import React from 'react';
import { ShoppingBag, ExternalLink, Sparkles, Tag, Gift } from 'lucide-react';
import { MonetizationSettings } from '../types/greeting';

interface AffiliateDealsProps {
  settings?: MonetizationSettings | null;
  lang?: 'hi' | 'en';
}

export const AffiliateDeals: React.FC<AffiliateDealsProps> = ({ settings, lang = 'hi' }) => {
  if (!settings) return null;

  const { amazonAffiliateUrl, flipkartAffiliateUrl, myntraAffiliateUrl, customDeals = [] } = settings;

  const majorStores = [
    {
      name: 'Amazon Diwali Sale',
      nameHi: 'अमेज़न ग्रेट इंडियन दिवाली सेल',
      url: amazonAffiliateUrl || 'https://www.amazon.in',
      tagline: lang === 'hi' ? 'दीये, पूजा सामग्री, लाइट्स एवं इलेक्ट्रॉनिक्स पर 75% तक छूट' : 'Up to 75% OFF on Diyas, Lights & Pooja Items',
      badge: 'Amazon Prime',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
      icon: '🛒',
      btnText: lang === 'hi' ? 'अमेज़न पर खरीदें' : 'Shop on Amazon',
    },
    {
      name: 'Flipkart Big Diwali Sale',
      nameHi: 'फ्लिपकार्ट बिग दिवाली सेल',
      url: flipkartAffiliateUrl || 'https://www.flipkart.com',
      tagline: lang === 'hi' ? 'काजू कतली, मिठाई गिफ्ट पैक, फैशन व घरेलू उपहार' : 'Festive Sweets, Dry Fruits & Gift Hampers',
      badge: 'Flipkart Assured',
      badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      icon: '🛍️',
      btnText: lang === 'hi' ? 'फ्लिपकार्ट पर खरीदें' : 'Shop on Flipkart',
    },
    {
      name: 'Myntra Festive Dhamaka',
      nameHi: 'मिंत्रा फेस्टिव फैशन महासेल',
      url: myntraAffiliateUrl || 'https://www.myntra.com',
      tagline: lang === 'hi' ? 'दिवाली कुर्ता सेट, कांजीवरम साड़ी व एथनिक परिधान' : 'Festive Kurtas, Silk Sarees & Ethnic Wear',
      badge: 'Myntra Festive',
      badgeColor: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
      icon: '👗',
      btnText: lang === 'hi' ? 'मिंत्रा पर खरीदें' : 'Shop on Myntra',
    },
  ];

  return (
    <section className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl sm:text-2xl font-black text-amber-100 font-festive">
              {lang === 'hi'
                ? 'दीपावली स्पेशल ऑफर्स व उपहार (Festive Deals)'
                : 'Diwali Special Shopping Deals & Gifts'}
            </h2>
          </div>
          <p className="text-xs text-amber-300/70 mt-1 font-hindi">
            {lang === 'hi'
              ? 'अमेज़न, फ्लिपकार्ट एवं मिंत्रा से पूजा सामग्री, मिठाई व कपड़े सर्वोत्तम छूट पर खरीदें।'
              : 'Direct verified festive deals on Amazon, Flipkart, and Myntra with exclusive festive savings.'}
          </p>
        </div>

        <span className="text-[11px] px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
          ✨ Verified Diwali Sales 2026
        </span>
      </div>

      {/* 3 Main Store Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {majorStores.map((store, idx) => (
          <a
            key={idx}
            href={store.url}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="group p-5 rounded-2xl bg-gradient-to-br from-[#1d0b33] to-[#120626] border border-amber-500/20 hover:border-amber-400/60 shadow-lg hover:shadow-2xl transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-2xl">{store.icon}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${store.badgeColor}`}>
                  {store.badge}
                </span>
              </div>
              <h3 className="text-base font-bold text-amber-100 font-festive group-hover:text-amber-300 transition-colors mb-1">
                {lang === 'hi' ? store.nameHi : store.name}
              </h3>
              <p className="text-xs text-amber-200/80 font-hindi leading-relaxed mb-4">
                {store.tagline}
              </p>
            </div>

            <div className="pt-3 border-t border-amber-500/15 flex items-center justify-between text-xs font-bold text-amber-300 group-hover:text-amber-200">
              <span>{store.btnText}</span>
              <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </a>
        ))}
      </div>

      {/* Curated Product Deals Grid */}
      {customDeals.length > 0 && (
        <div className="p-5 rounded-3xl bg-[#16072b]/80 border border-amber-500/20">
          <h4 className="text-sm font-bold text-amber-200 mb-3 flex items-center gap-1.5 font-hindi">
            <Gift className="w-4 h-4 text-amber-400" />
            <span>{lang === 'hi' ? 'लोकप्रिय दीपावली उपहार व पूजन उत्पाद:' : 'Trending Diwali Essentials & Gifts:'}</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {customDeals.map((deal) => (
              <a
                key={deal.id}
                href={deal.url}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="p-3 rounded-xl bg-black/40 hover:bg-black/60 border border-amber-500/15 hover:border-amber-400/40 transition-all flex items-center justify-between gap-2 group"
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className="text-xl shrink-0">{deal.icon || '🪔'}</span>
                  <div className="truncate">
                    <span className="text-xs font-semibold text-amber-100 group-hover:text-amber-300 block truncate">
                      {lang === 'hi' ? deal.titleHi : deal.title}
                    </span>
                    <div className="flex items-center gap-1.5 text-[10px] text-amber-300/70">
                      <span className="font-bold text-emerald-400">{deal.discountText}</span>
                      <span>·</span>
                      <span>{deal.store}</span>
                    </div>
                  </div>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-amber-400 shrink-0 opacity-70 group-hover:opacity-100" />
              </a>
            ))}
          </div>
        </div>
      )}
    </section>
  );
};
