import { DecorativeSticker } from '../types/greeting';

export const DECORATIVE_STICKERS: DecorativeSticker[] = [
  {
    id: 'diya-classic',
    name: 'Clay Diya',
    nameHi: 'पारंपरिक मिट्टी का दीया',
    category: 'diya',
    svgPath: 'M12 2c0 0-4 4-4 8 0 2.21 1.79 4 4 4s4-1.79 4-4c0-4-4-8-4-8zm-9 14c0 3.31 4.03 6 9 6s9-2.69 9-6H3z',
  },
  {
    id: 'diya-royal',
    name: 'Royal Brass Diya',
    nameHi: 'शाही पीतल दीया',
    category: 'diya',
    svgPath: 'M12 3c-1.5 2-2 3.5-2 5 0 1.1.9 2 2 2s2-.9 2-2c0-1.5-.5-3-2-5zm-7 8c0 3.5 3.5 5 7 5s7-1.5 7-5c0 0-1 4-7 4s-7-4-7-4zm4 6h6v2H9v-2zm-2 3h10v1H7v-1z',
  },
  {
    id: 'rangoli-mandala',
    name: 'Rangoli Mandala',
    nameHi: 'रंगोली मंडला',
    category: 'rangoli',
    svgPath: 'M12 2l2.5 5.5L20 8l-4 4.5 1 6-5-3-5 3 1-6-4-4.5 5.5-.5L12 2zm0 5a5 5 0 100 10 5 5 0 000-10z',
  },
  {
    id: 'shubh-swastik',
    name: 'Auspicious Swastik',
    nameHi: 'शुभ स्वास्तिक',
    category: 'divine',
    svgPath: 'M11 3v7H4V8h5V3h2zm2 0h2v5h5v2h-7V3zm-2 9v7H9v-5H4v-2h7zm9 0v2h-5v5h-2v-7h7z',
  },
  {
    id: 'divine-om',
    name: 'Sacred Om',
    nameHi: 'पवित्र ॐ',
    category: 'divine',
    svgPath: 'M7 4c2.5 0 4 1.5 4 3.5 0 1.5-1 2.5-2 3 1.5.5 3 2 3 4.5 0 2.8-2.2 5-5 5S2 18 2 15h3c0 1.1.9 2 2 2s2-.9 2-2-1-2-2.5-2H5v-2h1.5c1.1 0 1.5-.9 1.5-1.5S7.6 8 6.5 8C5.7 8 5 8.4 5 9H2C2 6.2 4.2 4 7 4zm10 2c0 2-2 4-4 4-1 0-1.5-.5-1.5-.5s.5 1.5 2 2c2 1 4 2.5 4 5.5 0 3.9-3.1 7-7 7v-2c2.8 0 5-2.2 5-5 0-2.2-1.5-3.5-3-4.5-2-1.2-3-2.5-3-4.5 0-2.8 2.2-5 5-5 1.5 0 2.5.5 2.5.5z',
  },
  {
    id: 'laxmi-charan',
    name: 'Laxmi Charan',
    nameHi: 'मां लक्ष्मी के चरण पादुका',
    category: 'divine',
    svgPath: 'M8 17c-2 0-3-2-3-4 0-3 2-6 3-8 1 2 3 5 3 8 0 2-1 4-3 4zm8 0c-2 0-3-2-3-4 0-3 2-6 3-8 1 2 3 5 3 8 0 2-1 4-3 4zm-9 3a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm10 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z',
  },
  {
    id: 'mangal-kalash',
    name: 'Mangal Kalash',
    nameHi: 'मंगल कलश',
    category: 'divine',
    svgPath: 'M12 2l2 4h-4l2-4zm-4 5h8l1 2H7l1-2zm-2 3h12l1 7c0 2.2-2.2 4-5 4H10c-2.8 0-5-1.8-5-4l1-7z',
  },
  {
    id: 'golden-sparkler',
    name: 'Phuljhadi Sparkler',
    nameHi: 'फुलझड़ी',
    category: 'crackers',
    svgPath: 'M12 1v4m0 14v4M1 12h4m14 0h4M4.2 4.2l2.8 2.8m10 10l2.8 2.8M4.2 19.8l2.8-2.8m10-10l2.8-2.8M12 8a4 4 0 100 8 4 4 0 000-8z',
  },
  {
    id: 'marigold-flower',
    name: 'Genda Phool Garland',
    nameHi: 'गेंदा फूल तोरण',
    category: 'floral',
    svgPath: 'M12 2a3 3 0 00-3 3c0 .5.1 1 .4 1.4A3 3 0 006 9c0 1.1.6 2 1.5 2.5A3 3 0 006 14a3 3 0 003 3c.5 0 1-.1 1.4-.4A3 3 0 0012 18a3 3 0 002-1.4c.4.3.9.4 1.4.4a3 3 0 003-3 3 3 0 00-1.5-2.5A3 3 0 0018 9a3 3 0 00-3.4-2.6A3 3 0 0012 2z',
  },
];
