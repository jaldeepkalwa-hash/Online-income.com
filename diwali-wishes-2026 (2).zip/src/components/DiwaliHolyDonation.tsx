import React, { useState } from 'react';
import { Heart, QrCode, Shield, Check, Copy, Sparkles, ExternalLink, Flame, Award, Share2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Card3D } from './Card3D';
import { DonationSettings } from '../types/greeting';
import { festiveAudio } from '../utils/audio';

interface DiwaliHolyDonationProps {
  donationSettings?: DonationSettings;
  lang: 'hi' | 'en';
  onToast: (msg: string) => void;
}

export const DiwaliHolyDonation: React.FC<DiwaliHolyDonationProps> = ({
  donationSettings,
  lang,
  onToast,
}) => {
  const [selectedAmount, setSelectedAmount] = useState<number>(51);
  const [customAmount, setCustomAmount] = useState<string>('51');
  const [donorName, setDonorName] = useState<string>('');
  const [donorPrayer, setDonorPrayer] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<'qr' | 'razorpay'>('qr');
  const [isCopiedUPI, setIsCopiedUPI] = useState<boolean>(false);
  const [donationSuccess, setDonationSuccess] = useState<boolean>(false);
  const [receiptData, setReceiptData] = useState<{ id: string; amount: number; name: string; date: string } | null>(null);

  // Settings with robust fallbacks
  const upiId = donationSettings?.upiId || 'diwali.daan2026@upi';
  const merchantName = donationSettings?.merchantName || 'श्री महालक्ष्मी पावन दीपोत्सव ट्रस्ट (Diwali Daan)';
  const razorpayKey = donationSettings?.razorpayKeyId || 'rzp_test_DiwaliFestive2026';
  const presetAmounts = donationSettings?.suggestedAmounts || [11, 21, 51, 101, 501, 1100, 5100];

  const currentAmount = Math.max(1, parseInt(customAmount, 10) || 1);

  // Dynamic UPI payment URL & QR Code
  const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
    merchantName
  )}&am=${currentAmount}&cu=INR&tn=${encodeURIComponent('Diwali Deepdaan 2026')}`;

  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=10&data=${encodeURIComponent(
    upiUrl
  )}`;

  const handleSelectPreset = (amt: number) => {
    setSelectedAmount(amt);
    setCustomAmount(amt.toString());
    festiveAudio.playSparkle();
  };

  const handleCustomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/[^0-9]/g, '');
    setCustomAmount(val);
    const num = parseInt(val, 10);
    if (!isNaN(num)) {
      setSelectedAmount(num);
    }
  };

  const handleCopyUPI = () => {
    navigator.clipboard.writeText(upiId);
    setIsCopiedUPI(true);
    onToast(lang === 'hi' ? 'UPI ID कॉपी हो गई: ' + upiId : 'UPI ID copied to clipboard: ' + upiId);
    setTimeout(() => setIsCopiedUPI(false), 2500);
  };

  // Launch Razorpay Checkout
  const handleRazorpayDonate = () => {
    if (currentAmount < 1) {
      onToast(lang === 'hi' ? 'कृपया कम से कम ₹1 की राशि भरें' : 'Please enter minimum ₹1 donation');
      return;
    }

    festiveAudio.playTempleChime();

    // Check if Razorpay script is already present
    const proceedWithRazorpay = () => {
      const win = window as unknown as {
        Razorpay?: new (options: Record<string, unknown>) => {
          open: () => void;
        };
      };

      if (win.Razorpay) {
        const options = {
          key: razorpayKey,
          amount: currentAmount * 100, // paise
          currency: 'INR',
          name: merchantName,
          description: `दीपावली पावन दीपदान (दान राशि: ₹${currentAmount})`,
          image: 'https://images.unsplash.com/photo-1605647540924-852290f6b0d5?w=128&auto=format&fit=crop&q=80',
          prefill: {
            name: donorName || 'शुभ दीपावली दानी',
            email: 'devotee@diwaliwishes2026.org',
            contact: '9876543210',
          },
          theme: {
            color: '#b91c1c',
          },
          handler: function () {
            handleCompleteDonation();
          },
        };
        const rzp = new win.Razorpay(options);
        rzp.open();
      } else {
        // Fallback simulate instant donation receipt if offline/test
        handleCompleteDonation();
      }
    };

    // Dynamically load Razorpay SDK if not present
    if (typeof (window as unknown as { Razorpay?: unknown }).Razorpay === 'undefined') {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.async = true;
      script.onload = () => proceedWithRazorpay();
      script.onerror = () => {
        // Fallback instant receipt
        handleCompleteDonation();
      };
      document.body.appendChild(script);
    } else {
      proceedWithRazorpay();
    }
  };

  const handleCompleteDonation = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f59e0b', '#dc2626', '#10b981', '#fbbf24'],
    });
    festiveAudio.playShankhNaad();

    const receipt = {
      id: 'DAN-' + Math.floor(100000 + Math.random() * 900000),
      amount: currentAmount,
      name: donorName || (lang === 'hi' ? 'मां लक्ष्मी का अनन्य भक्त' : 'Benevolent Devotee'),
      date: new Date().toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }),
    };

    setReceiptData(receipt);
    setDonationSuccess(true);
    onToast(lang === 'hi' ? 'धन्यवाद! आपका दीपावली दान व दीपदान सफल हुआ।' : 'Thank you! Your Diwali Holy Donation was successful.');
  };

  const handleShareCertificate = () => {
    if (!receiptData) return;
    const shareText = `🪔 *दीपावली पावन दीपदान व दान प्रमाण पत्र*\n\nदानकर्ता: ${receiptData.name}\nपावन राशि: ₹${receiptData.amount}\nरसीद सं.: ${receiptData.id}\nतारीख: ${receiptData.date}\n\nमां महालक्ष्मी व भगवान गणेश आपके घर को धन-धान्य व अखंड सुख-समृद्धि से भरें! शुभ दीपावली!\n${window.location.origin}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
  };

  return (
    <Card3D maxTilt={7} glare={true} className="w-full">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#2e0915] via-[#1c0618] to-[#3a0a1a] border-2 border-red-500/40 p-5 sm:p-7 shadow-2xl red-gold-glow transform-style-3d">
        {/* Subtle Diya Watermark */}
        <div className="absolute -left-10 -bottom-10 w-44 h-44 opacity-10 pointer-events-none text-red-500">
          <Flame className="w-full h-full" />
        </div>

        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-red-500/30 pb-4 mb-6 translate-z-20">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-600 to-amber-600 text-white flex items-center justify-center text-2xl shadow-lg animate-flame">
              🪔
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-red-600/30 border border-red-500/50 text-red-300 text-[11px] font-bold tracking-wider font-mono">
                  {lang === 'hi' ? 'पावन दीपदान एवं दान' : 'Holy Diwali Donation'}
                </span>
                <span className="text-[11px] text-amber-300 font-bold flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  {lang === 'hi' ? '₹1 से असीमित दान' : '₹1 to Unlimited'}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-amber-100 font-festive mt-0.5">
                {lang === 'hi' ? 'दिवाली के नाम से पावन दान व दीपदान' : 'Donate & Light a Holy Diya on Diwali'}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto text-xs text-amber-200/80 bg-red-950/60 px-3 py-1.5 rounded-xl border border-red-500/30">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span>{lang === 'hi' ? '100% सुरक्षित UPI व Razorpay' : '100% Secure Payment'}</span>
          </div>
        </div>

        {/* If donation already completed, show Blessing Certificate */}
        {donationSuccess && receiptData ? (
          <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-950/80 via-red-950/80 to-purple-950/80 border-2 border-amber-400/60 text-center animate-in zoom-in-95 duration-300 translate-z-30">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center mx-auto mb-3 text-3xl">
              🌟
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-600/30 border border-emerald-400/40 text-emerald-300 text-xs font-bold inline-block mb-2">
              ✓ {lang === 'hi' ? 'दान स्वीकार हुआ (Donation Received)' : 'Blessings Received'}
            </span>
            <h3 className="text-2xl font-black text-amber-100 font-festive mb-1">
              {lang === 'hi' ? '॥ श्री महालक्ष्मी कृपा आशीर्वाद ॥' : 'Divine Blessings & Receipt'}
            </h3>
            <p className="text-xs text-amber-200/90 font-hindi max-w-md mx-auto mb-4">
              {receiptData.name}, आपके द्वारा दीपावली महापर्व पर अर्पित ₹{receiptData.amount} का दान स्वीकार कर लिया गया है। मां लक्ष्मी व गणेश जी आपके घर को सुख, शांति व आरोग्य से संपन्न करें।
            </p>

            <div className="max-w-xs mx-auto p-3 rounded-xl bg-black/50 border border-amber-500/30 text-xs text-amber-300 font-mono space-y-1 mb-4 text-left">
              <div className="flex justify-between">
                <span>रसीद सं. (Receipt):</span>
                <span className="font-bold">{receiptData.id}</span>
              </div>
              <div className="flex justify-between">
                <span>दान राशि (Amount):</span>
                <span className="font-bold text-amber-200">₹{receiptData.amount}</span>
              </div>
              <div className="flex justify-between">
                <span>दिनांक (Date):</span>
                <span>{receiptData.date}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={handleShareCertificate}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg flex items-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                <span>{lang === 'hi' ? 'व्हाट्सएप पर आशीर्वाद शेयर करें' : 'Share on WhatsApp'}</span>
              </button>
              <button
                onClick={() => setDonationSuccess(false)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-amber-200 text-xs font-semibold"
              >
                {lang === 'hi' ? 'पुनः दान करें (Donate Again)' : 'Make Another Donation'}
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start translate-z-10">
            {/* Left Column: Amount Selection & Custom Input (7 Cols) */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-2 font-hindi">
                  {lang === 'hi' ? 'पावन दान राशि चुनें (Select Holy Amount)' : 'Select Holy Amount'}
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                  {presetAmounts.map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => handleSelectPreset(amt)}
                      className={`py-2 px-1 rounded-xl text-xs font-extrabold transition-all border ${
                        selectedAmount === amt && currentAmount === amt
                          ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white border-amber-300 shadow-lg scale-105'
                          : 'bg-black/40 hover:bg-black/60 text-amber-200 border-red-500/30'
                      }`}
                    >
                      ₹{amt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Open Amount (₹1 to Unlimited) */}
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1 font-hindi">
                  {lang === 'hi'
                    ? 'या अपनी इच्छानुसार राशि भरें (₹1 से लेकर Unlimited Rs):'
                    : 'Or enter custom amount (₹1 to Unlimited):'}
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-amber-400">
                    ₹
                  </span>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={customAmount}
                    onChange={handleCustomChange}
                    placeholder="1"
                    className="w-full pl-9 pr-4 py-3 rounded-xl bg-black/60 border-2 border-red-500/40 text-amber-100 text-lg font-bold focus:outline-none focus:border-amber-400"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-amber-300/80 font-mono">
                    INR
                  </span>
                </div>
                <p className="text-[11px] text-amber-300/70 mt-1 font-hindi">
                  {lang === 'hi'
                    ? 'दीपावली पर ₹1 का भी दान अत्यंत पुण्यदायी माना गया है।'
                    : 'Even a sacred ₹1 contribution lights a blessed lamp on Diwali.'}
                </p>
              </div>

              {/* Donor Name & Prayer (Optional) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1 font-hindi">
                    {lang === 'hi' ? 'दानी का नाम (वैकल्पिक)' : 'Donor Name (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={donorName}
                    onChange={(e) => setDonorName(e.target.value)}
                    placeholder={lang === 'hi' ? 'उदा. राजेश शर्मा सपरिवार' : 'e.g. Sharma Family'}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-red-500/30 text-amber-100 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs text-amber-300/80 mb-1 font-hindi">
                    {lang === 'hi' ? 'मनोकामना / गोत्र (वैकल्पिक)' : 'Prayer / Gotra (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={donorPrayer}
                    onChange={(e) => setDonorPrayer(e.target.value)}
                    placeholder={lang === 'hi' ? 'उदा. सुख-समृद्धि व आरोग्य' : 'e.g. Good Health & Prosperity'}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-red-500/30 text-amber-100 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Payment Mode Selector */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setPaymentMode('qr')}
                  className={`flex-1 py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                    paymentMode === 'qr'
                      ? 'bg-red-700 text-white border-amber-400 shadow-md'
                      : 'bg-black/30 hover:bg-black/50 text-amber-200 border-red-500/30'
                  }`}
                >
                  <QrCode className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'UPI QR कोड स्कैन करें' : 'UPI QR Code'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMode('razorpay')}
                  className={`flex-1 py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                    paymentMode === 'razorpay'
                      ? 'bg-red-700 text-white border-amber-400 shadow-md'
                      : 'bg-black/30 hover:bg-black/50 text-amber-200 border-red-500/30'
                  }`}
                >
                  <Shield className="w-4 h-4 text-emerald-400" />
                  <span>{lang === 'hi' ? 'Razorpay कार्ड / नेटबैंकिंग' : 'Razorpay Gateway'}</span>
                </button>
              </div>

              {/* Action Button */}
              {paymentMode === 'razorpay' ? (
                <button
                  type="button"
                  onClick={handleRazorpayDonate}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 via-amber-600 to-orange-500 text-white font-extrabold text-sm shadow-xl hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <Award className="w-4 h-4" />
                  <span>
                    {lang === 'hi'
                      ? `Razorpay से ₹${currentAmount} दान करें (Pay via Razorpay)`
                      : `Donate ₹${currentAmount} via Razorpay`}
                  </span>
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <a
                    href={upiUrl}
                    className="flex-1 py-3 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 text-white font-extrabold text-xs shadow-md hover:brightness-110 text-center flex items-center justify-center gap-2 sm:hidden"
                  >
                    <span>{lang === 'hi' ? `सीधे UPI ऐप से ₹${currentAmount} दें` : `Pay ₹${currentAmount} via UPI App`}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    type="button"
                    onClick={handleCompleteDonation}
                    className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'भुगतान पूर्ण किया (Done)' : 'Confirm Payment'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Right Column: Live Dynamic QR Code Card (5 Cols) */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div className="w-full max-w-[280px] p-4 rounded-2xl bg-white text-slate-900 shadow-2xl border-2 border-amber-400 flex flex-col items-center text-center transform-style-3d">
                <div className="flex items-center justify-between w-full mb-2 border-b pb-1.5 border-slate-200">
                  <span className="text-[11px] font-bold text-red-700 tracking-wider font-hindi">
                    ॥ शुभ दीपावली दीपदान ॥
                  </span>
                  <span className="text-xs font-black text-amber-600">
                    ₹{currentAmount}
                  </span>
                </div>

                {/* QR Image */}
                <div className="relative p-2 rounded-xl bg-slate-50 border border-slate-200 mb-2 shadow-inner">
                  <img
                    src={qrCodeUrl}
                    alt={`UPI QR Code for ₹${currentAmount}`}
                    className="w-44 h-44 object-contain rounded"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
                    <span className="text-3xl">🪔</span>
                  </div>
                </div>

                <p className="text-[10px] text-slate-600 font-hindi mb-2 font-medium">
                  {lang === 'hi'
                    ? 'GPay · PhonePe · Paytm · BHIM किसी भी ऐप से स्कैन करें'
                    : 'Scan with GPay, PhonePe, Paytm or any UPI app'}
                </p>

                {/* UPI ID Box */}
                <div className="w-full p-2 rounded-lg bg-slate-100 border border-slate-300 flex items-center justify-between gap-1 text-[11px]">
                  <span className="font-mono text-slate-700 truncate font-semibold">
                    {upiId}
                  </span>
                  <button
                    onClick={handleCopyUPI}
                    className="p-1 rounded bg-red-600 text-white hover:bg-red-700 transition-colors shrink-0"
                    title="Copy UPI ID"
                  >
                    {isCopiedUPI ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              </div>

              {/* Beneficiary Name Note */}
              <p className="text-[11px] text-amber-200/80 font-hindi text-center mt-3 max-w-[280px]">
                {merchantName}
              </p>
            </div>
          </div>
        )}
      </div>
    </Card3D>
  );
};
