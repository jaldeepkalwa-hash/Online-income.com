import React, { useState, useEffect } from 'react';
import { GREETING_DESIGNS } from './data/wishes';
import { CATEGORIES } from './data/categories';
import { GreetingDesign } from './types/greeting';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { DiwaliCountdown } from './components/DiwaliCountdown';
import { CategoryBar } from './components/CategoryBar';
import { GreetingGallery } from './components/GreetingGallery';
import { GreetingModal } from './components/GreetingModal';
import { GreetingMaker } from './components/GreetingMaker';
import { PublicGreetingView } from './components/PublicGreetingView';
import { AdminDashboard } from './components/AdminDashboard';
import { SeoLandingPage } from './components/SeoLandingPage';
import { Footer } from './components/Footer';
import { BottomNav } from './components/BottomNav';
import { Toast } from './components/Toast';
import { AdBanner } from './components/AdBanner';
import { AffiliateDeals } from './components/AffiliateDeals';
import { FestiveVideos } from './components/FestiveVideos';
import { GlobalThreeDiwaliWorld } from './components/GlobalThreeDiwaliWorld';
import { DiwaliVirtualCourtyard3D } from './components/DiwaliVirtualCourtyard3D';
import { getPreferredLanguage, setPreferredLanguage, getFavorites } from './utils/storage';
import { MonetizationSettings } from './types/greeting';
import { Sparkles, Layers, Wand2, Star, ArrowRight, Box } from 'lucide-react';

export default function App() {
  // App State
  const [lang, setLang] = useState<'hi' | 'en'>(getPreferredLanguage());
  const [currentView, setCurrentView] = useState<string>('home');
  const [viewParam, setViewParam] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  
  // Catalog State (allows admin to add/edit/delete dynamically)
  const [designs, setDesigns] = useState<GreetingDesign[]>(GREETING_DESIGNS);

  // Monetization & Video State
  const [monetization, setMonetization] = useState<MonetizationSettings | null>(null);

  // Modal & Edit State
  const [previewDesign, setPreviewDesign] = useState<GreetingDesign | null>(null);
  const [customizeDesign, setCustomizeDesign] = useState<GreetingDesign | null>(null);

  // Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Favorite Count for badge
  const [favCount, setFavCount] = useState<number>(0);

  // 3D Experience State
  const [show3DCourtyard, setShow3DCourtyard] = useState<boolean>(false);
  const [global3DEnabled, setGlobal3DEnabled] = useState<boolean>(true);

  // Fetch Monetization settings from server
  useEffect(() => {
    async function fetchMonetizationSettings() {
      try {
        const res = await fetch('/api/monetization');
        if (res.ok) {
          const data = await res.json();
          if (data.settings) {
            setMonetization(data.settings);
          }
        }
      } catch {
        // Fallback default
      }
    }
    fetchMonetizationSettings();
  }, []);

  // Sync favorites count
  useEffect(() => {
    const updateFavs = () => {
      setFavCount(getFavorites().length);
    };
    updateFavs();
    const interval = setInterval(updateFavs, 3000);
    return () => clearInterval(interval);
  }, []);

  // Handle URL Routing & History
  useEffect(() => {
    const parseUrl = () => {
      const path = window.location.pathname;
      if (path.startsWith('/wishes/')) {
        const slug = path.replace('/wishes/', '');
        setCurrentView('public-greeting');
        setViewParam(slug);
      } else if (path.startsWith('/card/')) {
        const id = path.replace('/card/', '');
        setCurrentView('public-greeting');
        setViewParam(id);
      } else if (path.startsWith('/seo/')) {
        const seoSlug = path.replace('/', '');
        setCurrentView('seo');
        setViewParam(seoSlug);
      } else if (path === '/create') {
        setCurrentView('create');
      } else if (path === '/admin') {
        setCurrentView('admin');
      } else if (path === '/favorites') {
        setCurrentView('favorites');
      } else if (path === '/gallery') {
        setCurrentView('gallery');
      } else if (path === '/categories') {
        setCurrentView('categories');
      } else {
        setCurrentView('home');
      }
    };

    parseUrl();
    window.addEventListener('popstate', parseUrl);
    return () => window.removeEventListener('popstate', parseUrl);
  }, []);

  // Navigation Helper
  const navigate = (view: string, param: string = '') => {
    setCurrentView(view);
    setViewParam(param);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    let newUrl = '/';
    if (view === 'public-greeting') {
      newUrl = `/wishes/${param}`;
    } else if (view === 'seo') {
      newUrl = `/${param}`;
    } else if (view !== 'home') {
      newUrl = `/${view}`;
    }
    window.history.pushState({}, '', newUrl);
  };

  const handleToggleLang = () => {
    const next = lang === 'hi' ? 'en' : 'hi';
    setLang(next);
    setPreferredLanguage(next);
    showToast(next === 'hi' ? 'भाषा: हिन्दी' : 'Language: English');
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  // Handler for Random Greeting click
  const handleRandomGreeting = () => {
    const random = designs[Math.floor(Math.random() * designs.length)];
    if (random) {
      setPreviewDesign(random);
    }
  };

  // Handlers for Admin
  const handleAddDesign = (newD: GreetingDesign) => {
    setDesigns([newD, ...designs]);
  };

  const handleDeleteDesign = (id: string) => {
    setDesigns(designs.filter((d) => d.id !== id));
  };

  const handleUpdateDesign = (updatedD: GreetingDesign) => {
    setDesigns(designs.map((d) => (d.id === updatedD.id ? updatedD : d)));
  };

  return (
    <div className="min-h-screen bg-[#0d051a] text-amber-50 flex flex-col selection:bg-amber-500 selection:text-purple-950 relative">
      {/* Global 3D Diwali World Background (Covers All Pages) */}
      <GlobalThreeDiwaliWorld enabled={global3DEnabled} />

      {/* Toast Notification */}
      {toastMessage && (
        <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
      )}

      {/* Main Header */}
      <Header
        lang={lang}
        onToggleLang={handleToggleLang}
        onNavigate={(view) => navigate(view)}
        currentView={currentView}
        onOpen3D={() => setShow3DCourtyard(true)}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {/* VIEW 1: HOME */}
        {currentView === 'home' && (
          <div>
            {/* Hero Section */}
            <Hero
              lang={lang}
              searchQuery={searchQuery}
              onSearchChange={(q) => {
                setSearchQuery(q);
                if (q.trim()) {
                  // auto scroll down to gallery
                  const el = document.getElementById('gallery-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              onCreateClick={() => {
                setCustomizeDesign(null);
                navigate('create');
              }}
              onRandomClick={handleRandomGreeting}
              onExploreGallery={() => {
                const el = document.getElementById('gallery-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* Diwali 2026 Countdown & Muhurat Banner */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 sm:-mt-8 relative z-20 mb-8">
              <DiwaliCountdown lang={lang} />
            </div>

            {/* 17 Categories Bar */}
            <CategoryBar
              selectedCategoryId={selectedCategoryId}
              onSelectCategory={(catId) => {
                setSelectedCategoryId(catId);
                const el = document.getElementById('gallery-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              lang={lang}
            />

            {/* Trending & Featured Highlights Banner */}
            <section className="py-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                  <h2 className="text-lg sm:text-xl font-bold text-amber-100 font-festive">
                    {lang === 'hi' ? 'ट्रेंडिंग विशेस 2026' : 'Trending Diwali Wishes 2026'}
                  </h2>
                </div>
                <button
                  onClick={() => navigate('gallery')}
                  className="text-xs font-semibold text-amber-300 hover:text-amber-100 flex items-center gap-1"
                >
                  <span>{lang === 'hi' ? 'सभी देखें' : 'View All'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Horizontal Scroll Highlights */}
              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin scrollbar-thumb-amber-500/20">
                {designs
                  .filter((d) => d.trending || d.featured)
                  .slice(0, 6)
                  .map((item) => (
                    <div
                      key={item.id}
                      onClick={() => setPreviewDesign(item)}
                      className="min-w-[240px] sm:min-w-[280px] p-4 rounded-2xl bg-gradient-to-br from-[#240e38] to-[#140624] border border-amber-500/20 hover:border-amber-400/50 cursor-pointer shadow-md transition-all flex flex-col justify-between shrink-0"
                    >
                      <div className="flex items-center justify-between text-[11px] text-amber-300/80 mb-2">
                        <span className="font-hindi">॥ शुभ दीपावली ॥</span>
                        <span className="bg-black/40 px-1.5 py-0.5 rounded font-mono text-[10px]">
                          {item.aspectRatio}
                        </span>
                      </div>
                      <div className="my-2">
                        <h4 className="text-sm font-bold text-amber-100 font-festive mb-1">
                          {lang === 'hi' ? item.titleHi : item.title}
                        </h4>
                        <p className="text-xs text-amber-200/80 line-clamp-2 font-hindi">
                          "{lang === 'hi' ? item.hindiWish : item.englishWish}"
                        </p>
                      </div>
                      <div className="pt-2 border-t border-amber-500/15 flex items-center justify-between text-xs text-amber-300">
                        <span>🔥 Trending</span>
                        <span className="font-bold">कस्टमाइज़ करें →</span>
                      </div>
                    </div>
                  ))}
              </div>
            </section>

            {/* Sponsored Google Ad / Adsterra Banner */}
            <AdBanner settings={monetization} slot="top" lang={lang} />

            {/* Main Greeting Gallery (100+ slots) */}
            <div id="gallery-section">
              <GreetingGallery
                designs={designs}
                selectedCategoryId={selectedCategoryId}
                searchQuery={searchQuery}
                lang={lang}
                onPreview={(design) => setPreviewDesign(design)}
                onCustomize={(design) => {
                  setCustomizeDesign(design);
                  navigate('create');
                }}
                onToast={showToast}
              />
            </div>

            {/* E-Commerce Festive Affiliate Deals (Amazon, Flipkart, Myntra) */}
            <AffiliateDeals settings={monetization} lang={lang} />

            {/* Festive Social Videos (YouTube, Instagram, Facebook) */}
            <FestiveVideos videos={monetization?.videos} lang={lang} />

            {/* Callout Section: Personalized Greeting Maker */}
            <section className="py-12 bg-gradient-to-r from-purple-950/80 via-[#220a3d] to-amber-950/80 border-y border-amber-500/30 my-8">
              <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center">
                <span className="text-4xl animate-flame block mb-3">🪔</span>
                <h2 className="text-2xl sm:text-4xl font-extrabold text-gold-gradient font-festive mb-3">
                  {lang === 'hi'
                    ? 'अपने नाम और फोटो के साथ बनाएं व्यक्तिगत दीपोत्सव कार्ड'
                    : 'Create Your Bespoke Diwali Greeting Card'}
                </h2>
                <p className="text-sm sm:text-base text-amber-200/90 max-w-2xl mx-auto font-hindi leading-relaxed mb-6">
                  {lang === 'hi'
                    ? 'परिवार, दोस्तों या अपनी दुकान/फर्म के नाम से आकर्षक कार्ड बनाएं, लाइव प्रीव्यू देखें और सीधे व्हाट्सएप पर शेयर करें।'
                    : 'Personalize with your photo, partner name, shop branding, custom Hindi fonts, and download in pristine HD format.'}
                </p>
                <button
                  onClick={() => {
                    setCustomizeDesign(null);
                    navigate('create');
                  }}
                  className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-purple-950 font-extrabold text-base shadow-xl hover:brightness-110 active:scale-95 transition-all gold-glow"
                >
                  <Wand2 className="w-5 h-5 stroke-[2.5]" />
                  <span>{lang === 'hi' ? 'अभी कार्ड बनाएं (Create Now)' : 'Open Greeting Maker'}</span>
                </button>
              </div>
            </section>
          </div>
        )}

        {/* VIEW 2: FULL 100+ GALLERY */}
        {currentView === 'gallery' && (
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-4">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-gold-gradient font-festive">
                {lang === 'hi' ? 'संपूर्ण 100+ दीपावली ग्रीटिंग डिजाइन्स' : 'All 100+ Diwali Greeting Designs'}
              </h1>
              <p className="text-xs sm:text-sm text-amber-300/80 font-hindi mt-1">
                {lang === 'hi'
                  ? 'सभी 17 श्रेणियों और विभिन्न आकारों (1:1, 9:16, 4:5, 16:9) में उपलब्ध।'
                  : 'Filter by categories, formats, and search terms to find your ideal Diwali greeting.'}
              </p>
            </div>
            <CategoryBar
              selectedCategoryId={selectedCategoryId}
              onSelectCategory={(id) => setSelectedCategoryId(id)}
              lang={lang}
            />
            <GreetingGallery
              designs={designs}
              selectedCategoryId={selectedCategoryId}
              searchQuery={searchQuery}
              lang={lang}
              onPreview={(design) => setPreviewDesign(design)}
              onCustomize={(design) => {
                setCustomizeDesign(design);
                navigate('create');
              }}
              onToast={showToast}
            />
          </div>
        )}

        {/* VIEW 3: ALL 17 CATEGORIES GRID */}
        {currentView === 'categories' && (
          <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-10">
              <h1 className="text-2xl sm:text-4xl font-black text-gold-gradient font-festive mb-2">
                {lang === 'hi' ? 'दीपावली ग्रीटिंग श्रेणियां (17 Categories)' : 'All 17 Greeting Categories'}
              </h1>
              <p className="text-xs sm:text-sm text-amber-200/80 font-hindi">
                {lang === 'hi'
                  ? 'हर रिश्ते और अवसर के लिए विशेष रूप से तैयार किए गए कार्ड और विशेस।'
                  : 'Curated for every relationship, occasion, and social platform.'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {CATEGORIES.map((cat, idx) => (
                <div
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategoryId(cat.id);
                    navigate('gallery');
                  }}
                  className="p-6 rounded-3xl bg-gradient-to-br from-[#1d0b33] to-[#120524] border border-amber-500/20 hover:border-amber-400/60 shadow-lg hover:shadow-2xl transition-all cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-mono text-amber-300/60">
                        #{idx + 1}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 font-mono">
                        {cat.defaultAspectRatio}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-amber-100 font-festive group-hover:text-amber-300 transition-colors mb-2">
                      {lang === 'hi' ? cat.nameHi : cat.name}
                    </h3>
                    <p className="text-xs text-amber-200/70 font-hindi leading-relaxed">
                      {cat.description}
                    </p>
                  </div>

                  <div className="pt-4 mt-4 border-t border-amber-500/15 flex items-center justify-between text-xs text-amber-300 font-semibold">
                    <span>डिजाइन्स देखें</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIEW 4: PERSONAL GREETING MAKER */}
        {currentView === 'create' && (
          <GreetingMaker
            initialDesign={customizeDesign}
            lang={lang}
            onBack={() => navigate('home')}
            onToast={showToast}
          />
        )}

        {/* VIEW 5: PUBLIC SHARED GREETING PAGE (/wishes/:slug) */}
        {currentView === 'public-greeting' && (
          <PublicGreetingView
            slug={viewParam}
            lang={lang}
            onBack={() => navigate('home')}
            onCreateNew={() => {
              setCustomizeDesign(null);
              navigate('create');
            }}
            onToast={showToast}
          />
        )}

        {/* VIEW 6: FAVORITES */}
        {currentView === 'favorites' && (
          <div className="py-6">
            <GreetingGallery
              designs={designs}
              selectedCategoryId="all"
              searchQuery=""
              lang={lang}
              favoritesOnly={true}
              favoriteIds={getFavorites()}
              onPreview={(design) => setPreviewDesign(design)}
              onCustomize={(design) => {
                setCustomizeDesign(design);
                navigate('create');
              }}
              onToast={showToast}
            />
          </div>
        )}

        {/* VIEW 7: SEO DEDICATED LANDING PAGES */}
        {currentView === 'seo' && (
          <SeoLandingPage
            slug={viewParam}
            lang={lang}
            designs={designs}
            onBack={() => navigate('home')}
            onCustomize={(design) => {
              setCustomizeDesign(design);
              navigate('create');
            }}
            onPreview={(design) => setPreviewDesign(design)}
            onToast={showToast}
          />
        )}

        {/* VIEW 8: PROTECTED ADMIN DASHBOARD */}
        {currentView === 'admin' && (
          <AdminDashboard
            designs={designs}
            onAddDesign={handleAddDesign}
            onDeleteDesign={handleDeleteDesign}
            onUpdateDesign={handleUpdateDesign}
            onBack={() => navigate('home')}
            onToast={showToast}
          />
        )}
      </main>

      {/* Greeting Modal (High-Res Preview & Direct Share) */}
      <GreetingModal
        design={previewDesign}
        lang={lang}
        onClose={() => setPreviewDesign(null)}
        onCustomize={(design) => {
          setPreviewDesign(null);
          setCustomizeDesign(design);
          navigate('create');
        }}
        onToast={showToast}
      />

      {/* Footer */}
      <Footer
        lang={lang}
        onSelectCategory={(catId) => {
          setSelectedCategoryId(catId);
          navigate('gallery');
        }}
        onNavigateSeo={(slug) => {
          navigate('seo', slug);
        }}
        onNavigate={(view) => navigate(view)}
      />

      {/* Floating 3D Mode Action Button (FAB) */}
      <button
        onClick={() => setShow3DCourtyard(true)}
        className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-40 flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 text-purple-950 font-black text-xs sm:text-sm shadow-2xl border-2 border-amber-300 hover:scale-105 active:scale-95 transition-all gold-glow group"
        title="Open Full 3D Interactive Diwali Courtyard & Firecrackers"
      >
        <span className="text-xl animate-flame group-hover:rotate-12 transition-transform">🪔</span>
        <span className="hidden sm:inline font-festive">{lang === 'hi' ? '3D दीपोत्सव दर्शन' : '3D Diwali World'}</span>
        <span className="sm:hidden font-festive">3D</span>
      </button>

      {/* 3D Virtual Mandir & Courtyard Fullscreen Experience */}
      {show3DCourtyard && (
        <DiwaliVirtualCourtyard3D
          lang={lang}
          onClose={() => setShow3DCourtyard(false)}
          onToast={showToast}
        />
      )}

      {/* Mobile-First Bottom Navigation */}
      <BottomNav
        currentView={currentView}
        onNavigate={(view) => navigate(view)}
        lang={lang}
        favCount={favCount}
        onOpen3D={() => setShow3DCourtyard(true)}
      />
    </div>
  );
}
