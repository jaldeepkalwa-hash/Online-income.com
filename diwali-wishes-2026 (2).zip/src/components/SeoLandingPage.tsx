import React from 'react';
import { ArrowLeft, Sparkles, Wand2, ChevronRight, HelpCircle, CheckCircle2 } from 'lucide-react';
import { GreetingDesign } from '../types/greeting';
import { GreetingCard } from './GreetingCard';

interface SeoLandingPageProps {
  slug: string;
  lang: 'hi' | 'en';
  designs: GreetingDesign[];
  onBack: () => void;
  onCustomize: (design: GreetingDesign) => void;
  onPreview: (design: GreetingDesign) => void;
  onToast: (msg: string) => void;
}

interface SeoPageConfig {
  title: string;
  titleHi: string;
  metaDesc: string;
  categoryIdFilter: string;
  aspectRatioFilter?: string;
  introText: string;
  introTextHi: string;
  faqs: Array<{ q: string; a: string }>;
}

const SEO_CONFIGS: Record<string, SeoPageConfig> = {
  'diwali-greetings': {
    title: 'Happy Diwali 2026 Wishes, Quotes & Greetings in Hindi and English',
    titleHi: 'दीपावली 2026 की हार्दिक शुभकामनाएँ एवं बधाई संदेश',
    metaDesc: 'Explore heartfelt Diwali 2026 wishes, quotes, and traditional Hindi messages. Create personalized greeting cards for family, friends, and colleagues.',
    categoryIdFilter: 'hindi-wishes',
    introText: 'Celebrate the supreme festival of lights with uplifting Hindi and English Deepawali wishes. Find traditional Sanskrit shlokas, heartfelt family blessings, and stylish festive quotes ready for one-click copy and instant social sharing.',
    introTextHi: 'दीपों के इस महापर्व पर अपने प्रियजनों को भेजें प्रेम, सौहार्द और मंगलकामनाओं से भरे पावन संदेश। यहाँ पाएं शास्त्रीय श्लोक, पारंपरिक दोहे और आधुनिक दिवाली विशेस।',
    faqs: [
      {
        q: 'When is Diwali celebrated in 2026?',
        a: 'Diwali (Lakshmi Puja) in 2026 is celebrated on Sunday, November 8, 2026, marking Kartik Krishna Amavasya in Vikram Samvat 2083.',
      },
      {
        q: 'How can I send personalized Diwali wishes with my name?',
        a: 'Simply click "Create Greeting", enter your name, recipient name, select an auspicious Hindi or English message, and download your customized HD Diwali card for free.',
      },
    ],
  },
  'whatsapp-status': {
    title: 'Diwali WhatsApp Status 9:16 HD Images & Video Backgrounds 2026',
    titleHi: 'दिवाली व्हाट्सएप स्टेटस (9:16) फुल स्क्रीन इमेज एवं ग्रीटिंग्स',
    metaDesc: 'Download 9:16 vertical full screen Happy Diwali 2026 WhatsApp status images with your name and photo. High-definition festive templates.',
    categoryIdFilter: 'whatsapp-status',
    aspectRatioFilter: '9:16',
    introText: 'Full-screen 9:16 vertical festive cards engineered specifically for mobile WhatsApp Status and Telegram stories. Featuring glowing diyas, golden fireworks, and vibrant rangoli patterns.',
    introTextHi: 'मोबाइल की पूरी स्क्रीन पर झिलमिलाते 9:16 आकार के दीपोत्सव स्टेटस कार्ड। अपना नाम और फोटो जोड़कर सीधे अपने व्हाट्सएप स्टेटस पर लगाएं।',
    faqs: [
      {
        q: 'What is the best image resolution for WhatsApp status?',
        a: 'The ideal ratio is 9:16 (1080x1920 pixels). All designs in this section are tailored to render crisply without stretching or unwanted cropping.',
      },
      {
        q: 'Can I add my photo to the WhatsApp status?',
        a: 'Yes, upload your photo in our Greeting Maker to place it with a royal golden circular border inside the 9:16 vertical card.',
      },
    ],
  },
  'diwali-images-with-name': {
    title: 'Create Diwali 2026 Images with Name & Photo Online Free',
    titleHi: 'अपने नाम और फोटो के साथ दिवाली ग्रीटिंग कार्ड बनाएं',
    metaDesc: 'Generate customized Happy Diwali images with your name, photo, and shop details online. Free instant HD download with glowing diyas and rangoli.',
    categoryIdFilter: 'royal-gold',
    introText: 'Personalize luxury 24K gold foil and royal purple Diwali cards. Type your name, partner or family names, and optional business details to create a bespoke festive keepsake.',
    introTextHi: 'बिना किसी ग्राफिक डिज़ाइनर के, सिर्फ 1 मिनट में अपने नाम और परिवार की फोटो के साथ सुंदर दीपोत्सव कार्ड बनाएं और एचडी क्वालिटी में डाउनलोड करें।',
    faqs: [
      {
        q: 'Is any login or payment required to download images with name?',
        a: 'No login, subscription, or watermark is required. All basic greeting cards and photo frames are 100% free and open for personal use.',
      },
      {
        q: 'Does it support typing Hindi fonts accurately?',
        a: 'Yes! Our custom HTML5 Canvas engine fully supports Hindi Unicode fonts including Rozha One, Noto Sans Devanagari, and calligraphy styles.',
      },
    ],
  },
  'business-diwali-wishes': {
    title: 'Corporate & Business Diwali Greetings 2026 - Shubh Laabh Cards',
    titleHi: 'व्यापार एवं दुकान के लिए शुभ-लाभ दिवाली शुभकामना कार्ड',
    metaDesc: 'Professional Diwali greetings for corporate clients, employees, shop owners, and retailers. Shubh Laabh cards with company branding.',
    categoryIdFilter: 'business-shop',
    introText: 'Express gratitude to loyal patrons, business partners, and colleagues with refined corporate and retail Diwali cards. Ideal for LinkedIn, email signatures, and storefront banners.',
    introTextHi: 'ग्राहकों और व्यावसायिक भागीदारों को दीपोत्सव की शुभकामना देने के लिए विशेष शुभ-लाभ एवं समृद्धि कार्ड। अपनी दुकान या फर्म का नाम अंकित करें।',
    faqs: [
      {
        q: 'Can I put my store or company name on the greeting card?',
        a: 'Yes, there is a dedicated field for "Business / Shop Name" that prominently prints your enterprise name with an auspicious "॥ शुभ लाभ ॥" crest.',
      },
    ],
  },
  'instagram-diwali-posts': {
    title: 'Instagram Diwali Story & Square Post Templates 2026',
    titleHi: 'इंस्टाग्राम दिवाली स्टोरी और रील थंबनेल टेम्पलेट्स',
    metaDesc: 'Aesthetic Diwali Instagram story templates (9:16) and feed posts (1:1). High engagement festive graphics for creators and influencers.',
    categoryIdFilter: 'instagram-story',
    aspectRatioFilter: '9:16',
    introText: 'Aesthetic, contemporary festive layouts crafted for content creators, fashion influencers, and Instagram enthusiasts. Rich deep colors with elegant typography.',
    introTextHi: 'इंस्टाग्राम फीड और स्टोरी के लिए आधुनिक, खूबसूरत और एस्थेटिक दिवाली टेम्पलेट्स। अपनी दिवाली ओओटीडी (OOTD) और तस्वीरों के साथ साझा करें।',
    faqs: [
      {
        q: 'How do I post this directly to Instagram?',
        a: 'Download the rendered high-res image to your device gallery, open Instagram, select Story or Post, and publish with our festive Diwali hashtags.',
      },
    ],
  },
};

export const SeoLandingPage: React.FC<SeoLandingPageProps> = ({
  slug,
  lang,
  designs,
  onBack,
  onCustomize,
  onPreview,
  onToast,
}) => {
  const cleanSlug = slug.replace(/^seo\//, '');
  const config = SEO_CONFIGS[cleanSlug] || SEO_CONFIGS['diwali-greetings'];

  const matchingDesigns = designs.filter((d) => {
    if (config.aspectRatioFilter && d.aspectRatio !== config.aspectRatioFilter) return false;
    return d.categoryId === config.categoryIdFilter || d.tags.includes(cleanSlug);
  }).slice(0, 8);

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-xs text-amber-300/60 mb-6 font-medium">
        <button onClick={onBack} className="hover:text-amber-200">
          Home
        </button>
        <ChevronRight className="w-3.5 h-3.5" />
        <span className="text-amber-200/90">{config.titleHi}</span>
      </nav>

      {/* Hero Header */}
      <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-br from-[#240e3d] to-[#120524] border border-amber-500/30 shadow-xl gold-glow mb-10">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>विशेष दीपोत्सव 2026 संग्रह</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-gold-gradient font-festive mb-3 leading-tight">
            {lang === 'hi' ? config.titleHi : config.title}
          </h1>

          <p className="text-sm sm:text-base text-amber-200/90 font-hindi leading-relaxed mb-6">
            {lang === 'hi' ? config.introTextHi : config.introText}
          </p>

          <button
            onClick={() => onCustomize(matchingDesigns[0] || designs[0])}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-purple-950 font-bold text-sm shadow-lg hover:brightness-110 active:scale-95 transition-all"
          >
            <Wand2 className="w-4 h-4 stroke-[2.5]" />
            <span>अपना नाम लिखकर कार्ड बनाएं (Create with Name)</span>
          </button>
        </div>
      </div>

      {/* Featured Designs in this topic */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg sm:text-2xl font-bold text-amber-100 font-festive">
            {lang === 'hi' ? 'विशेष चयनित डिजाइन्स' : 'Curated Design Templates'}
          </h2>
          <span className="text-xs text-amber-300/70 font-mono">
            {matchingDesigns.length} Templates
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {matchingDesigns.map((design) => (
            <GreetingCard
              key={design.id}
              design={design}
              lang={lang}
              onPreview={onPreview}
              onCustomize={onCustomize}
              onToast={onToast}
            />
          ))}
        </div>
      </section>

      {/* FAQ Section with SEO Value */}
      <section className="p-6 sm:p-8 rounded-3xl bg-[#17082a] border border-amber-500/20 max-w-4xl mx-auto">
        <div className="flex items-center gap-2 text-amber-300 font-bold mb-4">
          <HelpCircle className="w-5 h-5 text-amber-400" />
          <h3 className="text-base sm:text-lg">अक्सर पूछे जाने वाले प्रश्न (Frequently Asked Questions)</h3>
        </div>

        <div className="space-y-4">
          {config.faqs.map((faq, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-black/30 border border-amber-500/15">
              <h4 className="text-sm font-bold text-amber-100 mb-1 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{faq.q}</span>
              </h4>
              <p className="text-xs sm:text-sm text-amber-200/80 pl-6 font-hindi leading-relaxed">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Google Search Console & Analytics Instructions Modal Anchor */}
      <div className="mt-8 text-center text-xs text-amber-300/60 font-hindi">
        <span>Google Search Console: Submit sitemap at </span>
        <code className="text-amber-300 bg-black/40 px-1.5 py-0.5 rounded">/sitemap.xml</code>
        <span> · Robots file at </span>
        <code className="text-amber-300 bg-black/40 px-1.5 py-0.5 rounded">/robots.txt</code>
      </div>
    </div>
  );
};
