import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';

interface ThreeDiwaliSceneProps {
  className?: string;
}

export const ThreeDiwaliScene: React.FC<ThreeDiwaliSceneProps> = ({ className = '' }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0e051c, 0.05);

    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 1.8, 6.2);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // Group for the 3D Diya & Lanterns
    const mainGroup = new THREE.Group();
    scene.add(mainGroup);

    // 1. Procedural 3D Clay Diya Bowl
    const diyaGroup = new THREE.Group();

    // Terracotta material with subtle gold trim
    const clayMat = new THREE.MeshStandardMaterial({
      color: 0x853012,
      roughness: 0.65,
      metalness: 0.25,
    });

    const goldTrimMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.3,
      metalness: 0.85,
    });

    // Diya base dish
    const baseGeo = new THREE.CylinderGeometry(1.2, 0.6, 0.45, 32);
    const baseMesh = new THREE.Mesh(baseGeo, clayMat);
    baseMesh.castShadow = true;
    baseMesh.receiveShadow = true;
    diyaGroup.add(baseMesh);

    // Diya golden rim
    const rimGeo = new THREE.TorusGeometry(1.22, 0.08, 16, 32);
    rimGeo.rotateX(Math.PI / 2);
    rimGeo.translate(0, 0.22, 0);
    const rimMesh = new THREE.Mesh(rimGeo, goldTrimMat);
    diyaGroup.add(rimMesh);

    // Inner oil pool
    const oilGeo = new THREE.CylinderGeometry(1.05, 1.05, 0.05, 32);
    const oilMat = new THREE.MeshStandardMaterial({
      color: 0xb45309,
      roughness: 0.1,
      metalness: 0.4,
    });
    const oilMesh = new THREE.Mesh(oilGeo, oilMat);
    oilMesh.position.y = 0.15;
    diyaGroup.add(oilMesh);

    // Diya wick beak
    const beakGeo = new THREE.ConeGeometry(0.35, 0.6, 16);
    beakGeo.rotateZ(Math.PI / 4);
    const beakMesh = new THREE.Mesh(beakGeo, clayMat);
    beakMesh.position.set(1.15, 0.2, 0);
    diyaGroup.add(beakMesh);

    // 2. Multi-Layer Animated 3D Flame
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0xffedd5,
    });
    const flameOuterMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.85,
    });

    const flameInnerGeo = new THREE.ConeGeometry(0.2, 0.75, 16);
    const flameInner = new THREE.Mesh(flameInnerGeo, flameMat);
    flameInner.position.set(0, 0.65, 0);

    const flameOuterGeo = new THREE.ConeGeometry(0.34, 0.95, 16);
    const flameOuter = new THREE.Mesh(flameOuterGeo, flameOuterMat);
    flameOuter.position.set(0, 0.65, 0);

    const flameGroup = new THREE.Group();
    flameGroup.add(flameOuter);
    flameGroup.add(flameInner);
    diyaGroup.add(flameGroup);

    // Dynamic Point Light from Flame
    const flameLight = new THREE.PointLight(0xf59e0b, 3.5, 8);
    flameLight.position.set(0, 0.8, 0);
    flameLight.castShadow = true;
    diyaGroup.add(flameLight);

    const ambientLight = new THREE.AmbientLight(0x3b185f, 1.2);
    scene.add(ambientLight);

    const moonLight = new THREE.DirectionalLight(0xa78bfa, 0.8);
    moonLight.position.set(-5, 8, 4);
    scene.add(moonLight);

    mainGroup.add(diyaGroup);
    diyaGroup.position.set(0, -0.4, 0);

    // 3. Floating 3D Akash Kandil Lanterns
    const lanternMat = new THREE.MeshStandardMaterial({
      color: 0xe11d48,
      emissive: 0x9f1239,
      emissiveIntensity: 0.4,
      roughness: 0.4,
    });

    const createLantern = (x: number, y: number, z: number) => {
      const g = new THREE.Group();
      const bodyGeo = new THREE.OctahedronGeometry(0.5, 0);
      const m = new THREE.Mesh(bodyGeo, lanternMat);
      g.add(m);

      const lanternLight = new THREE.PointLight(0xf43f5e, 1.5, 4);
      g.add(lanternLight);

      g.position.set(x, y, z);
      return g;
    };

    const lantern1 = createLantern(-2.8, 1.4, -1);
    const lantern2 = createLantern(2.8, 1.2, -1.2);
    mainGroup.add(lantern1);
    mainGroup.add(lantern2);

    // 4. Golden Sparkle Particle System
    const particleCount = 450;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const scales = new Float32Array(particleCount);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 12;
      positions[i + 1] = (Math.random() - 0.5) * 8;
      positions[i + 2] = (Math.random() - 0.5) * 8;
      scales[i / 3] = Math.random() * 0.08 + 0.02;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0xfef08a,
      size: 0.08,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    scene.add(particleSystem);

    // Mouse / Touch Parallax Tracking
    let targetRotX = 0;
    let targetRotY = 0;

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      const normX = (clientX / window.innerWidth) * 2 - 1;
      const normY = -(clientY / window.innerHeight) * 2 + 1;

      targetRotY = normX * 0.45;
      targetRotX = normY * 0.25;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Smooth camera parallax
      camera.position.x += (targetRotY * 1.5 - camera.position.x) * 0.05;
      camera.position.y += (1.8 + targetRotX * 0.8 - camera.position.y) * 0.05;
      camera.lookAt(0, 0.2, 0);

      // Realistic flame flicker physics
      const flicker = Math.sin(elapsed * 12) * 0.08 + Math.cos(elapsed * 24) * 0.04;
      const flameScaleX = 1 + flicker * 0.8;
      const flameScaleY = 1 + Math.sin(elapsed * 16) * 0.15;
      flameGroup.scale.set(flameScaleX, flameScaleY, flameScaleX);
      flameGroup.rotation.z = Math.sin(elapsed * 8) * 0.08;
      flameGroup.rotation.x = Math.cos(elapsed * 6) * 0.05;

      flameLight.intensity = 3.2 + Math.sin(elapsed * 18) * 0.6;

      // Diya subtle float rotation
      diyaGroup.rotation.y = Math.sin(elapsed * 0.8) * 0.12;

      // Lantern float oscillation
      lantern1.position.y = 1.4 + Math.sin(elapsed * 1.5) * 0.15;
      lantern1.rotation.y = elapsed * 0.3;
      lantern2.position.y = 1.2 + Math.cos(elapsed * 1.3) * 0.15;
      lantern2.rotation.y = -elapsed * 0.25;

      // Gentle sparkle particles drift
      particleSystem.rotation.y = elapsed * 0.03;
      particleSystem.rotation.x = Math.sin(elapsed * 0.02) * 0.05;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('resize', handleResize);

      if (container && renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }

      // Dispose resources
      renderer.dispose();
      clayMat.dispose();
      goldTrimMat.dispose();
      flameMat.dispose();
      flameOuterMat.dispose();
      particleMat.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 pointer-events-none select-none z-0 ${className}`}
      aria-hidden="true"
    />
  );
};
