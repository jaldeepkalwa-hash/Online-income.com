import React, { useState, useMemo } from 'react';
import { GreetingDesign, AspectRatioType } from '../types/greeting';
import { GreetingCard } from './GreetingCard';
import { Sparkles, SlidersHorizontal, ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';

interface GreetingGalleryProps {
  designs: GreetingDesign[];
  selectedCategoryId: string;
  searchQuery: string;
  lang: 'hi' | 'en';
  onPreview: (design: GreetingDesign) => void;
  onCustomize: (design: GreetingDesign) => void;
  onToast: (msg: string) => void;
  favoritesOnly?: boolean;
  favoriteIds?: string[];
}

export const GreetingGallery: React.FC<GreetingGalleryProps> = ({
  designs,
  selectedCategoryId,
  searchQuery,
  lang,
  onPreview,
  onCustomize,
  onToast,
  favoritesOnly = false,
  favoriteIds = [],
}) => {
  const [selectedRatio, setSelectedRatio] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'popular' | 'trending' | 'newest'>('featured');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 12;

  // Filter and sort items
  const filteredDesigns = useMemo(() => {
    return designs
      .filter((d) => {
        // Favorites check
        if (favoritesOnly && !favoriteIds.includes(d.id)) {
          return false;
        }

        // Category check
        if (selectedCategoryId !== 'all' && d.categoryId !== selectedCategoryId) {
          return false;
        }

        // Aspect ratio check
        if (selectedRatio !== 'all' && d.aspectRatio !== selectedRatio) {
          return false;
        }

        // Search query check
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchTitle = d.title.toLowerCase().includes(q) || d.titleHi.toLowerCase().includes(q);
          const matchWish = d.hindiWish.toLowerCase().includes(q) || d.englishWish.toLowerCase().includes(q);
          const matchTag = d.tags.some((t) => t.toLowerCase().includes(q));
          if (!matchTitle && !matchWish && !matchTag) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'trending') return (b.trending ? 1 : 0) - (a.trending ? 1 : 0);
        if (sortBy === 'popular') return (b.likes || 0) - (a.likes || 0);
        if (sortBy === 'newest') return b.id.localeCompare(a.id);
        // Featured default
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      });
  }, [designs, selectedCategoryId, selectedRatio, searchQuery, sortBy, favoritesOnly, favoriteIds]);

  // Reset page when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategoryId, selectedRatio, searchQuery, sortBy, favoritesOnly]);

  const totalPages = Math.ceil(filteredDesigns.length / itemsPerPage) || 1;
  const paginatedDesigns = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredDesigns.slice(start, start + itemsPerPage);
  }, [filteredDesigns, currentPage, itemsPerPage]);

  return (
    <section className="py-8 sm:py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header controls & stats */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl sm:text-2xl font-black text-amber-100 font-festive">
              {favoritesOnly
                ? (lang === 'hi' ? 'आपके पसंदीदा कार्ड' : 'Your Favorite Greetings')
                : (lang === 'hi' ? 'दीपावली ग्रीटिंग डिजाइन्स' : 'Diwali Greeting Designs')}
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono font-bold">
              {filteredDesigns.length}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-amber-200/70 mt-1 font-hindi">
            {lang === 'hi'
              ? 'व्हाट्सएप, इंस्टाग्राम और फेसबुक के लिए तुरंत डाउनलोड व साझा करें।'
              : 'Browse, customize, and download high-resolution greetings ready for social sharing.'}
          </p>
        </div>

        {/* Filter Toolbar */}
        <div className="flex items-center gap-2 flex-wrap w-full md:w-auto">
          {/* Aspect Ratio Filter Tabs */}
          <div className="flex items-center bg-[#150726] border border-amber-500/20 rounded-xl p-1 text-xs">
            {[
              { id: 'all', label: lang === 'hi' ? 'सभी' : 'All' },
              { id: '1:1', label: '1:1 Square' },
              { id: '9:16', label: '9:16 Status' },
              { id: '4:5', label: '4:5 Card' },
              { id: '16:9', label: '16:9 Banner' },
            ].map((r) => (
              <button
                key={r.id}
                onClick={() => setSelectedRatio(r.id)}
                className={`px-2.5 py-1.5 rounded-lg font-medium transition-colors ${
                  selectedRatio === r.id
                    ? 'bg-amber-500 text-purple-950 font-bold shadow-sm'
                    : 'text-amber-200/70 hover:text-amber-100'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-1.5 bg-[#150726] border border-amber-500/20 rounded-xl px-2.5 py-1 text-xs">
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'featured' | 'popular' | 'trending' | 'newest')}
              className="bg-transparent text-amber-200 text-xs focus:outline-none cursor-pointer py-1"
            >
              <option value="featured" className="bg-[#1a0833] text-amber-100">
                {lang === 'hi' ? 'खास (Featured)' : 'Featured'}
              </option>
              <option value="trending" className="bg-[#1a0833] text-amber-100">
                {lang === 'hi' ? 'ट्रेंडिंग (Trending)' : 'Trending'}
              </option>
              <option value="popular" className="bg-[#1a0833] text-amber-100">
                {lang === 'hi' ? 'सर्वाधिक लोकप्रिय' : 'Most Popular'}
              </option>
              <option value="newest" className="bg-[#1a0833] text-amber-100">
                {lang === 'hi' ? 'नवीनतम' : 'Newest First'}
              </option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid of Designs */}
      {paginatedDesigns.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 sm:gap-6">
          {paginatedDesigns.map((design) => (
            <GreetingCard
              key={design.id}
              design={design}
              lang={lang}
              onPreview={onPreview}
              onCustomize={onCustomize}
              onToast={onToast}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-16 bg-[#16072b]/60 rounded-3xl border border-amber-500/20 p-8 my-6">
          <span className="text-5xl mb-3 inline-block">🪔</span>
          <h3 className="text-lg sm:text-xl font-bold text-amber-200 mb-2 font-festive">
            {lang === 'hi' ? 'कोई ग्रीटिंग नहीं मिला' : 'No Greeting Cards Found'}
          </h3>
          <p className="text-sm text-amber-300/70 max-w-md mx-auto mb-5 font-hindi">
            {lang === 'hi'
              ? 'कृपया अपने खोज शब्द या फ़िल्टर बदलकर दोबारा प्रयास करें।'
              : 'Try searching with different keywords or reset your category and aspect ratio filters.'}
          </p>
          <button
            onClick={() => {
              setSelectedRatio('all');
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 text-sm font-semibold transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{lang === 'hi' ? 'फ़िल्टर रीसेट करें' : 'Reset Filters'}</span>
          </button>
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-10">
          <button
            onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
            className="p-2.5 rounded-xl bg-[#17082a] border border-amber-500/20 text-amber-200 disabled:opacity-40 hover:bg-white/5 transition-colors"
            aria-label="Previous Page"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-1.5">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-9 h-9 rounded-xl text-xs font-bold transition-all ${
                  currentPage === page
                    ? 'bg-amber-500 text-purple-950 shadow-md font-black'
                    : 'bg-[#17082a] border border-amber-500/20 text-amber-200/80 hover:bg-white/5'
                }`}
              >
                {page}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="p-2.5 rounded-xl bg-[#17082a] border border-amber-500/20 text-amber-200 disabled:opacity-40 hover:bg-white/5 transition-colors"
            aria-label="Next Page"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </section>
  );
};
