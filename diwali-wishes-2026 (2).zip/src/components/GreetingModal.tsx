import React, { useState } from 'react';
import { GreetingDesign } from '../types/greeting';
import { X, Copy, Share2, Wand2, Heart, Check, QrCode, Box } from 'lucide-react';
import { isFavorite, toggleFavorite } from '../utils/storage';
import { Card3D } from './Card3D';
import {
  copyToClipboard,
  shareToWhatsApp,
  shareToFacebook,
  shareToTwitter,
  shareToTelegram,
  shareToNative,
} from '../utils/share';

interface GreetingModalProps {
  design: GreetingDesign | null;
  lang: 'hi' | 'en';
  onClose: () => void;
  onCustomize: (design: GreetingDesign) => void;
  onToast: (msg: string) => void;
}

export const GreetingModal: React.FC<GreetingModalProps> = ({
  design,
  lang,
  onClose,
  onCustomize,
  onToast,
}) => {
  if (!design) return null;

  const [fav, setFav] = useState(isFavorite(design.id));
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);

  const wish = lang === 'hi' ? design.hindiWish : design.englishWish;
  const shareUrl = `${window.location.origin}/wishes/${design.slug}`;

  const handleCopyWish = async () => {
    const text = `✨ ${design.titleHi} ✨\n\n"${wish}"\n\n🪔 शुभ दीपावली 2026!\n🔗 ${shareUrl}`;
    const ok = await copyToClipboard(text);
    if (ok) {
      setCopied(true);
      onToast(lang === 'hi' ? 'शुभकामना कॉपी हो गई!' : 'Greeting copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCopyLink = async () => {
    const ok = await copyToClipboard(shareUrl);
    if (ok) {
      onToast(lang === 'hi' ? 'लिंक कॉपी हो गया!' : 'Shareable link copied!');
    }
  };

  const handleFav = () => {
    const next = toggleFavorite(design.id);
    setFav(next);
    onToast(
      next
        ? (lang === 'hi' ? 'पसंदीदा में जोड़ा गया ❤️' : 'Added to favorites')
        : (lang === 'hi' ? 'हटाया गया' : 'Removed from favorites')
    );
  };

  const shareOptions = {
    title: design.title,
    text: `🪔 ${design.titleHi}\n\n"${wish}"\n\nHappy Diwali 2026!`,
    url: shareUrl,
    cardId: design.id,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-[#180830] border border-amber-500/30 rounded-3xl overflow-hidden shadow-2xl gold-glow my-6 animate-scale-up">
        {/* Top bar */}
        <div className="flex items-center justify-between p-4 border-b border-amber-500/20 bg-[#120524]">
          <div className="flex items-center gap-2">
            <span className="text-xl">🪔</span>
            <div>
              <h3 className="text-sm font-bold text-amber-100 font-festive">
                {lang === 'hi' ? design.titleHi : design.title}
              </h3>
              <p className="text-[11px] text-amber-300/70">{design.aspectRatio} Ratio · Diwali 2026</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleFav}
              className={`p-2 rounded-xl transition-colors ${
                fav ? 'bg-rose-500/20 text-rose-400' : 'text-amber-200/80 hover:bg-white/10'
              }`}
              title="Favorite"
            >
              <Heart className={`w-4 h-4 ${fav ? 'fill-rose-400 text-rose-400' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-amber-200/80 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Card Canvas Visual Preview with 3D Tilt */}
        <div className="p-4 sm:p-5">
          <Card3D maxTilt={14} glare={true} className="cursor-pointer">
            <div className={`p-6 sm:p-8 rounded-2xl bg-gradient-to-br ${design.previewGradient} border border-amber-400/30 text-center relative overflow-hidden select-none transform-style-3d shadow-xl`}>
              <div className="text-5xl mb-3 animate-flame filter drop-shadow-[0_0_15px_#f59e0b] translate-z-40">🪔</div>
              <span className="text-xs font-bold text-amber-300 tracking-widest uppercase block mb-1 translate-z-10">
                ॥ शुभ दीपावली २०२६ ॥
              </span>
              <h2 className="text-2xl font-black text-amber-100 font-festive mb-3 leading-tight drop-shadow-md translate-z-30 text-3d-gold">
                {lang === 'hi' ? design.titleHi : design.title}
              </h2>
              <div className="p-4 rounded-2xl bg-black/40 border border-amber-500/20 backdrop-blur-sm max-w-sm mx-auto mb-4 translate-z-20">
                <p className="text-sm sm:text-base text-amber-100/95 font-hindi leading-relaxed">
                  "{wish}"
                </p>
              </div>
              <div className="text-xs text-amber-300/80 font-medium translate-z-10 flex items-center justify-center gap-1">
                <Box className="w-3.5 h-3.5 text-amber-400" />
                <span>3D Interactive Hologram · संवत 2083</span>
              </div>
            </div>
          </Card3D>
        </div>

        {/* Action Controls & Sharing */}
        <div className="p-5 space-y-4 bg-[#140626]">
          {/* Main Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                onClose();
                onCustomize(design);
              }}
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-purple-950 font-bold text-sm shadow-md hover:brightness-110 active:scale-95 transition-all"
            >
              <Wand2 className="w-4 h-4" />
              <span>{lang === 'hi' ? 'नाम जोड़ें / कस्टमाइज़' : 'Customize with Name'}</span>
            </button>

            <button
              onClick={handleCopyWish}
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-amber-500/30 text-amber-200 font-semibold text-sm transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? (lang === 'hi' ? 'कॉपी हुआ!' : 'Copied!') : (lang === 'hi' ? 'विश कॉपी करें' : 'Copy Message')}</span>
            </button>
          </div>

          {/* Social Share Grid */}
          <div>
            <div className="flex items-center justify-between text-xs text-amber-300/70 mb-2 font-medium">
              <span>{lang === 'hi' ? 'दोस्तों व परिजनों को भेजें:' : 'Direct Share to Friends & Family:'}</span>
              <button
                onClick={() => setShowQr(!showQr)}
                className="hover:text-amber-200 flex items-center gap-1"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>{showQr ? 'Hide QR' : 'Scan QR'}</span>
              </button>
            </div>

            {/* QR Code view */}
            {showQr && (
              <div className="p-4 rounded-xl bg-black/40 border border-amber-500/30 text-center mb-3">
                <p className="text-xs text-amber-200/80 mb-2">
                  {lang === 'hi' ? 'मोबाइल से स्कैन करके कार्ड देखें' : 'Scan to view greeting on mobile'}
                </p>
                <div className="inline-block p-2 bg-white rounded-xl shadow-lg">
                  {/* Standard QR Code SVG representation */}
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(shareUrl)}`}
                    alt="Diwali Greeting QR Code"
                    className="w-32 h-32"
                    loading="lazy"
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-4 gap-2">
              <button
                onClick={() => shareToWhatsApp(shareOptions)}
                className="py-2.5 px-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex flex-col items-center gap-1 transition-colors"
              >
                <span className="text-base">💬</span>
                <span>WhatsApp</span>
              </button>

              <button
                onClick={() => shareToFacebook(shareOptions)}
                className="py-2.5 px-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 text-blue-300 text-xs font-semibold flex flex-col items-center gap-1 transition-colors"
              >
                <span className="text-base">🌐</span>
                <span>Facebook</span>
              </button>

              <button
                onClick={() => shareToTwitter(shareOptions)}
                className="py-2.5 px-2 rounded-xl bg-sky-600/20 hover:bg-sky-600/30 border border-sky-500/30 text-sky-300 text-xs font-semibold flex flex-col items-center gap-1 transition-colors"
              >
                <span className="text-base">🐦</span>
                <span>X (Twitter)</span>
              </button>

              <button
                onClick={() => shareToTelegram(shareOptions)}
                className="py-2.5 px-2 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex flex-col items-center gap-1 transition-colors"
              >
                <span className="text-base">✈️</span>
                <span>Telegram</span>
              </button>
            </div>
          </div>

          {/* Quick Copy Link Row */}
          <div className="flex items-center gap-2 pt-2 border-t border-amber-500/15">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="flex-1 bg-black/40 border border-amber-500/20 rounded-xl px-3 py-2 text-xs text-amber-200/80 font-mono truncate focus:outline-none"
            />
            <button
              onClick={handleCopyLink}
              className="px-3 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-semibold transition-colors shrink-0"
            >
              {lang === 'hi' ? 'लिंक कॉपी' : 'Copy Link'}
            </button>
            <button
              onClick={() => shareToNative(shareOptions)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-amber-300 transition-colors shrink-0"
              title="More share options"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
