import React, { useEffect, useState } from 'react';
import { Sparkles, Share2, Wand2, ArrowLeft, Download, Check, Copy, Box } from 'lucide-react';
import confetti from 'canvas-confetti';
import { festiveAudio } from '../utils/audio';
import { shareToWhatsApp, shareToFacebook, shareToTwitter, copyToClipboard } from '../utils/share';
import { Card3D } from './Card3D';

interface PublicGreetingViewProps {
  slug: string;
  lang: 'hi' | 'en';
  onBack: () => void;
  onCreateNew: () => void;
  onToast: (msg: string) => void;
}

interface CustomCardData {
  id: string;
  slug: string;
  senderName: string;
  recipientName: string;
  businessName?: string;
  messageText: string;
  language: 'hi' | 'en';
  aspectRatio: string;
  theme?: string;
  createdAt: string;
}

export const PublicGreetingView: React.FC<PublicGreetingViewProps> = ({
  slug,
  lang,
  onBack,
  onCreateNew,
  onToast,
}) => {
  const [card, setCard] = useState<CustomCardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Fetch custom card from API
    async function loadCard() {
      try {
        const res = await fetch(`/api/wishes/${slug}`);
        if (res.ok) {
          const data = await res.json();
          setCard(data.card);
        } else {
          // Fallback demo data
          setCard({
            id: slug,
            slug,
            senderName: 'शुभचिंतक',
            recipientName: 'सम्मानित मित्र',
            messageText: 'दीपावली का यह पावन पर्व आपके जीवन में अखंड सुख, शांति और समृद्धि लाए!',
            language: 'hi',
            aspectRatio: '1:1',
            createdAt: new Date().toISOString(),
          });
        }
      } catch {
        // Fallback
        setCard({
          id: slug,
          slug,
          senderName: 'शुभचिंतक',
          recipientName: 'सम्मानित मित्र',
          messageText: 'दीपावली का यह पावन पर्व आपके जीवन में अखंड सुख, शांति और समृद्धि लाए!',
          language: 'hi',
          aspectRatio: '1:1',
          createdAt: new Date().toISOString(),
        });
      } finally {
        setLoading(false);
      }
    }

    loadCard();

    // Trigger joyous festive fireworks celebration on arrival
    festiveAudio.playTempleChime();
    confetti({
      particleCount: 120,
      spread: 90,
      origin: { y: 0.5 },
      colors: ['#f59e0b', '#fbbf24', '#f43f5e', '#a855f7'],
    });
  }, [slug]);

  if (loading) {
    return (
      <div className="py-20 text-center">
        <div className="w-10 h-10 border-4 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-amber-200 font-festive">
          {lang === 'hi' ? 'शुभकामना कार्ड लोड हो रहा है...' : 'Loading Diwali greeting...'}
        </p>
      </div>
    );
  }

  if (!card) {
    return (
      <div className="py-20 text-center max-w-md mx-auto px-4">
        <span className="text-5xl mb-4 block">🪔</span>
        <h2 className="text-xl font-bold text-amber-200 mb-2">कार्ड नहीं मिला / Card Not Found</h2>
        <button
          onClick={onCreateNew}
          className="mt-4 px-5 py-2.5 rounded-xl bg-amber-500 text-purple-950 font-bold"
        >
          {lang === 'hi' ? 'नया कार्ड बनाएं' : 'Create New Card'}
        </button>
      </div>
    );
  }

  const shareUrl = window.location.href;
  const shareDetails = {
    title: `${card.senderName} की ओर से दीपावली संदेश`,
    text: `🪔 दीपावली 2026 की हार्दिक शुभकामनाएँ!\n\n"${card.messageText}"\n\n- सप्रेम: ${card.senderName}`,
    url: shareUrl,
  };

  return (
    <div className="py-8 sm:py-14 max-w-3xl mx-auto px-4 sm:px-6">
      {/* Back button */}
      <div className="mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#17082a] border border-amber-500/20 text-amber-200 hover:text-white transition-colors text-sm font-semibold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{lang === 'hi' ? 'मुख्य पृष्ठ पर जाएँ' : 'Back to Home'}</span>
        </button>
      </div>

      {/* Main Greeting Display Card with 3D Holographic Tilt */}
      <Card3D maxTilt={12} glare={true} className="cursor-pointer mb-8">
        <div className="relative rounded-3xl bg-gradient-to-br from-[#2f104e] via-[#1a0730] to-[#0d031a] border-2 border-amber-400/50 p-6 sm:p-10 shadow-2xl gold-glow text-center overflow-hidden transform-style-3d">
          {/* Top Floating Lamps */}
          <div className="flex items-center justify-between mb-4 text-xs font-bold text-amber-300 font-hindi translate-z-20">
            <span>॥ शुभ लाभ ॥</span>
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              दीपावली २०८३ · 3D
            </span>
            <span>॥ श्री गणेशाय नमः ॥</span>
          </div>

          {/* Realistic 3D Diya */}
          <div className="text-5xl sm:text-6xl my-4 animate-flame filter drop-shadow-[0_0_20px_#f59e0b] translate-z-40">
            🪔
          </div>

          {/* Recipient Line */}
          {card.recipientName && (
            <h3 className="text-lg sm:text-xl font-bold text-amber-200 font-hindi mb-2 translate-z-20">
              {lang === 'hi' ? `प्रिय ${card.recipientName}` : `Dear ${card.recipientName}`}
            </h3>
          )}

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-5xl font-black text-gold-gradient font-festive mb-4 leading-tight translate-z-30 text-3d-gold">
            दीपावली की हार्दिक शुभकामनाएँ
          </h1>
          <h2 className="text-base sm:text-xl font-bold text-amber-300 font-royal tracking-widest mb-6 uppercase translate-z-20 drop-shadow">
            Happy Diwali 2026
          </h2>

          {/* Wish Message Box */}
          <div className="max-w-lg mx-auto p-5 sm:p-6 rounded-2xl bg-black/50 border border-amber-500/30 backdrop-blur-md mb-8 translate-z-30 shadow-lg">
            <p className="text-base sm:text-xl text-amber-50 font-hindi leading-relaxed">
              "{card.messageText}"
            </p>
          </div>

          {/* Sender Signoff */}
          <div className="space-y-1 mb-8 translate-z-20">
            <span className="text-xs text-amber-300/80 font-hindi block uppercase tracking-wider">
              {lang === 'hi' ? 'सस्नेह मंगलकामनाएँ' : 'Warmest Greetings From'}
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-200 font-festive text-3d-gold">
              {card.senderName}
            </div>
            {card.businessName && (
              <div className="text-sm font-semibold text-amber-300 font-hindi">
                ॥ शुभ लाभ ॥ {card.businessName}
              </div>
            )}
          </div>

          {/* Action Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-amber-500/20 translate-z-30">
            <button
              onClick={onCreateNew}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-purple-950 font-extrabold text-sm sm:text-base shadow-xl hover:brightness-110 active:scale-95 transition-all"
            >
              <Wand2 className="w-5 h-5 stroke-[2.5]" />
              <span>{lang === 'hi' ? 'अपना कार्ड भी बनाएं' : 'Create Your Own Greeting'}</span>
            </button>

            <button
              onClick={() => shareToWhatsApp(shareDetails)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md transition-colors"
            >
              <span>💬 WhatsApp शेयर</span>
            </button>

            <button
              onClick={async () => {
                const text = `🪔 ${card.senderName} ने आपके लिए दीपोत्सव कार्ड भेजा है:\n\n"${card.messageText}"\n\n✨ देखें: ${shareUrl}`;
                await copyToClipboard(text);
                setCopied(true);
                onToast(lang === 'hi' ? 'शुभकामना कॉपी हो गई!' : 'Copied wish!');
                setTimeout(() => setCopied(false), 2000);
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-amber-500/30 text-amber-200 font-semibold text-sm transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'कॉपी हुआ' : 'मैसेज कॉपी'}</span>
            </button>
          </div>
        </div>
      </Card3D>
    </div>
  );
};
