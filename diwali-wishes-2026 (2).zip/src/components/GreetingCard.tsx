import React, { useState } from 'react';
import { Heart, Copy, Share2, Wand2, Eye, Check, Volume2, Music, Sparkles } from 'lucide-react';
import { GreetingDesign } from '../types/greeting';
import { isFavorite, toggleFavorite } from '../utils/storage';
import { copyToClipboard, shareToWhatsApp } from '../utils/share';
import { Card3D } from './Card3D';
import { festiveAudio } from '../utils/audio';

interface GreetingCardProps {
  design: GreetingDesign;
  lang: 'hi' | 'en';
  onPreview: (design: GreetingDesign) => void;
  onCustomize: (design: GreetingDesign) => void;
  onToast: (msg: string) => void;
}

export const GreetingCard: React.FC<GreetingCardProps> = ({
  design,
  lang,
  onPreview,
  onCustomize,
  onToast,
}) => {
  const [favorite, setFavorite] = useState(isFavorite(design.id));
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const handlePlayCardAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsPlayingAudio(true);
    // Alternate or choose sound based on card design
    const idNum = parseInt(design.id.replace(/\D/g, '') || '1', 10);
    if (idNum % 3 === 0) {
      festiveAudio.playShankhNaad();
      onToast('🪔 पावन शंख नाद (Holy Shankh Sound)');
    } else if (idNum % 3 === 1) {
      festiveAudio.playDiwaliSongMelody();
      onToast('🎵 दीपावली पावन आरती धुन (Diwali Aarti Song)');
    } else {
      festiveAudio.playCrackersSound();
      onToast('🎆 दीपावली पटाखे व फुलझड़ी ध्वनि (Sparkler Crackers Sound)');
    }
    setTimeout(() => setIsPlayingAudio(false), 3000);
  };

  const handleToggleFav = (e: React.MouseEvent) => {
    e.stopPropagation();
    const next = toggleFavorite(design.id);
    setFavorite(next);
    onToast(
      next
        ? (lang === 'hi' ? 'पसंदीदा में जोड़ा गया ❤️' : 'Added to favorites ❤️')
        : (lang === 'hi' ? 'पसंदीदा से हटाया गया' : 'Removed from favorites')
    );
  };

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const wish = lang === 'hi' ? design.hindiWish : design.englishWish;
    const fullText = `🪔 ${design.titleHi}\n\n"${wish}"\n\n✨ Happy Diwali 2026!`;
    const ok = await copyToClipboard(fullText);
    if (ok) {
      setCopied(true);
      onToast(lang === 'hi' ? 'शुभकामना कॉपी हो गई! ✅' : 'Greeting text copied! ✅');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    const wish = lang === 'hi' ? design.hindiWish : design.englishWish;
    shareToWhatsApp({
      title: design.title,
      text: `✨ ${design.titleHi} ✨\n\n"${wish}"\n\n🪔 शुभ दीपावली 2026!`,
      url: window.location.origin + `/wishes/${design.slug}`,
      cardId: design.id,
    });
  };

  // Determine Aspect Ratio Height
  const ratioClasses = {
    '1:1': 'aspect-square',
    '9:16': 'aspect-[9/16]',
    '4:5': 'aspect-[4/5]',
    '16:9': 'aspect-[16/9]',
  }[design.aspectRatio];

  return (
    <Card3D maxTilt={10} glare={true} className="w-full">
      <div
        onClick={() => onPreview(design)}
        className="group relative flex flex-col rounded-2xl bg-gradient-to-b from-[#1f0d36] to-[#120721] border border-amber-500/25 overflow-hidden shadow-lg hover:border-amber-400/60 hover:shadow-2xl hover:shadow-amber-500/20 transition-all duration-300 cursor-pointer transform-style-3d"
      >
        {/* Decorative Card Canvas Preview Area */}
        <div className={`relative w-full ${ratioClasses} overflow-hidden bg-gradient-to-br ${design.previewGradient} flex flex-col justify-between p-4 sm:p-5 select-none transform-style-3d`}>
          {/* Subtle Rangoli Vector Overlay */}
          <div className="absolute inset-0 opacity-10 pointer-events-none flex items-center justify-center">
            <svg viewBox="0 0 100 100" className="w-full h-full fill-amber-300">
              <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" />
              <polygon points="50,5 63,38 95,50 63,62 50,95 38,62 5,50 38,38" fill="none" stroke="currentColor" strokeWidth="1" />
            </svg>
          </div>

          {/* Top bar inside card */}
          <div className="relative z-10 flex items-center justify-between translate-z-20">
            <span className="text-[11px] font-bold text-amber-300/90 tracking-widest font-hindi drop-shadow">
              ॥ शुभ दीपावली ॥
            </span>
            <div className="flex items-center gap-1.5">
              {/* Sound Effect / Song Button */}
              <button
                onClick={handlePlayCardAudio}
                className={`p-1.5 sm:p-2 rounded-full backdrop-blur-md transition-all active:scale-90 ${
                  isPlayingAudio
                    ? 'bg-amber-400 text-purple-950 shadow-lg shadow-amber-400/50 animate-bounce'
                    : 'bg-black/40 text-amber-300 hover:text-white border border-amber-500/30'
                }`}
                title="Play Diwali Song / Sound Effect"
              >
                <Volume2 className={`w-3.5 h-3.5 ${isPlayingAudio ? 'animate-pulse' : ''}`} />
              </button>
              <button
                onClick={handleToggleFav}
                className={`p-1.5 sm:p-2 rounded-full backdrop-blur-md transition-transform active:scale-90 ${
                  favorite
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                    : 'bg-black/30 text-amber-200/80 hover:text-white border border-white/10'
                }`}
                title="Add to Favorites"
              >
                <Heart className={`w-3.5 h-3.5 ${favorite ? 'fill-rose-400 text-rose-400' : ''}`} />
              </button>
            </div>
          </div>

          {/* Card Center: 3D Popout Diya + Wish Text */}
          <div className="relative z-10 my-auto text-center px-1 transform-style-3d translate-z-30">
            {/* Animated 3D Diya popping out */}
            <div className="text-3xl sm:text-4xl mb-2 animate-flame filter drop-shadow-[0_0_15px_#f59e0b] translate-z-40">
              🪔
            </div>

            <h3 className="text-base sm:text-lg font-black text-amber-100 font-festive line-clamp-1 mb-1 group-hover:text-amber-300 transition-colors translate-z-20 text-3d-gold">
              {lang === 'hi' ? design.titleHi : design.title}
            </h3>

            <p className="text-xs sm:text-sm text-amber-200/90 font-hindi line-clamp-3 leading-relaxed drop-shadow-sm translate-z-10">
              "{lang === 'hi' ? design.hindiWish : design.englishWish}"
            </p>
          </div>

          {/* Bottom card motif & ratio indicator */}
          <div className="relative z-10 flex items-center justify-between text-[11px] text-amber-300/80 font-mono translate-z-10">
            <span className="flex items-center gap-1 font-hindi text-amber-200/70">
              ✨ संवत 2083
            </span>
            <span className="px-1.5 py-0.5 rounded bg-black/40 border border-amber-500/20 text-[10px]">
              {design.aspectRatio}
            </span>
          </div>

          {/* Hover Action Overlay */}
          <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-3 translate-z-40">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onPreview(design);
              }}
              className="p-2.5 rounded-xl bg-amber-500 text-purple-950 font-bold hover:brightness-110 shadow-lg active:scale-95 transition-all"
              title="Preview Card"
            >
              <Eye className="w-5 h-5" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onCustomize(design);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 text-purple-950 font-extrabold text-xs shadow-lg hover:brightness-110 active:scale-95 transition-all"
              title="Customize with your name"
            >
              <Wand2 className="w-4 h-4" />
              <span>{lang === 'hi' ? 'नाम लिखें' : 'Add Name'}</span>
            </button>
          </div>
        </div>

        {/* Card Info & Clean Unboxed Metadata */}
        <div className="p-3.5 flex flex-col gap-2.5 bg-[#17082a] translate-z-10">
          <div className="flex items-center justify-between text-xs text-amber-200/60">
            <span>{design.tags[0] || 'diwali'}</span>
            <span aria-hidden="true">·</span>
            <span>{design.likes ? `${design.likes} likes` : 'Popular'}</span>
            <span aria-hidden="true">·</span>
            <span>2026</span>
          </div>

          {/* Bottom Action Buttons */}
          <div className="flex items-center gap-1.5 pt-1 border-t border-amber-500/15">
            <button
              onClick={handleCopy}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-white/5 hover:bg-white/10 text-amber-200 text-xs font-semibold transition-colors"
              title="Copy Wish Text"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? (lang === 'hi' ? 'कॉपी हुआ' : 'Copied') : (lang === 'hi' ? 'मैसेज कॉपी' : 'Copy')}</span>
            </button>

            {/* Sound Effects & Songs Button */}
            <button
              onClick={handlePlayCardAudio}
              className={`p-2 rounded-lg border transition-all ${
                isPlayingAudio
                  ? 'bg-amber-500 text-purple-950 border-amber-400 animate-pulse'
                  : 'bg-amber-500/10 hover:bg-amber-500/25 text-amber-300 border-amber-500/25'
              }`}
              title="Play Festive Sound / Song"
            >
              <Music className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={handleWhatsApp}
              className="p-2 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 transition-colors"
              title="Share to WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onCustomize(design);
              }}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-bold transition-colors"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'एडिट करें' : 'Edit'}</span>
            </button>
          </div>
        </div>
      </div>
    </Card3D>
  );
};
