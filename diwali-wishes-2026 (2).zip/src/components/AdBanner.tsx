import React, { useEffect } from 'react';
import { ExternalLink, Sparkles } from 'lucide-react';
import { MonetizationSettings } from '../types/greeting';

interface AdBannerProps {
  settings?: MonetizationSettings | null;
  slot?: 'top' | 'middle' | 'bottom' | 'card-finish';
  lang?: 'hi' | 'en';
}

export const AdBanner: React.FC<AdBannerProps> = ({
  settings,
  slot = 'middle',
  lang = 'hi',
}) => {
  useEffect(() => {
    // If Google Ads script is enabled and present, trigger push
    try {
      if (settings?.googleAdEnabled && typeof window !== 'undefined') {
        const win = window as unknown as { adsbygoogle?: unknown[] };
        if (win.adsbygoogle) {
          win.adsbygoogle.push({});
        }
      }
    } catch {
      // Ad blocker or script not yet loaded
    }
  }, [settings]);

  if (!settings) return null;

  const { googleAdEnabled, googleAdClient, googleAdSlot, adsterraEnabled, adsterraDirectLink } = settings;

  // If neither is enabled, return null
  if (!googleAdEnabled && !adsterraEnabled) return null;

  return (
    <div className="w-full my-6 max-w-5xl mx-auto px-4">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#1c0833] via-[#240b40] to-[#17062b] border border-amber-500/20 p-4 shadow-lg gold-glow-sm">
        {/* Subtle Ad label */}
        <div className="flex items-center justify-between text-[10px] text-amber-300/60 uppercase tracking-widest mb-2 font-mono">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            {lang === 'hi' ? 'प्रायोजित / SPONSORED' : 'SPONSORED PARTNER'}
          </span>
          <span>FESTIVE DEALS</span>
        </div>

        {/* Google AdSense Area */}
        {googleAdEnabled && googleAdClient && (
          <div className="text-center my-2 min-h-[90px] flex flex-col items-center justify-center bg-black/30 rounded-xl border border-amber-500/10 p-2">
            <ins
              className="adsbygoogle"
              style={{ display: 'block', width: '100%', height: '90px' }}
              data-ad-client={googleAdClient}
              data-ad-slot={googleAdSlot || '1234567890'}
              data-ad-format="auto"
              data-full-width-responsive="true"
            />
            {/* Fallback Display if ad blocker or pending review */}
            <div className="text-xs text-amber-200/60 py-2">
              <span className="text-amber-400 font-bold block">
                {lang === 'hi' ? '✨ दीपोत्सव 2026 विशेष विज्ञापन ✨' : '✨ Diwali Festive Verified Partner ✨'}
              </span>
              <span className="text-[11px]">Google AdSense Responsive Unit ({googleAdSlot})</span>
            </div>
          </div>
        )}

        {/* Adsterra (Sterior) Direct Link Callout Button */}
        {adsterraEnabled && adsterraDirectLink && (
          <div className="mt-3 pt-3 border-t border-amber-500/15 flex flex-col sm:flex-row items-center justify-between gap-3 bg-amber-500/10 p-3 rounded-xl">
            <div className="text-center sm:text-left">
              <span className="text-xs font-bold text-amber-200 font-hindi block">
                {lang === 'hi'
                  ? '🎁 दीपावली महा बचत ऑफर व उपहार बोनस प्राप्त करें!'
                  : '🎁 Claim Your Diwali Mega Festive Bonus & Offers!'}
              </span>
              <span className="text-[11px] text-amber-300/70">
                {lang === 'hi'
                  ? 'एक्सक्लूसिव फेस्टिव बोनस, कूपन और कैशबैक के लिए टैप करें'
                  : 'Tap below to explore certified festive bonuses & offers'}
              </span>
            </div>

            <a
              href={adsterraDirectLink}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-purple-950 font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5 shrink-0"
            >
              <span>{lang === 'hi' ? 'ऑफर देखें (View Offer)' : 'Unlock Offer'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
