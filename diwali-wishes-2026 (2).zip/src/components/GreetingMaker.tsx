import React, { useState, useRef, useEffect } from 'react';
import {
  AspectRatioType,
  CardTheme,
  GreetingDesign,
  PlacedSticker,
} from '../types/greeting';
import { READY_WISHES } from '../data/wishes';
import { DECORATIVE_STICKERS } from '../data/stickers';
import {
  renderGreetingCanvas,
  exportCanvasImage,
  getCanvasDimensions,
} from '../utils/canvasRenderer';
import { saveCustomCard } from '../utils/storage';
import {
  shareToWhatsApp,
  shareToFacebook,
  shareToTwitter,
  shareToTelegram,
  copyToClipboard,
  shareToNative,
} from '../utils/share';
import {
  Download,
  Share2,
  Wand2,
  Sparkles,
  Image as ImageIcon,
  Check,
  Type,
  Palette,
  Smile,
  Maximize2,
  RotateCcw,
  Upload,
  Trash2,
  ArrowLeft,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { festiveAudio } from '../utils/audio';
import { Card3D } from './Card3D';
import { Box } from 'lucide-react';

interface GreetingMakerProps {
  initialDesign?: GreetingDesign | null;
  lang: 'hi' | 'en';
  onBack: () => void;
  onToast: (msg: string) => void;
}

export const GreetingMaker: React.FC<GreetingMakerProps> = ({
  initialDesign,
  lang,
  onBack,
  onToast,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Form States
  const [senderName, setSenderName] = useState<string>(
    lang === 'hi' ? 'राजेश एवं समस्त परिवार' : 'Rajesh & Family'
  );
  const [recipientName, setRecipientName] = useState<string>(
    lang === 'hi' ? 'प्रिय मित्रगण' : 'Dear Friends'
  );
  const [businessName, setBusinessName] = useState<string>('');
  const [messageText, setMessageText] = useState<string>(
    initialDesign
      ? lang === 'hi'
        ? initialDesign.hindiWish
        : initialDesign.englishWish
      : 'दीयों की रोशनी से झिलमिलाता आंगन हो, खुशियों की बहार हो। दीपावली 2026 की हार्दिक शुभकामनाएँ!'
  );
  const [aspectRatio, setAspectRatio] = useState<AspectRatioType>(
    initialDesign?.aspectRatio || '1:1'
  );
  const [theme, setTheme] = useState<CardTheme>(initialDesign?.theme || 'golden-amber');
  const [cardLang, setCardLang] = useState<'hi' | 'en'>(lang);

  // Styling States
  const [fontFamily, setFontFamily] = useState<string>('Noto Sans Devanagari');
  const [fontSizeScale, setFontSizeScale] = useState<number>(1.0);
  const [textColor, setTextColor] = useState<string>('#fef08a');
  const [textShadow, setTextShadow] = useState<boolean>(true);
  const [textAlign, setTextAlign] = useState<'center' | 'left' | 'right'>('center');

  // Photo States
  const [userPhotoImg, setUserPhotoImg] = useState<HTMLImageElement | null>(null);
  const [photoShape, setPhotoShape] = useState<'circle' | 'square' | 'rounded'>('circle');
  const [photoScale, setPhotoScale] = useState<number>(1.0);
  const [photoY, setPhotoY] = useState<number>(75);

  // Stickers / Overlays
  const [stickers, setStickers] = useState<PlacedSticker[]>([]);

  // Export & Share State
  const [exportedImage, setExportedImage] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [shareableUrl, setShareableUrl] = useState<string>('');
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [is3DMode, setIs3DMode] = useState<boolean>(true);

  // Quick Preset Selector
  const handleSelectPreset = (text: string) => {
    setMessageText(text);
    onToast(lang === 'hi' ? 'संदेश लागू किया गया!' : 'Message preset applied!');
  };

  // Photo Upload Handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      onToast(lang === 'hi' ? 'कृपया केवल छवि (Image) फ़ाइल चुनें' : 'Please select an image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        setUserPhotoImg(img);
        onToast(lang === 'hi' ? 'फोटो सफलतापूर्वक अपलोड हुई!' : 'Photo added successfully!');
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setUserPhotoImg(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    onToast(lang === 'hi' ? 'फोटो हटा दी गई' : 'Photo removed');
  };

  // Sticker Placement
  const handleAddSticker = (stickerId: string) => {
    const newSticker: PlacedSticker = {
      id: 'stk-' + Date.now(),
      stickerId,
      x: 50,
      y: 92,
      scale: 1,
    };
    setStickers([...stickers, newSticker]);
    onToast(lang === 'hi' ? 'तोरण / दीया जोड़ा गया!' : 'Sticker added!');
  };

  const handleClearStickers = () => {
    setStickers([]);
  };

  // Live Canvas Render on state change
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    renderGreetingCanvas({
      canvas,
      aspectRatio,
      theme,
      recipientName,
      senderName,
      businessName,
      messageText,
      language: cardLang,
      fontFamily,
      fontSize: fontSizeScale,
      textColor,
      textShadow,
      textAlign,
      userPhoto: userPhotoImg,
      photoShape,
      photoPosition: { x: 50, y: photoY, scale: photoScale },
      stickers,
    });
  }, [
    aspectRatio,
    theme,
    recipientName,
    senderName,
    businessName,
    messageText,
    cardLang,
    fontFamily,
    fontSizeScale,
    textColor,
    textShadow,
    textAlign,
    userPhotoImg,
    photoShape,
    photoScale,
    photoY,
    stickers,
  ]);

  // Export High-Res Image & Generate Public Link
  const handleExport = async (format: 'png' | 'jpeg' = 'png') => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    setIsExporting(true);
    try {
      // Ensure all fonts are ready
      if (document.fonts) await document.fonts.ready;

      // Re-render to ensure crispness
      await renderGreetingCanvas({
        canvas,
        aspectRatio,
        theme,
        recipientName,
        senderName,
        businessName,
        messageText,
        language: cardLang,
        fontFamily,
        fontSize: fontSizeScale,
        textColor,
        textShadow,
        textAlign,
        userPhoto: userPhotoImg,
        photoShape,
        photoPosition: { x: 50, y: photoY, scale: photoScale },
        stickers,
      });

      const dataUrl = exportCanvasImage(canvas, format);
      setExportedImage(dataUrl);

      // Save custom card to backend API
      try {
        const response = await fetch('/api/greetings/create-custom', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            senderName,
            recipientName,
            businessName,
            messageText,
            language: cardLang,
            baseDesignId: initialDesign?.id || 'hw-1',
            aspectRatio,
            theme,
          }),
        });

        if (response.ok) {
          const resData = await response.json();
          if (resData.shareUrl) {
            setShareableUrl(resData.shareUrl);
          }
          if (resData.card) {
            saveCustomCard(resData.card);
          }
        }
      } catch {
        // Fallback local URL
        const fallbackUrl = `${window.location.origin}/wishes/custom-diwali-${Date.now().toString(36)}`;
        setShareableUrl(fallbackUrl);
      }

      setIsSaved(true);
      festiveAudio.playSparkle();
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 },
        colors: ['#f59e0b', '#fbbf24', '#e11d48', '#8b5cf6'],
      });

      onToast(
        lang === 'hi'
          ? 'ग्रीटिंग कार्ड तैयार है! अब डाउनलोड या शेयर करें 🪔'
          : 'Greeting card ready! Download or share now 🪔'
      );
    } catch {
      onToast(lang === 'hi' ? 'एक्सपोर्ट करने में त्रुटि' : 'Export failed');
    } finally {
      setIsExporting(false);
    }
  };

  // Direct Download Trigger
  const handleDownloadFile = () => {
    if (!exportedImage) return;
    const a = document.createElement('a');
    a.href = exportedImage;
    const cleanName = (senderName || 'diwali-card').replace(/\s+/g, '-').toLowerCase();
    a.download = `diwali-2026-${cleanName}.${aspectRatio === '9:16' ? 'status.png' : 'card.png'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    onToast(lang === 'hi' ? 'डाउनलोड शुरू हो गया!' : 'Download started!');
  };

  const activeShareUrl = shareableUrl || window.location.href;
  const shareDetails = {
    title: `${senderName} की ओर से दीपावली की शुभकामनाएँ`,
    text: `🪔 दीपावली 2026 की हार्दिक शुभकामनाएँ!\n\n"${messageText}"\n\n- सप्रेम: ${senderName}`,
    url: activeShareUrl,
  };

  return (
    <div className="py-6 sm:py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#17082a] border border-amber-500/20 text-amber-200 hover:text-white transition-colors text-sm font-semibold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{lang === 'hi' ? 'वापस गैलरी में जाएँ' : 'Back to Gallery'}</span>
        </button>

        <div className="text-right">
          <h2 className="text-lg sm:text-2xl font-black text-amber-100 font-festive">
            {lang === 'hi' ? 'पर्सनल दीपावली कार्ड मेकर' : 'Personal Greeting Maker'}
          </h2>
          <p className="text-xs text-amber-300/70 font-hindi">
            {lang === 'hi' ? 'अपना नाम, फोटो व संदेश जोड़कर HD कार्ड बनाएं' : 'Add your name, photo, and customized wish'}
          </p>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Canvas Preview (lg:col-span-6) */}
        <div className="lg:col-span-6 flex flex-col items-center">
          <div className="w-full max-w-md p-3 sm:p-4 rounded-3xl bg-[#140624] border border-amber-500/30 shadow-2xl gold-glow sticky top-24">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-amber-500/15 text-xs text-amber-200/80">
              <span className="font-bold flex items-center gap-1.5 text-amber-300">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                {lang === 'hi' ? 'लाइव प्रीव्यू (Live Preview)' : 'Live Preview'}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIs3DMode(!is3DMode)}
                  className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-bold border transition-colors ${
                    is3DMode
                      ? 'bg-amber-500/20 text-amber-300 border-amber-400/50'
                      : 'bg-black/30 text-amber-200/60 border-transparent hover:text-white'
                  }`}
                  title="Toggle 3D Tilt View"
                >
                  <Box className="w-3 h-3 text-amber-400" />
                  <span>{is3DMode ? '3D Tilt ON' : '3D Tilt OFF'}</span>
                </button>
                <span className="font-mono text-[11px] bg-black/40 px-2 py-0.5 rounded border border-amber-500/20">
                  {aspectRatio}
                </span>
              </div>
            </div>

            {/* Canvas Container with 3D Card Support */}
            {is3DMode ? (
              <Card3D maxTilt={14} glare={true} className="w-full">
                <div className="relative w-full flex items-center justify-center bg-black/60 rounded-2xl overflow-hidden border border-amber-500/30 shadow-2xl max-h-[540px]">
                  <canvas
                    ref={canvasRef}
                    className="w-full h-auto object-contain max-h-[520px] rounded-xl shadow-lg"
                  />
                </div>
              </Card3D>
            ) : (
              <div className="relative w-full flex items-center justify-center bg-black/50 rounded-2xl overflow-hidden border border-amber-500/20 max-h-[540px]">
                <canvas
                  ref={canvasRef}
                  className="w-full h-auto object-contain max-h-[520px] rounded-xl shadow-lg"
                />
              </div>
            )}

            {/* Quick Canvas Format Quick Switch */}
            <div className="flex items-center justify-center gap-1.5 mt-3 pt-3 border-t border-amber-500/15">
              {[
                { r: '1:1', label: '1:1 Square' },
                { r: '4:5', label: '4:5 Card' },
                { r: '9:16', label: '9:16 Status/Story' },
                { r: '16:9', label: '16:9 Banner' },
              ].map((item) => (
                <button
                  key={item.r}
                  onClick={() => setAspectRatio(item.r as AspectRatioType)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    aspectRatio === item.r
                      ? 'bg-amber-500 text-purple-950 font-bold'
                      : 'bg-black/30 text-amber-200/70 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Main Generate / Export Button */}
            <div className="mt-4">
              <button
                onClick={() => handleExport('png')}
                disabled={isExporting}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-purple-950 font-extrabold text-sm sm:text-base shadow-xl hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 gold-glow"
              >
                {isExporting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-purple-950 border-t-transparent rounded-full animate-spin" />
                    <span>{lang === 'hi' ? 'कार्ड तैयार किया जा रहा है...' : 'Generating HD Card...'}</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5 stroke-[2.5]" />
                    <span>{lang === 'hi' ? 'HD कार्ड एक्सपोर्ट करें' : 'Export High-Res Card'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Exported Result Dialog / Download Box */}
          {exportedImage && (
            <div className="w-full max-w-md mt-6 p-5 rounded-3xl bg-[#1c0a36] border border-amber-400/50 shadow-2xl gold-glow animate-fade-in">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-3">
                <Check className="w-5 h-5" />
                <span>{lang === 'hi' ? 'कार्ड सफलतापूर्वक तैयार हुआ!' : 'Card generated successfully!'}</span>
              </div>

              <div className="grid grid-cols-2 gap-2.5 mb-4">
                <button
                  onClick={handleDownloadFile}
                  className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold text-sm shadow-md hover:brightness-110 active:scale-95 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'डाउनलोड PNG' : 'Download PNG'}</span>
                </button>

                <button
                  onClick={() => {
                    shareToWhatsApp(shareDetails);
                  }}
                  className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl bg-emerald-600 text-white font-bold text-sm shadow-md hover:brightness-110 active:scale-95 transition-all"
                >
                  <span>💬 WhatsApp</span>
                </button>
              </div>

              {/* Share links */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                <button
                  onClick={() => shareToFacebook(shareDetails)}
                  className="py-2 rounded-xl bg-blue-600/30 text-blue-200 border border-blue-500/30 text-xs font-semibold hover:bg-blue-600/40"
                >
                  Facebook
                </button>
                <button
                  onClick={() => shareToTwitter(shareDetails)}
                  className="py-2 rounded-xl bg-sky-600/30 text-sky-200 border border-sky-500/30 text-xs font-semibold hover:bg-sky-600/40"
                >
                  X (Twitter)
                </button>
                <button
                  onClick={() => shareToTelegram(shareDetails)}
                  className="py-2 rounded-xl bg-cyan-600/30 text-cyan-200 border border-cyan-500/30 text-xs font-semibold hover:bg-cyan-600/40"
                >
                  Telegram
                </button>
              </div>

              {/* Festive Sweets & Gifts Affiliate Callout */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-red-500/15 border border-amber-500/30 text-xs text-amber-200 mb-3">
                <div className="flex items-center gap-1.5 font-bold text-amber-300 mb-1">
                  <span>🎁 कार्ड के साथ मिठाई व दीये भी भेजें:</span>
                </div>
                <p className="text-[11px] text-amber-200/80 mb-2">
                  अमेज़न, फ्लिपकार्ट एवं मिंत्रा से काजू कतली, ड्राई फ्रूट्स व पूजा थाली विशेष छूट पर ऑर्डर करें।
                </p>
                <div className="flex items-center gap-2">
                  <a
                    href="https://www.amazon.in/b?node=diwali-sale&tag=diwaliwishes26-21"
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="flex-1 py-1.5 px-2 text-center rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 text-[11px] font-bold border border-amber-500/30"
                  >
                    Amazon Sale 🛒
                  </a>
                  <a
                    href="https://www.flipkart.com/the-big-billion-days-store?affid=diwaliwishes26"
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="flex-1 py-1.5 px-2 text-center rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-200 text-[11px] font-bold border border-blue-500/30"
                  >
                    Flipkart Gifts 🛍️
                  </a>
                </div>
              </div>

              {/* Instagram Notice */}
              <div className="p-3 rounded-xl bg-gradient-to-r from-pink-950/40 to-purple-950/40 border border-pink-500/20 text-xs text-pink-200 mb-3 flex items-center justify-between">
                <span>📸 Instagram Story: डाउनलोड करके शेयर करें</span>
                <button
                  onClick={() => {
                    handleDownloadFile();
                    window.open('https://instagram.com', '_blank');
                  }}
                  className="underline font-bold text-pink-300"
                >
                  Open Insta
                </button>
              </div>

              {/* Copy URL */}
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  readOnly
                  value={activeShareUrl}
                  className="flex-1 bg-black/40 border border-amber-500/20 rounded-xl px-2.5 py-1.5 text-xs text-amber-200 font-mono truncate"
                />
                <button
                  onClick={async () => {
                    await copyToClipboard(activeShareUrl);
                    onToast(lang === 'hi' ? 'पब्लिक लिंक कॉपी हो गया!' : 'Public link copied!');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 text-purple-950 font-bold text-xs"
                >
                  {lang === 'hi' ? 'कॉपी' : 'Copy'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Customization Controls (lg:col-span-6) */}
        <div className="lg:col-span-6 space-y-6">
          {/* Card Details & Names */}
          <div className="p-5 rounded-3xl bg-[#17082a] border border-amber-500/20 space-y-4">
            <h3 className="text-base font-bold text-amber-200 flex items-center gap-2">
              <Type className="w-4 h-4 text-amber-400" />
              <span>{lang === 'hi' ? '1. नाम एवं शुभकामना पाठ' : '1. Names & Greeting Message'}</span>
            </h3>

            {/* Sender Name */}
            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                {lang === 'hi' ? 'आपका नाम / प्रेषक (Sender Name):' : 'Your Name / Sender:'}
              </label>
              <input
                type="text"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                placeholder="जैसे: राहुल शर्मा एवं परिवार"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-amber-500/30 text-amber-100 text-sm focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Recipient Name */}
            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                {lang === 'hi' ? 'प्राप्तकर्ता का नाम (Recipient Name):' : 'Recipient Name (Optional):'}
              </label>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="जैसे: प्रिय वर्मा जी / प्यारे दोस्तों"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-amber-500/30 text-amber-100 text-sm focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Optional Business / Shop Name */}
            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1">
                {lang === 'hi' ? 'दुकान या व्यापार का नाम (Business Name - Optional):' : 'Business / Shop Name (Optional):'}
              </label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="जैसे: ॥ शुभ लाभ ज्वेलर्स ॥ / श्री गणेश ट्रेडर्स"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-amber-500/30 text-amber-100 text-sm focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Message Text with Presets */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-amber-300">
                  {lang === 'hi' ? 'शुभकामना संदेश (Greeting Message):' : 'Greeting Message:'}
                </label>
                {/* Language for card */}
                <div className="flex items-center gap-1 text-[11px]">
                  <button
                    onClick={() => setCardLang('hi')}
                    className={`px-2 py-0.5 rounded ${cardLang === 'hi' ? 'bg-amber-500 text-purple-950 font-bold' : 'text-amber-300/60'}`}
                  >
                    हिन्दी
                  </button>
                  <button
                    onClick={() => setCardLang('en')}
                    className={`px-2 py-0.5 rounded ${cardLang === 'en' ? 'bg-amber-500 text-purple-950 font-bold' : 'text-amber-300/60'}`}
                  >
                    English
                  </button>
                </div>
              </div>

              <textarea
                rows={3}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-amber-500/30 text-amber-100 text-sm focus:outline-none focus:border-amber-400 leading-relaxed font-hindi"
              />

              {/* Quick Presets Picker */}
              <div className="mt-2">
                <span className="text-[11px] text-amber-300/70 block mb-1">
                  {lang === 'hi' ? '✨ तैयार संदेश चुनें:' : '✨ Choose Ready Presets:'}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {READY_WISHES.filter((w) => w.lang === cardLang)
                    .slice(0, 6)
                    .map((w) => (
                      <button
                        key={w.id}
                        onClick={() => handleSelectPreset(w.text)}
                        className="px-2.5 py-1 rounded-lg bg-black/30 hover:bg-amber-500/20 border border-amber-500/20 text-[11px] text-amber-200/90 transition-colors"
                      >
                        {w.title}
                      </button>
                    ))}
                </div>
              </div>
            </div>
          </div>

          {/* Theme & Palette */}
          <div className="p-5 rounded-3xl bg-[#17082a] border border-amber-500/20 space-y-4">
            <h3 className="text-base font-bold text-amber-200 flex items-center gap-2">
              <Palette className="w-4 h-4 text-amber-400" />
              <span>{lang === 'hi' ? '2. रंग व थीम चयन (Festive Themes)' : '2. Festive Themes & Colors'}</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'golden-amber', name: 'गोल्डन एम्बर', color: '#f59e0b' },
                { id: 'royal-purple', name: 'रॉयल पर्पल', color: '#9333ea' },
                { id: 'crimson-divine', name: 'सिंदूरी लाल', color: '#e11d48' },
                { id: 'midnight-blue', name: 'मिडनाइट ब्लू', color: '#2563eb' },
                { id: 'saffron-glow', name: 'केसरिया दीया', color: '#ea580c' },
                { id: 'temple-gold', name: 'मंदिर स्वर्ण', color: '#ca8a04' },
              ].map((th) => (
                <button
                  key={th.id}
                  onClick={() => setTheme(th.id as CardTheme)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    theme === th.id
                      ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-md'
                      : 'bg-black/30 border-amber-500/20 text-amber-300/70 hover:bg-white/5'
                  }`}
                >
                  <span
                    className="w-4 h-4 rounded-full shrink-0 shadow-inner"
                    style={{ backgroundColor: th.color }}
                  />
                  <span className="truncate">{th.name}</span>
                </button>
              ))}
            </div>

            {/* Typography & Alignment Controls */}
            <div className="pt-3 border-t border-amber-500/15 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-amber-300">
                  {lang === 'hi' ? 'फ़ॉन्ट स्टाइल:' : 'Font Style:'}
                </span>
                <select
                  value={fontFamily}
                  onChange={(e) => setFontFamily(e.target.value)}
                  className="bg-black/40 border border-amber-500/30 rounded-xl px-2.5 py-1 text-xs text-amber-100"
                >
                  <option value="Noto Sans Devanagari">Noto Sans Devanagari</option>
                  <option value="Rozha One">Rozha One (Festive)</option>
                  <option value="Cinzel">Cinzel (Royal)</option>
                  <option value="Great Vibes">Great Vibes (Calligraphy)</option>
                  <option value="Outfit">Outfit (Modern)</option>
                </select>
              </div>

              {/* Text Size Scale & Align */}
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1">
                  <span className="text-[11px] text-amber-300/70 block mb-1">
                    फ़ॉन्ट आकार: {Math.round(fontSizeScale * 100)}%
                  </span>
                  <input
                    type="range"
                    min="0.8"
                    max="1.3"
                    step="0.05"
                    value={fontSizeScale}
                    onChange={(e) => setFontSizeScale(parseFloat(e.target.value))}
                    className="w-full accent-amber-400"
                  />
                </div>

                {/* Alignment */}
                <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-amber-500/20">
                  {(['left', 'center', 'right'] as const).map((al) => (
                    <button
                      key={al}
                      onClick={() => setTextAlign(al)}
                      className={`px-2 py-1 rounded text-xs font-semibold ${textAlign === al ? 'bg-amber-500 text-purple-950' : 'text-amber-200/70'}`}
                    >
                      {al === 'left' ? 'L' : al === 'center' ? 'C' : 'R'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Shadow toggle */}
              <div className="flex items-center justify-between text-xs text-amber-300">
                <span>{lang === 'hi' ? 'गोल्डन टेक्स्ट शैडो:' : 'Golden Text Shadow:'}</span>
                <button
                  onClick={() => setTextShadow(!textShadow)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold ${textShadow ? 'bg-amber-500 text-purple-950' : 'bg-black/30 text-amber-300/60'}`}
                >
                  {textShadow ? 'On' : 'Off'}
                </button>
              </div>
            </div>
          </div>

          {/* Photo & Custom Image Upload */}
          <div className="p-5 rounded-3xl bg-[#17082a] border border-amber-500/20 space-y-4">
            <h3 className="text-base font-bold text-amber-200 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-amber-400" />
              <span>{lang === 'hi' ? '3. फोटो जोड़ें (Optional Photo)' : '3. Add Photo (Optional)'}</span>
            </h3>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />

            {!userPhotoImg ? (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-4 px-4 rounded-2xl border-2 border-dashed border-amber-500/40 hover:border-amber-400 bg-black/20 hover:bg-black/30 flex flex-col items-center justify-center gap-2 text-amber-200 transition-all cursor-pointer"
              >
                <Upload className="w-6 h-6 text-amber-400" />
                <span className="text-xs font-semibold">
                  {lang === 'hi' ? 'अपनी या परिवार की फोटो अपलोड करें' : 'Upload your or family photo'}
                </span>
                <span className="text-[11px] text-amber-300/60">PNG, JPG or WebP (max 10MB)</span>
              </button>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-black/40 p-3 rounded-2xl border border-amber-500/20">
                  <div className="flex items-center gap-3">
                    <img
                      src={userPhotoImg.src}
                      alt="Uploaded preview"
                      className="w-12 h-12 object-cover rounded-xl border border-amber-400/50"
                    />
                    <div>
                      <span className="text-xs font-semibold text-amber-100 block">फोटो संलग्न है</span>
                      <span className="text-[11px] text-amber-300/60">कार्ड पर प्रदर्शित</span>
                    </div>
                  </div>
                  <button
                    onClick={handleRemovePhoto}
                    className="p-2 rounded-xl bg-rose-500/20 text-rose-300 hover:bg-rose-500/30"
                    title="Remove Photo"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Photo Shape & Scale Controls */}
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-amber-300/80">फ्रेम आकार:</span>
                  <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl">
                    {(['circle', 'rounded', 'square'] as const).map((sh) => (
                      <button
                        key={sh}
                        onClick={() => setPhotoShape(sh)}
                        className={`px-2.5 py-1 rounded text-xs font-semibold ${photoShape === sh ? 'bg-amber-500 text-purple-950' : 'text-amber-200/70'}`}
                      >
                        {sh === 'circle' ? 'गोल (Circle)' : sh === 'rounded' ? 'राउंडेड' : 'चौकोर'}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-amber-300/70 block mb-1">
                    फोटो आकार: {Math.round(photoScale * 100)}%
                  </span>
                  <input
                    type="range"
                    min="0.6"
                    max="1.5"
                    step="0.05"
                    value={photoScale}
                    onChange={(e) => setPhotoScale(parseFloat(e.target.value))}
                    className="w-full accent-amber-400"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Decorative Stickers & Diya Overlays */}
          <div className="p-5 rounded-3xl bg-[#17082a] border border-amber-500/20 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-amber-200 flex items-center gap-2">
                <Smile className="w-4 h-4 text-amber-400" />
                <span>{lang === 'hi' ? '4. सजावटी तोरण व दीये' : '4. Festive Stickers & Diyas'}</span>
              </h3>
              {stickers.length > 0 && (
                <button
                  onClick={handleClearStickers}
                  className="text-xs text-rose-300 hover:underline"
                >
                  {lang === 'hi' ? 'सभी हटाएं' : 'Clear all'}
                </button>
              )}
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {DECORATIVE_STICKERS.map((stk) => (
                <button
                  key={stk.id}
                  onClick={() => handleAddSticker(stk.id)}
                  className="p-2 rounded-xl bg-black/30 hover:bg-amber-500/15 border border-amber-500/20 flex flex-col items-center gap-1 transition-all text-center"
                >
                  <span className="text-xl">
                    {stk.id.includes('diya') ? '🪔' : stk.id.includes('swastik') ? '卐' : stk.id.includes('om') ? '🕉️' : stk.id.includes('kalash') ? '🏺' : stk.id.includes('sparkler') ? '✨' : '🌸'}
                  </span>
                  <span className="text-[10px] text-amber-200/80 truncate w-full font-hindi">
                    {lang === 'hi' ? stk.nameHi : stk.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
