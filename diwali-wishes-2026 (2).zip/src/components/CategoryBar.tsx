import React from 'react';
import { CATEGORIES } from '../data/categories';
import {
  Sparkles,
  Flame,
  HeartHandshake,
  Users,
  Heart,
  Store,
  Building2,
  Sun,
  LampFloor,
  Smile,
  Crown,
  Zap,
  Smartphone,
  Instagram,
  Share2,
  CreditCard,
  Video,
  Layers,
} from 'lucide-react';

interface CategoryBarProps {
  selectedCategoryId: string;
  onSelectCategory: (catId: string) => void;
  lang: 'hi' | 'en';
}

const ICON_MAP: Record<string, React.ElementType> = {
  Sparkles,
  Flame,
  HeartHandshake,
  Users,
  Heart,
  Store,
  Building2,
  Sun,
  LampFloor,
  Smile,
  Crown,
  Zap,
  Smartphone,
  Instagram,
  Share2,
  CreditCard,
  Video,
};

export const CategoryBar: React.FC<CategoryBarProps> = ({
  selectedCategoryId,
  onSelectCategory,
  lang,
}) => {
  return (
    <div className="w-full bg-[#120726]/80 border-y border-amber-500/25 py-3.5 backdrop-blur-md relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-amber-500/20 perspective-1000">
          {/* All Categories Option */}
          <button
            onClick={() => onSelectCategory('all')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-200 shrink-0 transform-style-3d hover:-translate-y-0.5 active:translate-y-0 shadow-md ${
              selectedCategoryId === 'all'
                ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-purple-950 font-black shadow-lg shadow-amber-500/25 border border-amber-300'
                : 'bg-[#1b0933]/70 text-amber-100/80 hover:text-amber-100 hover:bg-[#250d44] border border-amber-500/20'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{lang === 'hi' ? 'सभी 17 श्रेणियां' : 'All 17 Categories'}</span>
          </button>

          {/* 17 Requested Categories */}
          {CATEGORIES.map((cat) => {
            const Icon = ICON_MAP[cat.iconName] || Sparkles;
            const isSelected = selectedCategoryId === cat.id;

            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all duration-200 shrink-0 transform-style-3d hover:-translate-y-0.5 active:translate-y-0 shadow-md ${
                  isSelected
                    ? 'bg-gradient-to-r from-amber-500/25 to-orange-500/25 text-amber-200 border border-amber-400/70 shadow-lg shadow-amber-500/15 font-bold'
                    : 'bg-[#18072e]/60 text-amber-200/80 hover:text-amber-100 hover:bg-[#240c42]/80 border border-amber-500/20'
                }`}
                title={cat.description}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-300' : 'text-amber-400/80'}`} />
                <span>{lang === 'hi' ? cat.nameHi : cat.name}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/40 text-amber-300/80 font-mono border border-amber-500/20">
                  {cat.defaultAspectRatio}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
