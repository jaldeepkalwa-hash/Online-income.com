import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { X, Sparkles, Volume2, VolumeX, Camera, RotateCcw, Flame } from 'lucide-react';
import { festiveAudio } from '../utils/audio';

interface DiwaliVirtualCourtyard3DProps {
  lang: 'hi' | 'en';
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const DiwaliVirtualCourtyard3D: React.FC<DiwaliVirtualCourtyard3DProps> = ({
  lang,
  onClose,
  onToast,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [diyasLitCount, setDiyasLitCount] = useState<number>(12);
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(festiveAudio.getMuted());
  const [activeEffect, setActiveEffect] = useState<string>('');

  // Three.js scene refs
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const fireworksRef = useRef<Array<{
    points: THREE.Points;
    velocities: Float32Array;
    life: number;
    maxLife: number;
    color: THREE.Color;
  }>>([]);
  const diyasGroupRef = useRef<THREE.Group | null>(null);
  const flamesListRef = useRef<Array<{ group: THREE.Group; light: THREE.PointLight }>>([]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c0419);
    scene.fog = new THREE.FogExp2(0x0c0419, 0.04);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(
      50,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 3.2, 8.5);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 2. Lights
    const ambientLight = new THREE.AmbientLight(0x321350, 1.4);
    scene.add(ambientLight);

    const moonLight = new THREE.DirectionalLight(0xbfa5ff, 0.9);
    moonLight.position.set(-8, 14, 6);
    moonLight.castShadow = true;
    scene.add(moonLight);

    // Warm Temple Altar Glow Light
    const altarLight = new THREE.PointLight(0xffb703, 3.2, 14);
    altarLight.position.set(0, 2.8, -2);
    scene.add(altarLight);

    // 3. Ground: Ornate Rangoli Marble Courtyard
    const floorGeo = new THREE.PlaneGeometry(32, 32, 32, 32);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x16072a,
      roughness: 0.35,
      metalness: 0.2,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Glowing Central Rangoli Mandala Decal on floor
    const rangoliGroup = new THREE.Group();
    rangoliGroup.position.set(0, 0.02, 0);

    const ringColors = [0xf59e0b, 0xe11d48, 0x10b981, 0x8b5cf6, 0xfbbf24];
    ringColors.forEach((col, idx) => {
      const radius = 1.0 + idx * 0.55;
      const ringGeo = new THREE.RingGeometry(radius, radius + 0.08, 48);
      const ringMat = new THREE.MeshBasicMaterial({
        color: col,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.85,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = -Math.PI / 2;
      rangoliGroup.add(ringMesh);
    });
    scene.add(rangoliGroup);

    // 4. Temple Mandir Altar Structure
    const mandirGroup = new THREE.Group();
    mandirGroup.position.set(0, 0, -3.5);

    // Base Steps
    const step1Geo = new THREE.BoxGeometry(6, 0.3, 3);
    const marbleMat = new THREE.MeshStandardMaterial({
      color: 0x2e114d,
      roughness: 0.4,
      metalness: 0.3,
    });
    const step1 = new THREE.Mesh(step1Geo, marbleMat);
    step1.position.y = 0.15;
    mandirGroup.add(step1);

    const step2Geo = new THREE.BoxGeometry(5, 0.3, 2.4);
    const step2 = new THREE.Mesh(step2Geo, marbleMat);
    step2.position.y = 0.45;
    mandirGroup.add(step2);

    // Golden Pillars
    const goldPillarMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.85,
      roughness: 0.25,
    });

    const pillarGeo = new THREE.CylinderGeometry(0.18, 0.22, 3.2, 24);
    const p1 = new THREE.Mesh(pillarGeo, goldPillarMat);
    p1.position.set(-2, 2.05, 0.8);
    const p2 = new THREE.Mesh(pillarGeo, goldPillarMat);
    p2.position.set(2, 2.05, 0.8);
    const p3 = new THREE.Mesh(pillarGeo, goldPillarMat);
    p3.position.set(-2, 2.05, -0.8);
    const p4 = new THREE.Mesh(pillarGeo, goldPillarMat);
    p4.position.set(2, 2.05, -0.8);
    mandirGroup.add(p1, p2, p3, p4);

    // Temple Arch Dome (Shikhara)
    const domeGeo = new THREE.ConeGeometry(2.4, 2.2, 16);
    const domeMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.75,
      roughness: 0.3,
    });
    const dome = new THREE.Mesh(domeGeo, domeMat);
    dome.position.set(0, 4.6, 0);
    mandirGroup.add(dome);

    // Golden Kalash atop Shikhara
    const kalashGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const kalash = new THREE.Mesh(kalashGeo, goldPillarMat);
    kalash.position.set(0, 5.8, 0);
    mandirGroup.add(kalash);

    // Brass Temple Hanging Bells
    const bellMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      metalness: 0.9,
      roughness: 0.2,
    });
    const bellGeo = new THREE.ConeGeometry(0.18, 0.35, 16);
    const bell1 = new THREE.Mesh(bellGeo, bellMat);
    bell1.position.set(-1.2, 3.2, 0.7);
    const bell2 = new THREE.Mesh(bellGeo, bellMat);
    bell2.position.set(1.2, 3.2, 0.7);
    mandirGroup.add(bell1, bell2);

    scene.add(mandirGroup);

    // 5. Diya Creation Helper
    const diyasGroup = new THREE.Group();
    diyasGroupRef.current = diyasGroup;
    scene.add(diyasGroup);

    const clayMat = new THREE.MeshStandardMaterial({
      color: 0x9a3412,
      roughness: 0.7,
      metalness: 0.2,
    });
    const diyaRimMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.8,
      roughness: 0.25,
    });
    const flameMat = new THREE.MeshBasicMaterial({ color: 0xffedd5 });
    const flameOuterMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.85,
    });

    const addDiya = (x: number, y: number, z: number) => {
      const g = new THREE.Group();
      g.position.set(x, y, z);

      // Base bowl
      const baseGeo = new THREE.CylinderGeometry(0.32, 0.16, 0.15, 20);
      const bMesh = new THREE.Mesh(baseGeo, clayMat);
      bMesh.castShadow = true;
      g.add(bMesh);

      // Golden rim
      const rimGeo = new THREE.TorusGeometry(0.33, 0.03, 12, 24);
      rimGeo.rotateX(Math.PI / 2);
      rimGeo.translate(0, 0.08, 0);
      const rMesh = new THREE.Mesh(rimGeo, diyaRimMat);
      g.add(rMesh);

      // Flame
      const flameGroup = new THREE.Group();
      const fInner = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 12), flameMat);
      fInner.position.y = 0.22;
      const fOuter = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.38, 12), flameOuterMat);
      fOuter.position.y = 0.22;
      flameGroup.add(fOuter, fInner);
      g.add(flameGroup);

      // Point Light
      const pLight = new THREE.PointLight(0xf59e0b, 1.8, 4.5);
      pLight.position.set(0, 0.3, 0);
      g.add(pLight);

      diyasGroup.add(g);
      flamesListRef.current.push({ group: flameGroup, light: pLight });
    };

    // Arrange Initial 12 Courtyard Diyas in a Ring & Temple Altar
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      const radius = 3.2;
      addDiya(Math.cos(angle) * radius, 0.08, Math.sin(angle) * radius);
    }
    // Altar Diyas
    addDiya(-1.8, 0.7, -3.2);
    addDiya(1.8, 0.7, -3.2);
    addDiya(-0.8, 0.7, -3.2);
    addDiya(0.8, 0.7, -3.2);

    // 6. Floating Sky Lanterns (Akash Kandil) in the background
    const lanternsGroup = new THREE.Group();
    const lanternMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xb91c1c,
      emissiveIntensity: 0.5,
      roughness: 0.3,
    });
    for (let i = 0; i < 18; i++) {
      const l = new THREE.Mesh(new THREE.OctahedronGeometry(0.35 + Math.random() * 0.2, 0), lanternMat);
      l.position.set(
        (Math.random() - 0.5) * 22,
        2.5 + Math.random() * 10,
        -4 - Math.random() * 16
      );
      lanternsGroup.add(l);
    }
    scene.add(lanternsGroup);

    // 7. Ambient Golden Sparkle Dust Particles
    const dustCount = 600;
    const dustGeo = new THREE.BufferGeometry();
    const dustPositions = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount * 3; i += 3) {
      dustPositions[i] = (Math.random() - 0.5) * 20;
      dustPositions[i + 1] = Math.random() * 10;
      dustPositions[i + 2] = (Math.random() - 0.5) * 16;
    }
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0xfde047,
      size: 0.06,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });
    const dustPoints = new THREE.Points(dustGeo, dustMat);
    scene.add(dustPoints);

    // 8. Interactive Camera Orbit Controls (Mouse & Touch Drag)
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let spherical = { radius: 8.5, theta: 0, phi: Math.PI / 3.2 };

    const updateCameraPos = () => {
      camera.position.x = spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta);
      camera.position.y = spherical.radius * Math.cos(spherical.phi);
      camera.position.z = spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);
      camera.lookAt(0, 1.2, -0.8);
    };
    updateCameraPos();

    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      isDragging = true;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      prevMouseX = clientX;
      prevMouseY = clientY;
    };

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      const deltaX = clientX - prevMouseX;
      const deltaY = clientY - prevMouseY;
      prevMouseX = clientX;
      prevMouseY = clientY;

      spherical.theta -= deltaX * 0.006;
      spherical.phi = Math.max(0.3, Math.min(Math.PI / 2.1, spherical.phi - deltaY * 0.006));
      updateCameraPos();
    };

    const onPointerUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      spherical.radius = Math.max(4.5, Math.min(14, spherical.radius + e.deltaY * 0.005));
      updateCameraPos();
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);
    dom.addEventListener('touchstart', onPointerDown, { passive: true });
    window.addEventListener('touchmove', onPointerMove, { passive: true });
    window.addEventListener('touchend', onPointerUp);
    dom.addEventListener('wheel', onWheel, { passive: true });

    // Click to Light New Diya on Floor
    const raycaster = new THREE.Raycaster();
    const mouseVector = new THREE.Vector2();

    const handleClickFloor = (e: MouseEvent) => {
      const rect = dom.getBoundingClientRect();
      mouseVector.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseVector.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouseVector, camera);

      const intersects = raycaster.intersectObject(floor);
      if (intersects.length > 0) {
        const point = intersects[0].point;
        if (point.z > -5 && point.z < 6 && Math.abs(point.x) < 7) {
          addDiya(point.x, 0.08, point.z);
          setDiyasLitCount((prev) => prev + 1);
          festiveAudio.playChime();
          onToast(lang === 'hi' ? 'शुभ दीया प्रज्वलित हुआ! 🪔' : 'New Diya lit with blessing! 🪔');
        }
      }
    };
    dom.addEventListener('click', handleClickFloor);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // 9. Animation Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Flame flicker
      flamesListRef.current.forEach((item, idx) => {
        const offset = idx * 0.4;
        const s = 1 + Math.sin(elapsed * 12 + offset) * 0.12;
        item.group.scale.set(s, 1 + Math.cos(elapsed * 15 + offset) * 0.18, s);
        item.group.rotation.z = Math.sin(elapsed * 8 + offset) * 0.08;
        item.light.intensity = 1.6 + Math.sin(elapsed * 16 + offset) * 0.4;
      });

      // Slowly rotate Rangoli
      rangoliGroup.rotation.y = elapsed * 0.05;

      // Floating lanterns slow drift
      lanternsGroup.children.forEach((l, idx) => {
        l.position.y += Math.sin(elapsed * 1.5 + idx) * 0.005;
        l.rotation.y = elapsed * 0.2 + idx;
      });

      // Dust particle drift
      dustPoints.rotation.y = elapsed * 0.02;

      // Update active fireworks
      for (let i = fireworksRef.current.length - 1; i >= 0; i--) {
        const fw = fireworksRef.current[i];
        fw.life++;
        const posAttr = fw.points.geometry.getAttribute('position') as THREE.BufferAttribute;
        const posArray = posAttr.array as Float32Array;

        for (let j = 0; j < posArray.length; j += 3) {
          posArray[j] += fw.velocities[j];
          posArray[j + 1] += fw.velocities[j + 1];
          posArray[j + 2] += fw.velocities[j + 2];
          fw.velocities[j + 1] -= 0.004; // Gravity
        }
        posAttr.needsUpdate = true;

        const mat = fw.points.material as THREE.PointsMaterial;
        mat.opacity = 1 - fw.life / fw.maxLife;

        if (fw.life >= fw.maxLife) {
          scene.remove(fw.points);
          fw.points.geometry.dispose();
          mat.dispose();
          fireworksRef.current.splice(i, 1);
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      dom.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      dom.removeEventListener('touchstart', onPointerDown);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);
      dom.removeEventListener('wheel', onWheel);
      dom.removeEventListener('click', handleClickFloor);
      window.removeEventListener('resize', handleResize);

      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [lang, onToast]);

  // Firecracker Launcher Helper
  const launchFirework = (type: 'skyshot' | 'anar' | 'phuljhadi' | 'rocket') => {
    setActiveEffect(type);
    setTimeout(() => setActiveEffect(''), 1500);

    const scene = sceneRef.current;
    if (!scene) return;

    festiveAudio.playSparkle();

    if (type === 'skyshot' || type === 'rocket') {
      const particleCount = 280;
      const geo = new THREE.BufferGeometry();
      const pos = new Float32Array(particleCount * 3);
      const vel = new Float32Array(particleCount * 3);

      const burstX = (Math.random() - 0.5) * 8;
      const burstY = 5 + Math.random() * 3.5;
      const burstZ = -1 - Math.random() * 5;

      const colors = [0xf59e0b, 0xf43f5e, 0x10b981, 0xa855f7, 0xfde047];
      const pickedColor = new THREE.Color(colors[Math.floor(Math.random() * colors.length)]);

      for (let i = 0; i < particleCount * 3; i += 3) {
        pos[i] = burstX;
        pos[i + 1] = burstY;
        pos[i + 2] = burstZ;

        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        const speed = 0.08 + Math.random() * 0.12;

        vel[i] = speed * Math.sin(phi) * Math.cos(theta);
        vel[i + 1] = speed * Math.cos(phi);
        vel[i + 2] = speed * Math.sin(phi) * Math.sin(theta);
      }

      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.PointsMaterial({
        color: pickedColor,
        size: 0.12,
        transparent: true,
        opacity: 1,
        blending: THREE.AdditiveBlending,
      });

      const points = new THREE.Points(geo, mat);
      scene.add(points);

      fireworksRef.current.push({
        points,
        velocities: vel,
        life: 0,
        maxLife: 70,
        color: pickedColor,
      });

      onToast(lang === 'hi' ? '🚀 3D आतिशबाजी रॉकेट छूटा!' : '🚀 3D Fireworks burst launched!');
    } else if (type === 'anar') {
      // Fountain from floor
      const count = 350;
      const geo = new THREE.BufferGeometry();
      const pos = new Float32Array(count * 3);
      const vel = new Float32Array(count * 3);

      for (let i = 0; i < count * 3; i += 3) {
        pos[i] = 0;
        pos[i + 1] = 0.1;
        pos[i + 2] = 0;

        const spread = (Math.random() - 0.5) * 0.05;
        vel[i] = spread;
        vel[i + 1] = 0.14 + Math.random() * 0.08;
        vel[i + 2] = spread;
      }

      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.PointsMaterial({
        color: 0xfef08a,
        size: 0.1,
        transparent: true,
        opacity: 1,
        blending: THREE.AdditiveBlending,
      });

      const points = new THREE.Points(geo, mat);
      scene.add(points);

      fireworksRef.current.push({
        points,
        velocities: vel,
        life: 0,
        maxLife: 60,
        color: new THREE.Color(0xfef08a),
      });

      onToast(lang === 'hi' ? '🎆 स्वर्ण अनार फव्वारा शुरू!' : '🎆 Golden Anar fountain bursting!');
    } else if (type === 'phuljhadi') {
      // Sparkler vortex
      const count = 220;
      const geo = new THREE.BufferGeometry();
      const pos = new Float32Array(count * 3);
      const vel = new Float32Array(count * 3);

      for (let i = 0; i < count * 3; i += 3) {
        pos[i] = (Math.random() - 0.5) * 0.5;
        pos[i + 1] = 1.5;
        pos[i + 2] = (Math.random() - 0.5) * 0.5;

        vel[i] = (Math.random() - 0.5) * 0.09;
        vel[i + 1] = (Math.random() - 0.5) * 0.09;
        vel[i + 2] = (Math.random() - 0.5) * 0.09;
      }

      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.PointsMaterial({
        color: 0x38bdf8,
        size: 0.09,
        transparent: true,
        opacity: 1,
        blending: THREE.AdditiveBlending,
      });

      const points = new THREE.Points(geo, mat);
      scene.add(points);

      fireworksRef.current.push({
        points,
        velocities: vel,
        life: 0,
        maxLife: 50,
        color: new THREE.Color(0x38bdf8),
      });

      onToast(lang === 'hi' ? '✨ रंग-बिरंगी फुलझड़ी जल उठी!' : '✨ Colorful Phuljhadi sparkler glowing!');
    }
  };

  const handleToggleSound = () => {
    const next = festiveAudio.toggleMute();
    setIsAudioMuted(next);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black overflow-hidden select-none">
      {/* Three.js Canvas Container */}
      <div ref={containerRef} className="absolute inset-0 cursor-grab active:cursor-grabbing" />

      {/* Top Overlay Controls Bar */}
      <div className="relative z-10 flex items-center justify-between p-4 sm:p-6 bg-gradient-to-b from-black/85 via-black/40 to-transparent backdrop-blur-[2px]">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 p-0.5 shadow-lg">
            <div className="w-full h-full bg-[#1b0833] rounded-[14px] flex items-center justify-center">
              <span className="text-2xl animate-flame">🪔</span>
            </div>
          </div>
          <div>
            <h2 className="text-lg sm:text-2xl font-black text-gold-gradient font-festive flex items-center gap-2">
              <span>{lang === 'hi' ? '3D दीपोत्सव मंदिर व वर्चुअल प्रांगण' : '3D Virtual Diwali Courtyard'}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                360° 3D
              </span>
            </h2>
            <p className="text-xs text-amber-200/80 font-hindi">
              {lang === 'hi'
                ? 'माउस/टच से घुमाएँ • प्रांगण में कहीं भी टैप कर शुभ दीया जलाएं'
                : 'Drag to look around 360° • Tap anywhere to place & light fresh Diyas'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* Diya Counter Badge */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/60 border border-amber-500/30 text-amber-300 text-xs font-bold">
            <Flame className="w-4 h-4 text-orange-400 fill-orange-400" />
            <span>{diyasLitCount} {lang === 'hi' ? 'दीये प्रज्वलित' : 'Diyas Lit'}</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={handleToggleSound}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-amber-200 border border-amber-500/20 transition-colors"
            title="Toggle Festive Sound"
          >
            {isAudioMuted ? <VolumeX className="w-5 h-5 text-amber-400/60" /> : <Volume2 className="w-5 h-5 text-amber-300" />}
          </button>

          {/* Close / Return Button */}
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg active:scale-95 transition-all"
          >
            <X className="w-4 h-4" />
            <span>{lang === 'hi' ? 'बाहर निकलें' : 'Exit 3D'}</span>
          </button>
        </div>
      </div>

      {/* Center Guidance Hint */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 z-10 pointer-events-none text-center">
        <span className="px-3.5 py-1.5 rounded-full bg-black/50 backdrop-blur-md border border-amber-500/20 text-amber-200 text-xs font-hindi shadow-md">
          {lang === 'hi'
            ? '✨ 360° व्यू के लिए स्क्रीन को ड्रैग करें • फर्श पर क्लिक कर दीया लगाएं'
            : '✨ Drag screen to explore 360° • Click courtyard floor to light a Diya'}
        </span>
      </div>

      {/* Bottom Firecracker Interactive Toolbar */}
      <div className="relative z-10 mt-auto p-4 sm:p-6 bg-gradient-to-t from-black/90 via-black/50 to-transparent">
        <div className="max-w-2xl mx-auto flex flex-col items-center gap-3">
          {/* Sanskrit Shloka Card with 3D Depth */}
          <div className="px-5 py-2 rounded-2xl bg-[#1b0833]/80 border border-amber-500/30 text-center backdrop-blur-md">
            <span className="text-xs sm:text-sm font-bold text-amber-200 font-festive block">
              ॥ ॐ महालक्ष्म्यै नमः • शुभ दीपावली विक्रम संवत 2083 ॥
            </span>
          </div>

          {/* Firecracker Launch Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            <button
              onClick={() => launchFirework('skyshot')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:brightness-110 active:scale-95 text-white font-bold text-xs sm:text-sm shadow-xl transition-all"
            >
              <span>🚀</span>
              <span>{lang === 'hi' ? 'आतिशबाजी (Skyshot)' : 'Skyshot'}</span>
            </button>

            <button
              onClick={() => launchFirework('anar')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 active:scale-95 text-purple-950 font-black text-xs sm:text-sm shadow-xl transition-all"
            >
              <span>🎆</span>
              <span>{lang === 'hi' ? 'स्वर्ण अनार (Anar)' : 'Golden Anar'}</span>
            </button>

            <button
              onClick={() => launchFirework('phuljhadi')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-teal-500 to-cyan-500 hover:brightness-110 active:scale-95 text-purple-950 font-black text-xs sm:text-sm shadow-xl transition-all"
            >
              <span>✨</span>
              <span>{lang === 'hi' ? 'फुलझड़ी (Sparkler)' : 'Phuljhadi'}</span>
            </button>

            <button
              onClick={() => {
                festiveAudio.playChime();
                onToast(lang === 'hi' ? '🔔 पावन मंदिर घंटा बजा!' : '🔔 Sacred Temple Bell chimed!');
              }}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-amber-500/30 text-amber-300 font-bold text-xs active:scale-95 transition-all"
            >
              <span>🔔</span>
              <span>{lang === 'hi' ? 'मंदिर घंटी' : 'Temple Bell'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
