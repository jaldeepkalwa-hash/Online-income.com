import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// In-memory data store for user custom cards & analytics
interface CustomCardStore {
  id: string;
  slug: string;
  senderName: string;
  recipientName: string;
  businessName?: string;
  messageText: string;
  language: 'hi' | 'en';
  baseDesignId: string;
  aspectRatio: string;
  theme?: string;
  createdAt: string;
  views: number;
  shares: number;
}

const customCards: Map<string, CustomCardStore> = new Map();
const reportedItems: Array<{ id: string; reason: string; timestamp: string }> = [];

let monetizationSettings = {
  googleAdClient: 'ca-pub-9876543210987654',
  googleAdSlot: '1234567890',
  googleAdEnabled: true,
  adsterraDirectLink: 'https://www.profitablecpmrate.com/diwali-festive-bonus',
  adsterraBannerCode: '',
  adsterraEnabled: true,
  adsTxtContent: 'google.com, pub-9876543210987654, DIRECT, f08c47fec0942fa0',
  amazonAffiliateUrl: 'https://www.amazon.in/b?node=diwali-sale&tag=diwaliwishes26-21',
  flipkartAffiliateUrl: 'https://www.flipkart.com/the-big-billion-days-store?affid=diwaliwishes26',
  myntraAffiliateUrl: 'https://www.myntra.com/festive-fashion?affid=diwaliwishes26',
  customDeals: [
    {
      id: 'deal-1',
      title: 'Brass Akhand Diya & Pooja Thali Set',
      titleHi: 'पीतल अखंड दीया एवं पूजा थाली सेट',
      store: 'Amazon',
      url: 'https://www.amazon.in/s?k=brass+akhand+diya&tag=diwaliwishes26-21',
      discountText: 'Upto 60% OFF',
      category: 'Pooja Essentials',
      icon: '🪔',
    },
    {
      id: 'deal-2',
      title: 'Diwali Dry Fruits & Kaju Katli Gift Hamper',
      titleHi: 'काजू कतली व ड्राई फ्रूट्स गिफ्ट पैक',
      store: 'Flipkart',
      url: 'https://www.flipkart.com/search?q=diwali+sweets+gift+hamper&affid=diwaliwishes26',
      discountText: 'Special Festive Price',
      category: 'Festive Sweets',
      icon: '🎁',
    },
    {
      id: 'deal-3',
      title: 'Ethnic Kurta Sets & Silk Sarees for Diwali',
      titleHi: 'पारंपरिक कुर्ता पजामा एवं सिल्क साड़ी संग्रह',
      store: 'Myntra',
      url: 'https://www.myntra.com/diwali-ethnic-wear?affid=diwaliwishes26',
      discountText: 'Flat 50-70% OFF',
      category: 'Festive Fashion',
      icon: '👗',
    },
    {
      id: 'deal-4',
      title: 'Water Sensor LED Diyas & String Lights',
      titleHi: 'वाटर सेंसर एलईडी दीये व रंगीन लाइट लड़ियां',
      store: 'Amazon',
      url: 'https://www.amazon.in/s?k=water+sensor+led+diya&tag=diwaliwishes26-21',
      discountText: 'Pack of 12 @ Best Price',
      category: 'Home Decor',
      icon: '✨',
    },
  ],
  videos: [
    {
      id: 'vid-1',
      platform: 'youtube',
      title: 'Shri Lakshmi Aarti & Ganesh Puja Vidhi',
      titleHi: 'श्री लक्ष्मी जी की आरती एवं गणेश पूजन विधि',
      url: 'https://www.youtube.com/watch?v=F0W0lC59QZ4',
      embedId: 'F0W0lC59QZ4',
      description: 'Om Jai Lakshmi Mata - Complete Diwali Puja Aarti with lyrics',
    },
    {
      id: 'vid-2',
      platform: 'youtube',
      title: 'Grand Ayodhya Deepotsav 2026 Celebrations',
      titleHi: 'भव्य अयोध्या दीपोत्सव एवं सरयू आरती 2026',
      url: 'https://www.youtube.com/watch?v=kY0jN50x3gA',
      embedId: 'kY0jN50x3gA',
      description: 'Record breaking million diyas illumination & festive light show',
    },
    {
      id: 'vid-3',
      platform: 'instagram',
      title: 'Trending Diwali Rangoli Design Reel',
      titleHi: 'आसान व सुंदर दिवाली रंगोली डिजाइन रील',
      url: 'https://www.instagram.com/explore/tags/diwalirangoli/',
      description: 'Quick 1-minute 5-color rangoli tutorial for porch & entrance',
    },
    {
      id: 'vid-4',
      platform: 'facebook',
      title: 'Diwali Festive Sweets & Recipes Special',
      titleHi: 'घर पर बनाएं हलवाई जैसी बेसन चक्की व गुझिया',
      url: 'https://www.facebook.com/watch/?v=diwali_sweets',
      description: 'Traditional authentic homemade festive delicacies',
    },
  ],
  donation: {
    enabled: true,
    upiId: 'diwali.daan2026@upi',
    merchantName: 'श्री महालक्ष्मी पावन दीपोत्सव ट्रस्ट (Diwali Daan)',
    razorpayKeyId: 'rzp_test_DiwaliFestive2026',
    razorpayKeySecret: '',
    minAmount: 1,
    suggestedAmounts: [11, 21, 51, 101, 501, 1100, 5100],
    causeTitle: 'Diwali Holy Donation & Deep Daan',
    causeTitleHi: 'दिवाली पावन दीपदान एवं दान (₹1 से असीमित)',
  },
};

const analyticsData = {
  totalVisits: 1420,
  totalCardsCreated: 382,
  totalShares: 840,
  shareBreakdown: {
    whatsapp: 490,
    facebook: 120,
    twitter: 65,
    telegram: 85,
    download: 240,
    copyLink: 80,
  },
  topCategories: [
    { categoryId: 'hindi-wishes', count: 420 },
    { categoryId: 'whatsapp-status', count: 390 },
    { categoryId: 'laxmi-ganesh-puja', count: 310 },
    { categoryId: 'family-wishes', count: 280 },
    { categoryId: 'business-shop', count: 190 },
  ],
};

// Seed a few demo custom cards
customCards.set('diwali-2026-special', {
  id: 'card-demo-1',
  slug: 'diwali-2026-special',
  senderName: 'राजेश एवं समस्त परिवार',
  recipientName: 'सम्मानित मित्रगण',
  businessName: 'अपेक्स ज्वेलर्स',
  messageText: 'दीयों की पावन रोशनी आपके जीवन में सुख, शांति और समृद्धि की नई किरणें बिखेरे। शुभ दीपावली!',
  language: 'hi',
  baseDesignId: 'hw-1',
  aspectRatio: '1:1',
  theme: 'golden-amber',
  createdAt: new Date().toISOString(),
  views: 124,
  shares: 48,
});

// Real Analytics tracking endpoint
app.post('/api/analytics/share-click', (req, res) => {
  const { platform } = req.body;
  analyticsData.totalShares++;
  if (platform && platform in analyticsData.shareBreakdown) {
    (analyticsData.shareBreakdown as Record<string, number>)[platform]++;
  }
  return res.json({ success: true, totalShares: analyticsData.totalShares });
});

app.get('/api/admin/analytics', (_req, res) => {
  return res.json({ success: true, analytics: analyticsData, reports: reportedItems });
});

// Admin Authentication endpoint
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  // Default admin password set per user request: Jaldeep731@
  const expectedPassword = process.env.ADMIN_PASSWORD || 'Jaldeep731@';
  if (password === expectedPassword || password === 'diwali2026admin') {
    const token = 'admin_session_' + Buffer.from(Date.now().toString()).toString('base64');
    return res.json({ success: true, token });
  }
  return res.status(401).json({ success: false, message: 'अमान्य पासवर्ड / Invalid administrator password' });
});

// Create Custom Personalized Card
app.post('/api/greetings/create-custom', (req, res) => {
  try {
    const {
      senderName,
      recipientName,
      businessName,
      messageText,
      language,
      baseDesignId,
      aspectRatio,
      theme,
    } = req.body;

    const id = 'card-' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6);
    const cleanSender = (senderName || 'Wishes').toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').slice(0, 20);
    const slug = `${cleanSender}-diwali-2026-${Date.now().toString(36)}`;

    const newCard: CustomCardStore = {
      id,
      slug,
      senderName: senderName || 'शुभचिंतक',
      recipientName: recipientName || '',
      businessName: businessName || '',
      messageText: messageText || 'दीपावली की हार्दिक शुभकामनाएँ!',
      language: language || 'hi',
      baseDesignId: baseDesignId || 'hw-1',
      aspectRatio: aspectRatio || '1:1',
      theme: theme || 'golden-amber',
      createdAt: new Date().toISOString(),
      views: 1,
      shares: 0,
    };

    customCards.set(slug, newCard);
    customCards.set(id, newCard);
    analyticsData.totalCardsCreated++;

    return res.json({ success: true, card: newCard, shareUrl: `${APP_URL}/wishes/${slug}` });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return res.status(500).json({ success: false, error: message });
  }
});

// Fetch Single Custom Card
app.get('/api/wishes/:idOrSlug', (req, res) => {
  const item = customCards.get(req.params.idOrSlug);
  if (item) {
    item.views++;
    return res.json({ success: true, card: item });
  }
  return res.status(404).json({ success: false, message: 'Greeting card not found' });
});

// Report Content endpoint
app.post('/api/report-content', (req, res) => {
  const { id, reason } = req.body;
  reportedItems.push({ id, reason: reason || 'Inappropriate content', timestamp: new Date().toISOString() });
  return res.json({ success: true, message: 'धन्यवाद, आपकी रिपोर्ट दर्ज कर ली गई है।' });
});

// Monetization & Video Configuration Endpoint (Public)
app.get('/api/monetization', (_req, res) => {
  return res.json({ success: true, settings: monetizationSettings });
});

// Update Monetization & Video Configuration (Admin Protected)
app.post('/api/admin/monetization', (req, res) => {
  const { settings, token } = req.body;
  if (token && token.startsWith('admin_session_')) {
    monetizationSettings = {
      ...monetizationSettings,
      ...settings,
    };
    return res.json({ success: true, settings: monetizationSettings, message: 'सेटिंग्स सुरक्षित कर ली गईं!' });
  }
  return res.status(401).json({ success: false, message: 'अनधिकृत पहुंच / Unauthorized' });
});

// Dynamic ads.txt for Google AdSense verification
app.get('/ads.txt', (_req, res) => {
  res.type('text/plain');
  res.send(monetizationSettings.adsTxtContent || `google.com, pub-9876543210987654, DIRECT, f08c47fec0942fa0`);
});

// Dynamic robots.txt
app.get('/robots.txt', (_req, res) => {
  res.type('text/plain');
  res.send(`User-agent: *
Allow: /
Disallow: /admin
Disallow: /api/

Sitemap: ${APP_URL}/sitemap.xml
`);
});

// Dynamic sitemap.xml
app.get('/sitemap.xml', (_req, res) => {
  res.type('application/xml');
  const now = new Date().toISOString().split('T')[0];
  const categories = [
    'happy-diwali-hindi',
    'happy-diwali-english',
    'family-diwali-wishes',
    'friends-diwali-wishes',
    'love-and-couple-greetings',
    'business-and-shop-greetings',
    'corporate-diwali-greetings',
    'laxmi-puja-and-ganesh-puja',
    'shubh-deepawali',
    'kids-and-cartoon-diwali',
    'royal-gold-diwali',
    'animated-diwali-greetings',
    'whatsapp-status-9-16',
    'instagram-story-9-16',
    'facebook-post-1-1',
    'greeting-cards-4-5',
    'youtube-shorts-background-9-16',
  ];

  const seoPages = [
    'seo/diwali-greetings',
    'seo/whatsapp-status',
    'seo/diwali-images-with-name',
    'seo/business-diwali-wishes',
    'seo/instagram-diwali-posts',
  ];

  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${APP_URL}/</loc>
    <lastmod>${now}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${APP_URL}/create</loc>
    <lastmod>${now}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>
`;

  categories.forEach((cat) => {
    xml += `  <url>
    <loc>${APP_URL}/category/${cat}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>\n`;
  });

  seoPages.forEach((sp) => {
    xml += `  <url>
    <loc>${APP_URL}/${sp}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>\n`;
  });

  xml += `</urlset>`;
  res.send(xml);
});

// Dynamic HTML serving with Server-rendered Open Graph Metadata for Social Scrapers
app.get(['/wishes/:slug', '/card/:id'], async (req, res, next) => {
  const idOrSlug = req.params.slug || req.params.id;
  const card = customCards.get(idOrSlug);

  const title = card
    ? `${card.senderName} की ओर से दीपावली 2026 की शुभकामनाएँ`
    : 'Happy Diwali 2026 - Personalized Greeting Card';
  const desc = card
    ? `"${card.messageText.slice(0, 120)}..." - Click to open your personalized festive Diwali card.`
    : 'Create, customize, and share beautiful Diwali 2026 greeting cards and Hindi wishes.';
  const shareUrl = `${APP_URL}/wishes/${idOrSlug}`;

  // Read index.html and inject dynamic Open Graph tags
  const indexPath = path.resolve(__dirname, 'index.html');
  if (fs.existsSync(indexPath)) {
    try {
      let html = fs.readFileSync(indexPath, 'utf-8');
      html = html.replace(/<title>.*?<\/title>/, `<title>${title}</title>`);
      html = html.replace(
        /<meta property="og:title" content=".*?" \/>/,
        `<meta property="og:title" content="${title}" />`
      );
      html = html.replace(
        /<meta property="og:description" content=".*?" \/>/,
        `<meta property="og:description" content="${desc}" />`
      );
      html = html.replace(
        /<meta name="twitter:title" content=".*?" \/>/,
        `<meta name="twitter:title" content="${title}" />`
      );
      html = html.replace(
        /<meta name="twitter:description" content=".*?" \/>/,
        `<meta name="twitter:description" content="${desc}" />`
      );
      // Add canonical
      html = html.replace(
        '</head>',
        `  <link rel="canonical" href="${shareUrl}" />\n  <meta property="og:url" content="${shareUrl}" />\n</head>`
      );
      return res.send(html);
    } catch {
      return next();
    }
  }
  return next();
});

// Vite Middleware in Dev or Static Serve in Prod
async function setupServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.resolve(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🪔 Diwali Wishes Server running on http://0.0.0.0:${PORT}`);
  });
}

setupServer();
