import React, { useState } from 'react';
import { Play, Video, ExternalLink, X, Film, Volume2, Music } from 'lucide-react';
import { SocialVideoItem } from '../types/greeting';
import { festiveAudio } from '../utils/audio';

interface FestiveVideosProps {
  videos?: SocialVideoItem[];
  lang?: 'hi' | 'en';
}

export const FestiveVideos: React.FC<FestiveVideosProps> = ({ videos = [], lang = 'hi' }) => {
  const [activeVideo, setActiveVideo] = useState<SocialVideoItem | null>(null);

  if (!videos || videos.length === 0) return null;

  return (
    <section className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl sm:text-2xl font-black text-amber-100 font-festive">
              {lang === 'hi'
                ? 'दीपावली विशेष वीडियो एवं रील्स (Videos & Reels)'
                : 'Diwali Special Videos, Aarti & Reels'}
            </h2>
          </div>
          <p className="text-xs text-amber-300/70 mt-1 font-hindi">
            {lang === 'hi'
              ? 'यूट्यूब, इंस्टाग्राम और फेसबुक से चयनित पावन लक्ष्मी आरती, दीपोत्सव एवं रंगोली रील्स।'
              : 'Curated festive YouTube aartis, Instagram reels, and Facebook Diwali videos.'}
          </p>
        </div>

        <span className="text-[11px] px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-medium">
          YouTube • Instagram • Facebook
        </span>
      </div>

      {/* Video Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {videos.map((vid) => {
          const isYouTube = vid.platform === 'youtube';
          const isInsta = vid.platform === 'instagram';
          const isFB = vid.platform === 'facebook';

          const badgeColor = isYouTube
            ? 'bg-red-600/20 text-red-400 border-red-500/30'
            : isInsta
            ? 'bg-pink-600/20 text-pink-400 border-pink-500/30'
            : 'bg-blue-600/20 text-blue-400 border-blue-500/30';

          const icon = isYouTube ? '▶️ YouTube' : isInsta ? '📸 Instagram' : '📘 Facebook';

          return (
            <div
              key={vid.id}
              className="group p-4 rounded-2xl bg-gradient-to-br from-[#1c0a33] to-[#120626] border border-amber-500/20 hover:border-amber-400/50 shadow-lg hover:shadow-2xl transition-all flex flex-col justify-between"
            >
              <div>
                {/* Platform Badge */}
                <div className="flex items-center justify-between mb-3">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${badgeColor}`}>
                    {icon}
                  </span>
                  <span className="text-xs text-amber-300/60 font-mono">2026</span>
                </div>

                {/* Video Title */}
                <h3 className="text-sm font-bold text-amber-100 font-festive group-hover:text-amber-300 transition-colors mb-2 line-clamp-2">
                  {lang === 'hi' ? vid.titleHi : vid.title}
                </h3>

                {vid.description && (
                  <p className="text-xs text-amber-200/70 font-hindi line-clamp-2 mb-4 leading-relaxed">
                    {vid.description}
                  </p>
                )}
              </div>

              {/* Action */}
              <div className="pt-3 border-t border-amber-500/15 flex items-center gap-2">
                {isYouTube ? (
                  <button
                    onClick={() => {
                      festiveAudio.playSparkle();
                      setActiveVideo(vid);
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/30 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5 fill-red-400 text-red-400" />
                    <span>{lang === 'hi' ? 'यहाँ देखें' : 'Watch'}</span>
                  </button>
                ) : (
                  <a
                    href={vid.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-amber-200 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>{lang === 'hi' ? 'खोलें' : 'Open'}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
                <button
                  onClick={() => {
                    festiveAudio.playDiwaliSongMelody();
                  }}
                  className="p-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 transition-colors"
                  title="Play Festive Audio"
                >
                  <Music className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* YouTube Watch Modal */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-3xl bg-[#17082a] border border-amber-500/30 rounded-3xl overflow-hidden shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b border-amber-500/20 bg-[#120524]">
              <h3 className="text-sm font-bold text-amber-200 truncate pr-4 font-festive">
                {lang === 'hi' ? activeVideo.titleHi : activeVideo.title}
              </h3>
              <button
                onClick={() => setActiveVideo(null)}
                className="p-1 rounded-lg text-amber-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Embedded Iframe */}
            <div className="relative aspect-video w-full bg-black">
              {activeVideo.embedId ? (
                <iframe
                  className="w-full h-full"
                  src={`https://www.youtube-nocookie.com/embed/${activeVideo.embedId}?autoplay=1&rel=0`}
                  title={activeVideo.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <div className="p-8 text-center text-amber-200">
                  <a
                    href={activeVideo.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline text-amber-400"
                  >
                    Click to view video directly
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
