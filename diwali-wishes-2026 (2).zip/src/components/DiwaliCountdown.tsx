import React, { useState, useEffect } from 'react';
import { Sparkles, Calendar, Flame } from 'lucide-react';
import { Card3D } from './Card3D';

interface CountdownProps {
  lang: 'hi' | 'en';
}

export const DiwaliCountdown: React.FC<CountdownProps> = ({ lang }) => {
  // Diwali 2026 Date: Sunday, November 8, 2026 (Kartik Amavasya)
  const targetDate = new Date('2026-11-08T18:00:00+05:30').getTime();

  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTime = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  return (
    <Card3D maxTilt={6} glare={true} className="w-full">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#21093b]/95 via-[#2b0f47]/95 to-[#1c0830]/95 border border-amber-500/35 p-4 sm:p-6 shadow-2xl gold-glow transform-style-3d">
        {/* Ornate 3D Glow Line */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent opacity-80" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-5 relative z-10 translate-z-20">
          {/* Left: Info */}
          <div className="flex items-center gap-3.5 text-center md:text-left">
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/10 border border-amber-500/40 flex items-center justify-center shrink-0 text-amber-300 shadow-md">
              <span className="text-2xl animate-flame">🪔</span>
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <span className="text-xs uppercase tracking-wider font-extrabold text-amber-300 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
                  {lang === 'hi' ? 'दीपावली महोत्सव 2026' : 'Diwali Celebration 2026'}
                </span>
                <span className="text-xs text-amber-400/50">·</span>
                <span className="text-xs font-semibold text-amber-200/90 font-hindi">
                  {lang === 'hi' ? 'रविवार, 8 नवंबर 2026' : 'Sunday, Nov 8, 2026'}
                </span>
              </div>
              <h3 className="text-base sm:text-xl font-bold text-amber-100 font-festive text-3d-gold mt-0.5">
                {lang === 'hi'
                  ? 'कार्तिक अमावस्या • विक्रम संवत 2083'
                  : 'Kartik Amavasya • Vikram Samvat 2083'}
              </h3>
            </div>
          </div>

          {/* Right: 3D Counter Dial Numbers */}
          <div className="flex items-center gap-2 sm:gap-3.5">
            {[
              { label: lang === 'hi' ? 'दिन' : 'Days', val: timeLeft.days, color: 'text-amber-300' },
              { label: lang === 'hi' ? 'घंटे' : 'Hours', val: timeLeft.hours, color: 'text-orange-300' },
              { label: lang === 'hi' ? 'मिनट' : 'Mins', val: timeLeft.minutes, color: 'text-yellow-300' },
              { label: lang === 'hi' ? 'सेकंड' : 'Secs', val: timeLeft.seconds, color: 'text-rose-300' },
            ].map((item, idx) => (
              <div
                key={idx}
                className="group flex flex-col items-center justify-center min-w-[62px] sm:min-w-[74px] px-2.5 py-2 rounded-2xl bg-gradient-to-b from-black/70 to-black/40 border border-amber-500/30 backdrop-blur-md shadow-lg hover:border-amber-400 transition-all transform-style-3d hover:translate-z-30 hover:-translate-y-1"
              >
                <span className={`text-2xl sm:text-3xl font-black ${item.color} font-mono tracking-tight text-3d-gold`}>
                  {String(item.val).padStart(2, '0')}
                </span>
                <span className="text-[10px] sm:text-xs font-bold text-amber-200/80 uppercase tracking-wider font-hindi mt-0.5">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card3D>
  );
};
