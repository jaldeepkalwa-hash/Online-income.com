import React, { useState } from 'react';
import { Sparkles, Heart, Shield, HelpCircle, X, ExternalLink } from 'lucide-react';
import { CATEGORIES } from '../data/categories';

interface FooterProps {
  lang: 'hi' | 'en';
  onSelectCategory: (catId: string) => void;
  onNavigateSeo: (slug: string) => void;
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  lang,
  onSelectCategory,
  onNavigateSeo,
  onNavigate,
}) => {
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const seoLinks = [
    { slug: 'seo/diwali-greetings', labelHi: 'दीपावली 2026 विशेस एवं कोट्स', labelEn: 'Diwali 2026 Wishes & Quotes' },
    { slug: 'seo/whatsapp-status', labelHi: 'दिवाली व्हाट्सएप स्टेटस (9:16)', labelEn: 'Diwali WhatsApp Status 9:16' },
    { slug: 'seo/diwali-images-with-name', labelHi: 'नाम और फोटो के साथ दिवाली इमेज', labelEn: 'Diwali Images with Name' },
    { slug: 'seo/business-diwali-wishes', labelHi: 'दुकान व व्यापार दिवाली संदेश', labelEn: 'Business & Shop Greetings' },
    { slug: 'seo/instagram-diwali-posts', labelHi: 'इंस्टाग्राम दिवाली स्टोरी टेम्पलेट्स', labelEn: 'Instagram Diwali Stories' },
  ];

  return (
    <footer className="bg-[#0b0417] border-t border-amber-500/20 pt-12 pb-24 sm:pb-12 text-amber-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Sanskrit Auspicious Shloka Banner */}
        <div className="text-center py-6 px-4 rounded-2xl bg-amber-500/5 border border-amber-500/20 mb-10 max-w-2xl mx-auto">
          <span className="text-2xl animate-flame block mb-1">🪔</span>
          <p className="text-base sm:text-lg font-bold text-amber-200 font-festive">
            ॐ असतो मा सद्गमय। तमसो मा ज्योतिर्गमय। मृत्योर्मा अमृतं गमय॥
          </p>
          <p className="text-xs text-amber-300/70 mt-1 font-hindi">
            {lang === 'hi'
              ? 'हे प्रभु! हमें असत्य से सत्य की ओर, अंधकार से प्रकाश की ओर और मृत्यु से अमरता की ओर ले चलें।'
              : 'Lead us from the unreal to the real, from darkness unto light, from mortality to immortality.'}
          </p>
        </div>

        {/* 4-Column Directory */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10 text-xs">
          {/* Col 1: About Platform */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-xl">🪔</span>
              <span className="text-base font-bold text-amber-100 font-festive">
                Diwali Wishes 2026
              </span>
            </div>
            <p className="text-amber-200/70 font-hindi leading-relaxed">
              {lang === 'hi'
                ? 'भारत के सबसे बड़े दीपोत्सव के लिए नि:शुल्क, सुंदर और व्यक्तिगत फोटो ग्रीटिंग कार्ड, व्हाट्सएप स्टेटस और हिंदी शुभकामनाएँ बनाने का आधुनिक मंच।'
                : 'A dedicated mobile-first platform to create, customize, and share authentic Indian Diwali wishes, personalized photo frames, and status updates.'}
            </p>
            <div className="pt-2 text-[11px] text-amber-300/60 font-mono">
              दीपावली: रविवार, 8 नवंबर 2026 (कार्तिक अमावस्या)
            </div>
          </div>

          {/* Col 2: Top Categories */}
          <div className="space-y-2">
            <h4 className="font-bold text-amber-100 uppercase tracking-wider text-xs">
              {lang === 'hi' ? 'प्रमुख श्रेणियां' : 'Top Categories'}
            </h4>
            <ul className="space-y-1.5 font-hindi">
              {CATEGORIES.slice(0, 7).map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => onSelectCategory(c.id)}
                    className="hover:text-amber-300 transition-colors text-left"
                  >
                    {lang === 'hi' ? c.nameHi : c.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: SEO Landing Pages */}
          <div className="space-y-2">
            <h4 className="font-bold text-amber-100 uppercase tracking-wider text-xs">
              {lang === 'hi' ? 'विशेष संग्रह (Special Guides)' : 'Festive Guides'}
            </h4>
            <ul className="space-y-1.5 font-hindi">
              {seoLinks.map((sl) => (
                <li key={sl.slug}>
                  <button
                    onClick={() => onNavigateSeo(sl.slug)}
                    className="hover:text-amber-300 transition-colors text-left"
                  >
                    {lang === 'hi' ? sl.labelHi : sl.labelEn}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Legal & Policies */}
          <div className="space-y-2">
            <h4 className="font-bold text-amber-100 uppercase tracking-wider text-xs">
              {lang === 'hi' ? 'नीति एवं सहायता' : 'Policies & Support'}
            </h4>
            <ul className="space-y-1.5">
              <li>
                <button
                  onClick={() => setActiveModal('about')}
                  className="hover:text-amber-300 transition-colors"
                >
                  {lang === 'hi' ? 'हमारे बारे में (About Us)' : 'About Us'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveModal('contact')}
                  className="hover:text-amber-300 transition-colors"
                >
                  {lang === 'hi' ? 'संपर्क करें (Contact Us)' : 'Contact Us'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveModal('privacy')}
                  className="hover:text-amber-300 transition-colors"
                >
                  {lang === 'hi' ? 'गोपनीयता नीति (Privacy Policy)' : 'Privacy Policy'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveModal('terms')}
                  className="hover:text-amber-300 transition-colors"
                >
                  {lang === 'hi' ? 'नियम व शर्तें (Terms of Service)' : 'Terms of Service'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveModal('disclaimer')}
                  className="hover:text-amber-300 transition-colors"
                >
                  {lang === 'hi' ? 'अस्वीकरण (Disclaimer)' : 'Disclaimer'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveModal('gsc')}
                  className="hover:text-amber-300 transition-colors text-amber-400/90 font-medium"
                >
                  Google Search Console & SEO Guide
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-6 border-t border-amber-500/15 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-amber-300/60">
          <div>
            © 2026 Diwali Wishes. All rights reserved. विक्रम संवत 2083.
          </div>
          <div className="flex items-center gap-2">
            <span>Made with devotion & festive spirit</span>
            <span className="text-rose-400">❤️</span>
            <span>in India</span>
          </div>
        </div>
      </div>

      {/* Legal & Policy Modals */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-[#190930] border border-amber-500/30 rounded-3xl p-6 shadow-2xl text-amber-100 my-6">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-amber-500/20">
              <h3 className="text-base font-bold font-festive text-amber-200">
                {activeModal === 'about' && 'हमारे बारे में (About Us)'}
                {activeModal === 'contact' && 'संपर्क सूत्र (Contact Us)'}
                {activeModal === 'privacy' && 'गोपनीयता नीति (Privacy Policy)'}
                {activeModal === 'terms' && 'उपयोग की शर्तें (Terms of Service)'}
                {activeModal === 'disclaimer' && 'अस्वीकरण (Disclaimer)'}
                {activeModal === 'gsc' && 'Google Search Console & Analytics Setup'}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-lg text-amber-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs leading-relaxed space-y-3 max-h-[60vh] overflow-y-auto pr-2 text-amber-200/90">
              {activeModal === 'about' && (
                <>
                  <p>
                    <strong>Diwali Wishes 2026</strong> एक निःशुल्क, आधुनिक एवं सुलभ वेब प्लेटफॉर्म है, जिसे भारतीय संस्कृति के सबसे बड़े उत्सव — दीपावली — की गरिमा और उल्लास को डिजिटल युग में जीवंत रखने के लिए विकसित किया गया है।
                  </p>
                  <p>
                    यहाँ प्रत्येक उपयोगकर्ता बिना किसी अनिवार्य लॉगिन अथवा भुगतान के अपने नाम, परिवार के सदस्यों, अथवा व्यावसायिक प्रतिष्ठान के नाम के साथ उच्च गुणवत्ता (HD) वाले ग्रीटिंग कार्ड्स तैयार कर सकते हैं।
                  </p>
                </>
              )}

              {activeModal === 'contact' && (
                <>
                  <p>
                    यदि आपके पास कोई प्रश्न, सुझाव अथवा किसी सामग्री के संबंध में सहायता की आवश्यकता है, तो आप हमारी सहायता टीम से संपर्क कर सकते हैं:
                  </p>
                  <p className="font-mono bg-black/40 p-2.5 rounded-xl border border-amber-500/20">
                    📧 Email: support@diwaliwishes2026.app<br />
                    📍 New Delhi, India<br />
                    ⏰ Response Time: 24 to 48 Hours
                  </p>
                </>
              )}

              {activeModal === 'privacy' && (
                <>
                  <p>
                    <strong>आपकी गोपनीयता हमारी सर्वोच्च प्राथमिकता है:</strong>
                  </p>
                  <ul className="list-disc pl-4 space-y-1.5">
                    <li>उपयोगकर्ता द्वारा अपलोड की गई तस्वीरें स्थानीय रूप से क्लाइंट-साइड (ब्राउज़र के HTML5 Canvas) पर प्रोसेस की जाती हैं और अनधिकृत रूप से तीसरे पक्ष के साथ साझा नहीं की जाती हैं।</li>
                    <li>पसंदीदा कार्ड एवं सेटिंग्स केवल आपके डिवाइस के स्थानीय स्टोरेज (LocalStorage) में सुरक्षित रहते हैं।</li>
                    <li>हम किसी भी भ्रामक शेयरिंग या गुप्त ट्रैकिंग कुकीज़ का उपयोग नहीं करते हैं।</li>
                  </ul>
                </>
              )}

              {activeModal === 'terms' && (
                <>
                  <p>
                    इस वेबसाइट का उपयोग केवल व्यक्तिगत, गैर-वाणिज्यिक अथवा वैध व्यावसायिक शुभकामनाओं के आदान-प्रदान के लिए किया जा सकता है।
                  </p>
                  <p>
                    किसी भी प्रकार की घृणास्पद, आपत्तिजनक, अश्लील अथवा भ्रामक सामग्री का निर्माण अथवा साझा करना सख्त वर्जित है।
                  </p>
                </>
              )}

              {activeModal === 'disclaimer' && (
                <>
                  <p>
                    सभी पारंपरिक श्लोक, मंत्र और दोहे सनातन सांस्कृतिक धरोहर का हिस्सा हैं। यह वेबसाइट किसी भी प्रकार के अनधिकृत व्यावसायिक लाभ अथवा कॉपीराइट उल्लंघन के इरादे से संचालित नहीं की जाती।
                  </p>
                  <p>
                    शुभ मुहूर्त एवं तिथियां शास्त्रीय पंचांग (विक्रम संवत 2083) के अनुसार सामान्य मार्गदर्शन हेतु प्रदान की गई हैं।
                  </p>
                  <p className="font-bold text-amber-300 mt-2">
                    विज्ञापन एवं एफिलिएट डिस्क्लोजर (Affiliate & Advertising Disclosure):
                  </p>
                  <p>
                    इस वेबसाइट पर प्रदर्शित कुछ लिंक (Amazon, Flipkart, Myntra, Adsterra आदि) एफिलिएट या प्रायोजित लिंक हो सकते हैं। जब आप इन लिंक्स के माध्यम से कोई वस्तु खरीदते हैं, तो वेबसाइट को बिना किसी अतिरिक्त शुल्क के छोटा कमीशन प्राप्त हो सकता है, जिससे इस निःशुल्क सेवा का संचालन जारी रखा जा सके।
                  </p>
                </>
              )}

              {activeModal === 'gsc' && (
                <>
                  <p className="font-bold text-amber-300">
                    Webmaster Instructions for Google Search Console:
                  </p>
                  <ol className="list-decimal pl-4 space-y-2">
                    <li>
                      <strong>Sitemap Submission:</strong> Add <code>https://yourdomain.com/sitemap.xml</code> into Google Search Console. It includes all 17 categories, greeting URLs, and landing pages.
                    </li>
                    <li>
                      <strong>Structured Data:</strong> The application incorporates Schema.org WebPage, Article, and FAQPage JSON-LD schemas.
                    </li>
                    <li>
                      <strong>Google Analytics 4:</strong> To add GA4 tracking, inject your Measurement ID (e.g., <code>G-XXXXXXXXXX</code>) into <code>index.html</code>.
                    </li>
                    <li>
                      <em>Note: Search engines index pages based on crawl budgets and search quality guidelines; automatic immediate indexing is never guaranteed.</em>
                    </li>
                  </ol>
                </>
              )}
            </div>

            <div className="pt-4 mt-4 border-t border-amber-500/20 text-right">
              <button
                onClick={() => setActiveModal(null)}
                className="px-4 py-2 rounded-xl bg-amber-500 text-purple-950 font-bold text-xs"
              >
                बंद करें (Close)
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
