import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';

interface GlobalThreeDiwaliWorldProps {
  enabled?: boolean;
}

export const GlobalThreeDiwaliWorld: React.FC<GlobalThreeDiwaliWorldProps> = ({
  enabled = true,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const container = containerRef.current;
    if (!container) return;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0d051a, 0.04);

    const camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(0, 1.2, 8);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    // 2. Lights
    const ambientLight = new THREE.AmbientLight(0x2d124d, 1.2);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0xf59e0b, 2.5, 12);
    pointLight.position.set(0, 1, 3);
    scene.add(pointLight);

    // 3. Floating 3D Diyas along the lower background horizon
    const diyasGroup = new THREE.Group();
    scene.add(diyasGroup);

    const clayMat = new THREE.MeshStandardMaterial({
      color: 0x9a3412,
      roughness: 0.65,
      metalness: 0.2,
    });
    const goldRimMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.8,
      roughness: 0.3,
    });
    const flameMat = new THREE.MeshBasicMaterial({ color: 0xffedd5 });
    const flameOuterMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.85,
    });

    const diyaFlames: Array<{ mesh: THREE.Group; light: THREE.PointLight; offset: number }> = [];

    const createFloatingDiya = (x: number, y: number, z: number, scale: number = 1) => {
      const g = new THREE.Group();
      g.position.set(x, y, z);
      g.scale.set(scale, scale, scale);

      // Bowl
      const baseGeo = new THREE.CylinderGeometry(0.35, 0.18, 0.18, 16);
      const bMesh = new THREE.Mesh(baseGeo, clayMat);
      g.add(bMesh);

      // Rim
      const rimGeo = new THREE.TorusGeometry(0.36, 0.03, 8, 20);
      rimGeo.rotateX(Math.PI / 2);
      rimGeo.translate(0, 0.09, 0);
      const rMesh = new THREE.Mesh(rimGeo, goldRimMat);
      g.add(rMesh);

      // Flame
      const fGroup = new THREE.Group();
      const fIn = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 10), flameMat);
      fIn.position.y = 0.22;
      const fOut = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.38, 10), flameOuterMat);
      fOut.position.y = 0.22;
      fGroup.add(fOut, fIn);
      g.add(fGroup);

      // Point Light
      const pLight = new THREE.PointLight(0xf59e0b, 1.2, 5);
      pLight.position.set(0, 0.3, 0);
      g.add(pLight);

      diyasGroup.add(g);
      diyaFlames.push({ mesh: fGroup, light: pLight, offset: Math.random() * 10 });
    };

    // Position background floating Diyas
    createFloatingDiya(-4.2, -1.8, -2, 0.9);
    createFloatingDiya(-2.2, -2.2, -1, 0.85);
    createFloatingDiya(2.2, -2.1, -1.2, 0.85);
    createFloatingDiya(4.2, -1.7, -2.5, 0.95);
    createFloatingDiya(0, -2.6, 0.5, 1.0);

    // 4. Floating Sky Lanterns (Akash Kandil) rising upward
    const lanternsGroup = new THREE.Group();
    scene.add(lanternsGroup);

    const lanternMat = new THREE.MeshStandardMaterial({
      color: 0xe11d48,
      emissive: 0x9f1239,
      emissiveIntensity: 0.6,
      roughness: 0.3,
    });

    interface LanternItem {
      mesh: THREE.Mesh;
      baseX: number;
      speedY: number;
      speedRot: number;
    }
    const lanterns: LanternItem[] = [];

    for (let i = 0; i < 16; i++) {
      const geo = new THREE.OctahedronGeometry(0.25 + Math.random() * 0.15, 0);
      const m = new THREE.Mesh(geo, lanternMat);
      const x = (Math.random() - 0.5) * 16;
      const y = -3 + Math.random() * 10;
      const z = -2 - Math.random() * 10;
      m.position.set(x, y, z);
      lanternsGroup.add(m);

      lanterns.push({
        mesh: m,
        baseX: x,
        speedY: 0.004 + Math.random() * 0.006,
        speedRot: 0.008 + Math.random() * 0.012,
      });
    }

    // 5. 3D Golden Sparkle Particle System across entire viewport
    const particleCount = 380;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 20;
      positions[i + 1] = (Math.random() - 0.5) * 14;
      positions[i + 2] = (Math.random() - 0.5) * 12;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0xfef08a,
      size: 0.07,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    scene.add(particleSystem);

    // 6. Interactive Fireworks System triggered on global clicks
    const fireworks: Array<{
      points: THREE.Points;
      vels: Float32Array;
      life: number;
      maxLife: number;
    }> = [];

    const triggerBurst = (screenX: number, screenY: number) => {
      // Map screen coordinates to approximate 3D world plane (Z = 0)
      const normX = (screenX / window.innerWidth) * 2 - 1;
      const normY = -(screenY / window.innerHeight) * 2 + 1;
      const worldX = normX * 6.5;
      const worldY = normY * 4.5 + 1.2;
      const worldZ = -1 - Math.random() * 2;

      const pCount = 120;
      const geo = new THREE.BufferGeometry();
      const pos = new Float32Array(pCount * 3);
      const vel = new Float32Array(pCount * 3);

      const colors = [0xf59e0b, 0xf43f5e, 0x10b981, 0xa855f7, 0xfde047];
      const color = new THREE.Color(colors[Math.floor(Math.random() * colors.length)]);

      for (let i = 0; i < pCount * 3; i += 3) {
        pos[i] = worldX;
        pos[i + 1] = worldY;
        pos[i + 2] = worldZ;

        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        const speed = 0.04 + Math.random() * 0.08;

        vel[i] = speed * Math.sin(phi) * Math.cos(theta);
        vel[i + 1] = speed * Math.cos(phi);
        vel[i + 2] = speed * Math.sin(phi) * Math.sin(theta);
      }

      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.PointsMaterial({
        color,
        size: 0.09,
        transparent: true,
        opacity: 1,
        blending: THREE.AdditiveBlending,
      });

      const pts = new THREE.Points(geo, mat);
      scene.add(pts);

      fireworks.push({
        points: pts,
        vels: vel,
        life: 0,
        maxLife: 45,
      });
    };

    const handleWindowClick = (e: MouseEvent) => {
      // Small 3D firework burst near click position
      triggerBurst(e.clientX, e.clientY);
    };
    window.addEventListener('click', handleWindowClick);

    // Mouse / Parallax Tracking
    let targetX = 0;
    let targetY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      targetX = ((e.clientX / window.innerWidth) * 2 - 1) * 0.4;
      targetY = (-(e.clientY / window.innerHeight) * 2 + 1) * 0.25;
    };
    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    // Resize Handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // 7. Animation Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Smooth camera parallax
      camera.position.x += (targetX - camera.position.x) * 0.04;
      camera.position.y += (1.2 + targetY - camera.position.y) * 0.04;

      // Flame flicker
      diyaFlames.forEach((item) => {
        const s = 1 + Math.sin(elapsed * 14 + item.offset) * 0.12;
        item.mesh.scale.set(s, 1 + Math.cos(elapsed * 16 + item.offset) * 0.18, s);
        item.light.intensity = 1.0 + Math.sin(elapsed * 18 + item.offset) * 0.3;
      });

      // Sky Lanterns gentle ascent
      lanterns.forEach((item) => {
        item.mesh.position.y += item.speedY;
        item.mesh.rotation.y += item.speedRot;
        item.mesh.position.x = item.baseX + Math.sin(elapsed * 0.8 + item.speedY * 100) * 0.3;

        // Loop back down when too high
        if (item.mesh.position.y > 8) {
          item.mesh.position.y = -4;
        }
      });

      // Golden particle drift
      particleSystem.rotation.y = elapsed * 0.015;
      particleSystem.rotation.x = Math.sin(elapsed * 0.01) * 0.03;

      // Fireworks update
      for (let i = fireworks.length - 1; i >= 0; i--) {
        const fw = fireworks[i];
        fw.life++;
        const posAttr = fw.points.geometry.getAttribute('position') as THREE.BufferAttribute;
        const posArr = posAttr.array as Float32Array;

        for (let j = 0; j < posArr.length; j += 3) {
          posArr[j] += fw.vels[j];
          posArr[j + 1] += fw.vels[j + 1];
          posArr[j + 2] += fw.vels[j + 2];
          fw.vels[j + 1] -= 0.003; // gravity
        }
        posAttr.needsUpdate = true;

        const mat = fw.points.material as THREE.PointsMaterial;
        mat.opacity = 1 - fw.life / fw.maxLife;

        if (fw.life >= fw.maxLife) {
          scene.remove(fw.points);
          fw.points.geometry.dispose();
          mat.dispose();
          fireworks.splice(i, 1);
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('click', handleWindowClick);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);

      if (container && renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none select-none z-0 overflow-hidden opacity-85"
      aria-hidden="true"
    />
  );
};
