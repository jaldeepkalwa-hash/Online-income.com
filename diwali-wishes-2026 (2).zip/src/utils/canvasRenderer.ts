import { AspectRatioType, CardTheme, PlacedSticker } from '../types/greeting';

export interface RenderCanvasOptions {
  canvas: HTMLCanvasElement;
  aspectRatio: AspectRatioType;
  theme: CardTheme;
  recipientName: string;
  senderName: string;
  businessName?: string;
  messageText: string;
  language: 'hi' | 'en';
  fontFamily: string;
  fontSize: number; // multiplier e.g. 1.0, 1.2
  textColor: string;
  textShadow: boolean;
  textAlign: 'center' | 'left' | 'right';
  userPhoto?: HTMLImageElement | null;
  photoShape?: 'circle' | 'square' | 'rounded';
  photoPosition?: { x: number; y: number; scale: number };
  stickers?: PlacedSticker[];
}

export function getCanvasDimensions(ratio: AspectRatioType): { width: number; height: number } {
  switch (ratio) {
    case '9:16':
      return { width: 1080, height: 1920 };
    case '4:5':
      return { width: 1080, height: 1350 };
    case '16:9':
      return { width: 1920, height: 1080 };
    case '1:1':
    default:
      return { width: 1080, height: 1080 };
  }
}

// Background gradient definitions for themes
const THEME_GRADIENTS: Record<CardTheme, { bg1: string; bg2: string; bg3: string; accent: string; gold: string }> = {
  'royal-purple': { bg1: '#320b57', bg2: '#1a0533', bg3: '#0c0217', accent: '#c084fc', gold: '#fde047' },
  'golden-amber': { bg1: '#4a2505', bg2: '#281202', bg3: '#130801', accent: '#f59e0b', gold: '#fef08a' },
  'crimson-divine': { bg1: '#54091a', bg2: '#2b030b', bg3: '#140105', accent: '#fb7185', gold: '#fde047' },
  'midnight-blue': { bg1: '#0f172a', bg2: '#060e20', bg3: '#02050e', accent: '#60a5fa', gold: '#facc15' },
  'saffron-glow': { bg1: '#5c2406', bg2: '#301103', bg3: '#140701', accent: '#fb923c', gold: '#fde047' },
  'emerald-festive': { bg1: '#063d27', bg2: '#031f13', bg3: '#010f09', accent: '#34d399', gold: '#fde047' },
  'temple-gold': { bg1: '#472a04', bg2: '#261502', bg3: '#0f0801', accent: '#eab308', gold: '#fef9c3' },
};

/**
 * Draw ornate mandala geometric patterns on canvas
 */
function drawMandalaWatermark(ctx: CanvasRenderingContext2D, cx: number, cy: number, radius: number, alpha: number) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = `rgba(253, 224, 71, ${alpha})`;
  ctx.lineWidth = 1.5;

  const petals = 16;
  for (let i = 0; i < petals; i++) {
    ctx.rotate((Math.PI * 2) / petals);
    ctx.beginPath();
    ctx.arc(0, radius * 0.45, radius * 0.25, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(radius * 0.35, radius * 0.7, 0, radius);
    ctx.quadraticCurveTo(-radius * 0.35, radius * 0.7, 0, 0);
    ctx.stroke();
  }

  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.8, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.3, 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
}

/**
 * Draw ornate decorative corners and borders
 */
function drawGoldBorder(ctx: CanvasRenderingContext2D, w: number, h: number, goldColor: string) {
  ctx.save();
  const pad = 36;
  const innerPad = 48;

  // Outer border
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
  ctx.lineWidth = 2;
  ctx.strokeRect(pad, pad, w - pad * 2, h - pad * 2);

  // Inner border
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.8)';
  ctx.lineWidth = 3;
  ctx.strokeRect(innerPad, innerPad, w - innerPad * 2, h - innerPad * 2);

  // Corner ornaments
  const cornerSize = 40;
  const corners = [
    { x: innerPad, y: innerPad, dx: 1, dy: 1 },
    { x: w - innerPad, y: innerPad, dx: -1, dy: 1 },
    { x: innerPad, y: h - innerPad, dx: 1, dy: -1 },
    { x: w - innerPad, y: h - innerPad, dx: -1, dy: -1 },
  ];

  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 4;
  corners.forEach((c) => {
    ctx.beginPath();
    ctx.moveTo(c.x, c.y + c.dy * cornerSize);
    ctx.lineTo(c.x, c.y);
    ctx.lineTo(c.x + c.dx * cornerSize, c.y);
    ctx.stroke();

    // Corner dot
    ctx.fillStyle = goldColor;
    ctx.beginPath();
    ctx.arc(c.x + c.dx * 12, c.y + c.dy * 12, 4, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.restore();
}

/**
 * Draw an authentic clay diya lamp with glowing flame
 */
function drawDiyaLamp(ctx: CanvasRenderingContext2D, x: number, y: number, scale: number = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  // Diya base (terracotta / bronze)
  const baseGrad = ctx.createLinearGradient(0, 0, 0, 40);
  baseGrad.addColorStop(0, '#ea580c');
  baseGrad.addColorStop(0.5, '#9a3412');
  baseGrad.addColorStop(1, '#431407');

  ctx.fillStyle = baseGrad;
  ctx.beginPath();
  ctx.ellipse(0, 10, 48, 18, 0, 0, Math.PI);
  ctx.lineTo(-48, 10);
  ctx.closePath();
  ctx.fill();

  // Rim gold ornament
  ctx.strokeStyle = '#fde047';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Flame glow
  const glowGrad = ctx.createRadialGradient(0, -18, 4, 0, -18, 55);
  glowGrad.addColorStop(0, 'rgba(254, 240, 138, 0.9)');
  glowGrad.addColorStop(0.35, 'rgba(245, 158, 11, 0.6)');
  glowGrad.addColorStop(0.7, 'rgba(234, 88, 12, 0.25)');
  glowGrad.addColorStop(1, 'rgba(234, 88, 12, 0)');

  ctx.fillStyle = glowGrad;
  ctx.beginPath();
  ctx.arc(0, -18, 55, 0, Math.PI * 2);
  ctx.fill();

  // Flame teardrop
  const flameGrad = ctx.createLinearGradient(0, 10, 0, -35);
  flameGrad.addColorStop(0, '#ea580c');
  flameGrad.addColorStop(0.4, '#f59e0b');
  flameGrad.addColorStop(0.85, '#fef08a');
  flameGrad.addColorStop(1, '#ffffff');

  ctx.fillStyle = flameGrad;
  ctx.beginPath();
  ctx.moveTo(0, -38);
  ctx.bezierCurveTo(14, -22, 14, 2, 0, 4);
  ctx.bezierCurveTo(-14, 2, -14, -22, 0, -38);
  ctx.fill();

  ctx.restore();
}

/**
 * Wrap text nicely across multiple lines
 */
function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let currentLine = words[0] || '';

  for (let i = 1; i < words.length; i++) {
    const word = words[i];
    const width = ctx.measureText(currentLine + ' ' + word).width;
    if (width < maxWidth) {
      currentLine += ' ' + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  if (currentLine) {
    lines.push(currentLine);
  }
  return lines;
}

/**
 * Main export & render function
 */
export async function renderGreetingCanvas(options: RenderCanvasOptions): Promise<void> {
  const {
    canvas,
    aspectRatio,
    theme,
    recipientName,
    senderName,
    businessName,
    messageText,
    language,
    fontFamily,
    fontSize,
    textColor,
    textShadow,
    textAlign,
    userPhoto,
    photoShape = 'circle',
    photoPosition = { x: 50, y: 78, scale: 1 },
    stickers = [],
  } = options;

  // Ensure custom web fonts are fully loaded before rendering to canvas
  try {
    if (document.fonts) {
      await document.fonts.ready;
    }
  } catch {
    // Continue
  }

  const { width: W, height: H } = getCanvasDimensions(aspectRatio);
  canvas.width = W;
  canvas.height = H;

  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) return;

  const colors = THEME_GRADIENTS[theme] || THEME_GRADIENTS['royal-purple'];

  // 1. Draw Background Gradient
  const bgGrad = ctx.createRadialGradient(W / 2, H * 0.35, 10, W / 2, H / 2, Math.max(W, H) * 0.85);
  bgGrad.addColorStop(0, colors.bg1);
  bgGrad.addColorStop(0.55, colors.bg2);
  bgGrad.addColorStop(1, colors.bg3);
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  // 2. Watermark Mandalas
  drawMandalaWatermark(ctx, W / 2, H * 0.32, Math.min(W, H) * 0.38, 0.08);
  drawMandalaWatermark(ctx, 0, 0, Math.min(W, H) * 0.25, 0.06);
  drawMandalaWatermark(ctx, W, 0, Math.min(W, H) * 0.25, 0.06);

  // 3. Ornate Gold Border & Corners
  drawGoldBorder(ctx, W, H, colors.gold);

  // 4. Auspicious Header Motifs
  ctx.save();
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `600 ${Math.round(28 * fontSize)}px 'Noto Sans Devanagari', sans-serif`;
  ctx.fillStyle = colors.gold;
  ctx.fillText('॥ शुभ दीपावली ॥', W / 2, H * 0.085);
  ctx.restore();

  // 5. Decorative Top Hanging Lanterns / Diyas
  drawDiyaLamp(ctx, W * 0.18, H * 0.14, 0.75);
  drawDiyaLamp(ctx, W * 0.82, H * 0.14, 0.75);
  drawDiyaLamp(ctx, W / 2, H * 0.2, 1.1);

  // 6. Draw User Uploaded Photo (if present)
  if (userPhoto && userPhoto.complete && userPhoto.naturalWidth > 0) {
    ctx.save();
    const photoPxX = (photoPosition.x / 100) * W;
    const photoPxY = (photoPosition.y / 100) * H;
    const basePhotoSize = Math.min(W, H) * 0.22 * photoPosition.scale;

    ctx.save();
    if (photoShape === 'circle') {
      ctx.beginPath();
      ctx.arc(photoPxX, photoPxY, basePhotoSize / 2, 0, Math.PI * 2);
      ctx.clip();
    } else if (photoShape === 'rounded') {
      const r = 24;
      const x0 = photoPxX - basePhotoSize / 2;
      const y0 = photoPxY - basePhotoSize / 2;
      ctx.beginPath();
      ctx.roundRect(x0, y0, basePhotoSize, basePhotoSize, r);
      ctx.clip();
    } else {
      ctx.beginPath();
      ctx.rect(photoPxX - basePhotoSize / 2, photoPxY - basePhotoSize / 2, basePhotoSize, basePhotoSize);
      ctx.clip();
    }

    // Draw image centered in clip
    ctx.drawImage(
      userPhoto,
      photoPxX - basePhotoSize / 2,
      photoPxY - basePhotoSize / 2,
      basePhotoSize,
      basePhotoSize
    );
    ctx.restore();

    // Photo Gold Rim Frame
    ctx.strokeStyle = colors.gold;
    ctx.lineWidth = 4;
    if (photoShape === 'circle') {
      ctx.beginPath();
      ctx.arc(photoPxX, photoPxY, basePhotoSize / 2, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      ctx.strokeRect(photoPxX - basePhotoSize / 2, photoPxY - basePhotoSize / 2, basePhotoSize, basePhotoSize);
    }
    ctx.restore();
  }

  // 7. Typography Layout
  ctx.save();
  if (textShadow) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 3;
  }

  // Recipient Name
  if (recipientName.trim()) {
    ctx.font = `600 ${Math.round(34 * fontSize)}px ${fontFamily}, 'Noto Sans Devanagari', sans-serif`;
    ctx.fillStyle = colors.gold;
    ctx.textAlign = textAlign;
    const rx = textAlign === 'center' ? W / 2 : textAlign === 'left' ? W * 0.12 : W * 0.88;
    const recipientText = language === 'hi' ? `प्रिय ${recipientName},` : `Dear ${recipientName},`;
    ctx.fillText(recipientText, rx, H * 0.31);
  }

  // Festival Heading
  ctx.font = `900 ${Math.round(62 * fontSize)}px 'Rozha One', 'Cinzel', 'Noto Sans Devanagari', serif`;
  ctx.fillStyle = colors.gold;
  ctx.textAlign = 'center';
  const headingText = language === 'hi' ? 'दीपावली की हार्दिक शुभकामनाएँ' : 'Happy Diwali 2026';
  ctx.fillText(headingText, W / 2, H * 0.39);

  // Sub-year tag
  ctx.font = `700 ${Math.round(26 * fontSize)}px 'Outfit', sans-serif`;
  ctx.fillStyle = colors.accent;
  ctx.fillText('✨ संवत २०८३ • FESTIVAL OF LIGHTS ✨', W / 2, H * 0.44);

  // Greeting Message Body
  ctx.font = `500 ${Math.round(36 * fontSize)}px ${fontFamily}, 'Noto Sans Devanagari', sans-serif`;
  ctx.fillStyle = textColor;
  ctx.textAlign = textAlign;
  const msgX = textAlign === 'center' ? W / 2 : textAlign === 'left' ? W * 0.12 : W * 0.88;
  const maxTextWidth = W * 0.78;
  const lines = wrapText(ctx, messageText, maxTextWidth);
  const startY = H * 0.50;
  const lineHeight = 54 * fontSize;

  lines.forEach((line, index) => {
    ctx.fillText(line, msgX, startY + index * lineHeight);
  });

  // Sender Name & Warm Regards
  const footerBaseY = H * 0.86;
  if (senderName.trim()) {
    ctx.textAlign = 'center';
    ctx.font = `600 ${Math.round(26 * fontSize)}px 'Outfit', 'Noto Sans Devanagari', sans-serif`;
    ctx.fillStyle = colors.accent;
    const senderPrefix = language === 'hi' ? 'सस्नेह मंगलकामनाएँ' : 'With Warmest Wishes From';
    ctx.fillText(senderPrefix, W / 2, footerBaseY - 38);

    ctx.font = `800 ${Math.round(44 * fontSize)}px 'Rozha One', 'Cinzel', 'Noto Sans Devanagari', serif`;
    ctx.fillStyle = colors.gold;
    ctx.fillText(senderName, W / 2, footerBaseY);
  }

  // Business / Shop Name (if provided)
  if (businessName && businessName.trim()) {
    ctx.textAlign = 'center';
    ctx.font = `700 ${Math.round(30 * fontSize)}px 'Outfit', 'Noto Sans Devanagari', sans-serif`;
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`॥ शुभ लाभ ॥  ${businessName}`, W / 2, footerBaseY + 44);
  }

  ctx.restore();

  // 8. Bottom Center Diya Pair
  drawDiyaLamp(ctx, W * 0.32, H * 0.94, 0.85);
  drawDiyaLamp(ctx, W * 0.68, H * 0.94, 0.85);

  // 9. Additional User Placed Stickers
  if (stickers && stickers.length > 0) {
    stickers.forEach((s) => {
      const sx = (s.x / 100) * W;
      const sy = (s.y / 100) * H;
      drawDiyaLamp(ctx, sx, sy, s.scale);
    });
  }
}

/**
 * Export canvas to Downloadable Blob or DataURL
 */
export function exportCanvasImage(canvas: HTMLCanvasElement, format: 'png' | 'jpeg' = 'png'): string {
  const mime = format === 'jpeg' ? 'image/jpeg' : 'image/png';
  return canvas.toDataURL(mime, 0.95);
}
