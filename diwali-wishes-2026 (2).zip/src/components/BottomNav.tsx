import React from 'react';
import { Home, Layers, Plus, Heart, Shield, Box } from 'lucide-react';

interface BottomNavProps {
  currentView: string;
  onNavigate: (view: string) => void;
  lang: 'hi' | 'en';
  favCount: number;
  onOpen3D?: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentView,
  onNavigate,
  lang,
  favCount,
  onOpen3D,
}) => {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#130626]/95 backdrop-blur-lg border-t border-amber-500/30 px-2 py-1.5 shadow-[0_-8px_20px_rgba(0,0,0,0.5)]">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* Home */}
        <button
          onClick={() => onNavigate('home')}
          className={`flex flex-col items-center py-1 px-2 rounded-xl transition-colors ${
            currentView === 'home' ? 'text-amber-300 font-bold' : 'text-amber-200/60 hover:text-amber-200'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-medium">
            {lang === 'hi' ? 'होम' : 'Home'}
          </span>
        </button>

        {/* 3D Mode */}
        <button
          onClick={() => {
            if (onOpen3D) onOpen3D();
          }}
          className="flex flex-col items-center py-1 px-2 rounded-xl transition-colors text-amber-300 hover:text-amber-100"
        >
          <Box className="w-5 h-5 text-amber-400 animate-pulse" />
          <span className="text-[10px] mt-0.5 font-bold">
            {lang === 'hi' ? '3D दर्शन' : '3D World'}
          </span>
        </button>

        {/* Center Create Button with Glowing Diya */}
        <button
          onClick={() => onNavigate('create')}
          className="relative -top-4 flex flex-col items-center justify-center w-13 h-13 rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-red-600 text-purple-950 shadow-xl gold-glow active:scale-95 transition-transform"
          aria-label="Create Greeting"
        >
          <span className="text-2xl animate-flame">🪔</span>
        </button>

        {/* Categories */}
        <button
          onClick={() => onNavigate('categories')}
          className={`flex flex-col items-center py-1 px-2 rounded-xl transition-colors ${
            currentView === 'categories' ? 'text-amber-300 font-bold' : 'text-amber-200/60 hover:text-amber-200'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-medium">
            {lang === 'hi' ? 'श्रेणियां' : 'Categories'}
          </span>
        </button>

        {/* Favorites */}
        <button
          onClick={() => onNavigate('favorites')}
          className={`relative flex flex-col items-center py-1 px-2 rounded-xl transition-colors ${
            currentView === 'favorites' ? 'text-amber-300 font-bold' : 'text-amber-200/60 hover:text-amber-200'
          }`}
        >
          <Heart className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-medium">
            {lang === 'hi' ? 'पसंदीदा' : 'Favorites'}
          </span>
          {favCount > 0 && (
            <span className="absolute top-0 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
              {favCount}
            </span>
          )}
        </button>
      </div>
    </nav>
  );
};
