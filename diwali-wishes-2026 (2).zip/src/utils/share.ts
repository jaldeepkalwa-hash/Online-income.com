/**
 * Social sharing helper with real platform URLs, native Web Share API, and click tracking.
 */

export interface ShareOptions {
  title: string;
  text: string;
  url: string;
  cardId?: string;
}

export async function recordShareClick(platform: string, cardId: string = 'general') {
  try {
    fetch('/api/analytics/share-click', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ platform, cardId }),
    }).catch(() => {});
  } catch {
    // Non-blocking
  }
}

export async function shareToNative(options: ShareOptions): Promise<boolean> {
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: options.title,
        text: options.text,
        url: options.url,
      });
      recordShareClick('native', options.cardId);
      return true;
    } catch (err: unknown) {
      if (err instanceof Error && err.name !== 'AbortError') {
        // Fall back to copy
      }
    }
  }
  return false;
}

export function shareToWhatsApp(options: ShareOptions) {
  recordShareClick('whatsapp', options.cardId);
  const message = `${options.text}\n\n✨ शुभकामना यहाँ देखें: ${options.url}`;
  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
  window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
}

export function shareToFacebook(options: ShareOptions) {
  recordShareClick('facebook', options.cardId);
  const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(options.url)}&quote=${encodeURIComponent(options.text)}`;
  window.open(fbUrl, '_blank', 'noopener,noreferrer,width=600,height=500');
}

export function shareToTwitter(options: ShareOptions) {
  recordShareClick('twitter', options.cardId);
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(options.text)}&url=${encodeURIComponent(options.url)}&hashtags=HappyDiwali2026,DiwaliWishes,ShubhDeepawali`;
  window.open(twitterUrl, '_blank', 'noopener,noreferrer,width=600,height=500');
}

export function shareToTelegram(options: ShareOptions) {
  recordShareClick('telegram', options.cardId);
  const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(options.url)}&text=${encodeURIComponent(options.text)}`;
  window.open(tgUrl, '_blank', 'noopener,noreferrer');
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.left = '-999999px';
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      const success = document.execCommand('copy');
      document.body.removeChild(textarea);
      return success;
    }
  } catch {
    return false;
  }
}
