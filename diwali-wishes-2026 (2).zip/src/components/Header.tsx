import React, { useState, useEffect } from 'react';
import { Sparkles, Heart, Volume2, VolumeX, Shield, PlusCircle, Menu, X, Box } from 'lucide-react';
import { festiveAudio } from '../utils/audio';
import { getFavorites } from '../utils/storage';

interface HeaderProps {
  lang: 'hi' | 'en';
  onToggleLang: () => void;
  onNavigate: (view: string, param?: string) => void;
  currentView: string;
  onOpen3D?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  onNavigate,
  currentView,
  onOpen3D,
}) => {
  const [isMuted, setIsMuted] = useState(festiveAudio.getMuted());
  const [favCount, setFavCount] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const updateFavs = () => {
      setFavCount(getFavorites().length);
    };
    updateFavs();
    window.addEventListener('storage', updateFavs);
    const interval = setInterval(updateFavs, 2000);
    return () => {
      window.removeEventListener('storage', updateFavs);
      clearInterval(interval);
    };
  }, []);

  const handleToggleSound = () => {
    const nextState = festiveAudio.toggleMute();
    setIsMuted(nextState);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#120626]/90 backdrop-blur-md border-b border-amber-500/20 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Brand */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 group text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-lg p-1"
          >
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-red-600 p-0.5 shadow-md gold-glow-sm">
              <div className="w-full h-full bg-[#1e0a36] rounded-[10px] flex items-center justify-center relative overflow-hidden">
                <span className="text-xl sm:text-2xl animate-flame">🪔</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg sm:text-xl font-extrabold tracking-wide text-amber-100 font-festive group-hover:text-amber-300 transition-colors">
                  {lang === 'hi' ? 'दीपावली विशेस' : 'Diwali Wishes'}
                </span>
                <span className="text-xs px-1.5 py-0.2 font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded">
                  2026
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-amber-200/70 font-hindi hidden sm:block">
                {lang === 'hi' ? 'शुभ दीपावली कार्ड एवं स्टेटस मेकर' : 'Festival Greetings & Card Maker'}
              </p>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => onNavigate('home')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentView === 'home'
                  ? 'text-amber-300 bg-amber-500/10 border border-amber-500/20'
                  : 'text-amber-100/80 hover:text-amber-200 hover:bg-white/5'
              }`}
            >
              {lang === 'hi' ? 'मुख्य पृष्ठ' : 'Home'}
            </button>
            <button
              onClick={() => onNavigate('gallery')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentView === 'gallery'
                  ? 'text-amber-300 bg-amber-500/10 border border-amber-500/20'
                  : 'text-amber-100/80 hover:text-amber-200 hover:bg-white/5'
              }`}
            >
              {lang === 'hi' ? '100+ डिजाइन्स' : '100+ Designs'}
            </button>
            <button
              onClick={() => onNavigate('categories')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentView === 'categories'
                  ? 'text-amber-300 bg-amber-500/10 border border-amber-500/20'
                  : 'text-amber-100/80 hover:text-amber-200 hover:bg-white/5'
              }`}
            >
              {lang === 'hi' ? 'श्रेणियां' : 'Categories'}
            </button>
            <button
              onClick={() => onNavigate('favorites')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
                currentView === 'favorites'
                  ? 'text-amber-300 bg-amber-500/10 border border-amber-500/20'
                  : 'text-amber-100/80 hover:text-amber-200 hover:bg-white/5'
              }`}
            >
              <Heart className="w-4 h-4 text-rose-400" />
              <span>{lang === 'hi' ? 'पसंदीदा' : 'Favorites'}</span>
              {favCount > 0 && (
                <span className="text-xs bg-rose-500/30 text-rose-300 px-1.5 py-0.5 rounded-full font-bold">
                  {favCount}
                </span>
              )}
            </button>
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Audio Toggle */}
            <button
              onClick={handleToggleSound}
              className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-purple-950/60 border border-amber-500/20 text-amber-200 hover:text-amber-100 hover:border-amber-400/40 transition-colors flex items-center gap-1.5 text-xs font-medium"
              title={isMuted ? 'Play Festive Chime' : 'Mute Sound'}
              aria-label="Festive audio toggle"
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-4 h-4 text-amber-400/70" />
                  <span className="hidden sm:inline">{lang === 'hi' ? 'ध्वनि' : 'Sound'}</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span className="hidden sm:inline text-amber-300">{lang === 'hi' ? 'चालू' : 'On'}</span>
                </>
              )}
            </button>

            {/* 3D Virtual Darshan Button */}
            <button
              onClick={() => onOpen3D && onOpen3D()}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-red-500/20 border border-amber-400/50 hover:border-amber-300 text-amber-200 hover:text-amber-100 text-xs font-black transition-all flex items-center gap-1.5 shadow-md gold-glow-sm"
              title="Experience 3D Virtual Diwali Courtyard & Firecrackers"
            >
              <Box className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'hi' ? '3D दर्शन' : '3D Mode'}</span>
            </button>

            {/* Language Toggle */}
            <button
              onClick={onToggleLang}
              className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/15 to-orange-500/15 border border-amber-500/30 text-amber-200 hover:text-amber-100 hover:border-amber-400 text-xs font-bold transition-all shadow-sm"
              title="Toggle Language"
            >
              {lang === 'hi' ? 'English' : 'हिन्दी'}
            </button>

            {/* Admin Link */}
            <button
              onClick={() => onNavigate('admin')}
              className="p-2 rounded-xl text-amber-300/80 hover:text-amber-200 hover:bg-white/5 transition-colors hidden sm:flex"
              title="Admin Dashboard"
              aria-label="Admin Dashboard"
            >
              <Shield className="w-4 h-4" />
            </button>

            {/* Create Greeting CTA */}
            <button
              onClick={() => onNavigate('create')}
              className="flex items-center gap-1.5 px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-purple-950 font-bold text-xs sm:text-sm shadow-lg hover:brightness-110 active:scale-95 transition-all gold-glow-sm"
            >
              <PlusCircle className="w-4 h-4 shrink-0 text-purple-950 stroke-[2.5]" />
              <span className="whitespace-nowrap">{lang === 'hi' ? 'कार्ड बनाएं' : 'Create Card'}</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-amber-200 hover:bg-white/10 md:hidden"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#16072e] border-b border-amber-500/30 px-4 pt-2 pb-4 space-y-1">
          <button
            onClick={() => {
              onNavigate('home');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-amber-100 hover:bg-white/5 rounded-lg"
          >
            {lang === 'hi' ? 'मुख्य पृष्ठ (Home)' : 'Home'}
          </button>
          <button
            onClick={() => {
              if (onOpen3D) onOpen3D();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm font-bold text-amber-300 hover:bg-white/5 rounded-lg flex items-center gap-2 bg-amber-500/10 border border-amber-500/20"
          >
            <Box className="w-4 h-4 text-amber-400" />
            <span>{lang === 'hi' ? '🪔 3D वर्चुअल दीपोत्सव दर्शन' : '🪔 3D Virtual Diwali Courtyard'}</span>
          </button>
          <button
            onClick={() => {
              onNavigate('gallery');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-amber-100 hover:bg-white/5 rounded-lg"
          >
            {lang === 'hi' ? '100+ ग्रीटिंग डिजाइन्स' : '100+ Greeting Designs'}
          </button>
          <button
            onClick={() => {
              onNavigate('categories');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-amber-100 hover:bg-white/5 rounded-lg"
          >
            {lang === 'hi' ? 'सभी 17 श्रेणियां' : 'All 17 Categories'}
          </button>
          <button
            onClick={() => {
              onNavigate('favorites');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-amber-100 hover:bg-white/5 rounded-lg flex items-center justify-between"
          >
            <span>{lang === 'hi' ? 'पसंदीदा कार्ड (Favorites)' : 'Favorites'}</span>
            {favCount > 0 && (
              <span className="text-xs bg-rose-500/30 text-rose-300 px-2 py-0.5 rounded-full font-bold">
                {favCount}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              onNavigate('admin');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-amber-100 hover:bg-white/5 rounded-lg flex items-center gap-2"
          >
            <Shield className="w-4 h-4 text-amber-400" />
            <span>{lang === 'hi' ? 'व्यवस्थापक डैशबोर्ड (Admin)' : 'Admin Dashboard'}</span>
          </button>
        </div>
      )}
    </header>
  );
};
