import React from 'react';
import { Sparkles, Wand2, Search, Shuffle, ArrowRight, Box } from 'lucide-react';
import confetti from 'canvas-confetti';
import { festiveAudio } from '../utils/audio';
import { ThreeDiwaliScene } from './ThreeDiwaliScene';
import { Card3D } from './Card3D';

interface HeroProps {
  lang: 'hi' | 'en';
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onCreateClick: () => void;
  onRandomClick: () => void;
  onExploreGallery: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  lang,
  searchQuery,
  onSearchChange,
  onCreateClick,
  onRandomClick,
  onExploreGallery,
}) => {
  const triggerCelebration = () => {
    festiveAudio.playSparkle();
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f59e0b', '#fbbf24', '#f43f5e', '#a855f7', '#10b981'],
    });
    onRandomClick();
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-12 sm:pt-14 sm:pb-16 bg-festive-royal min-h-[580px]">
      {/* Interactive 3D WebGL Diya, Lanterns & Particles Scene */}
      <ThreeDiwaliScene className="opacity-75" />

      {/* Background Ornate Rangoli Watermark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] sm:w-[900px] h-[600px] sm:h-[900px] pointer-events-none opacity-10 animate-slow-spin">
        <svg viewBox="0 0 200 200" className="w-full h-full fill-amber-400">
          <circle cx="100" cy="100" r="95" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="4 4" />
          <circle cx="100" cy="100" r="75" fill="none" stroke="currentColor" strokeWidth="1.5" />
          <circle cx="100" cy="100" r="50" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M100 5 L115 85 L195 100 L115 115 L100 195 L85 115 L5 100 L85 85 Z" fill="none" stroke="currentColor" strokeWidth="1" />
        </svg>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center">
        {/* Festive Kicker with 3D Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs sm:text-sm font-semibold mb-5 shadow-sm backdrop-blur-sm">
          <span className="animate-flame inline-block">🪔</span>
          <span>
            {lang === 'hi'
              ? 'कार्तिक मास कृष्ण पक्ष अमावस्या • विक्रम संवत 2083'
              : 'Festival of Lights • Vikram Samvat 2083'}
          </span>
          <span className="text-amber-400/50">·</span>
          <span className="text-amber-200 flex items-center gap-1">
            <Box className="w-3.5 h-3.5 text-amber-400" />
            3D WebGL
          </span>
        </div>

        {/* Hindi Grand Heading with 3D Depth */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-gold-gradient font-festive tracking-tight leading-tight mb-3 text-3d-gold">
          दीपावली की हार्दिक शुभकामनाएँ
        </h1>

        {/* English Title & Year */}
        <h2 className="text-xl sm:text-3xl md:text-4xl font-black text-amber-100 font-royal tracking-wider mb-4 drop-shadow">
          Happy Diwali 2026
        </h2>

        {/* Poetic Greeting text */}
        <p className="max-w-2xl mx-auto text-sm sm:text-lg text-amber-200/90 font-hindi leading-relaxed mb-8 drop-shadow">
          {lang === 'hi'
            ? 'दीपों के पावन पर्व पर अपने परिजनों, मित्रों और व्यावसायिक सहयोगियों के लिए 3D फोटो ग्रीटिंग कार्ड, व्हाट्सएप स्टेटस और शुभ संदेश तैयार करें।'
            : 'Craft 3D personalized photo greetings, WhatsApp status cards, and quotes adorned with glowing 3D diyas, rangoli, and golden sparkles.'}
        </p>

        {/* 3D Interactive Center Display */}
        <div className="max-w-md mx-auto my-6">
          <Card3D maxTilt={15} glare={true} className="cursor-pointer">
            <div className="flex items-center justify-center gap-6 sm:gap-10 p-4 rounded-3xl bg-black/40 border border-amber-500/30 backdrop-blur-md gold-glow transform-style-3d">
              <div className="flex flex-col items-center transform-style-3d translate-z-20">
                <span className="text-3xl sm:text-4xl animate-flame filter drop-shadow-[0_0_15px_#f59e0b] translate-z-30">🪔</span>
                <span className="text-[10px] sm:text-xs text-amber-300/80 font-medium mt-1">शुभ</span>
              </div>
              <div className="relative flex flex-col items-center p-3 rounded-full bg-amber-500/15 border border-amber-500/40 gold-glow transform-style-3d translate-z-40">
                <span className="text-4xl sm:text-5xl animate-flame filter drop-shadow-[0_0_20px_#f59e0b]">🪔</span>
                <span className="text-xs sm:text-sm font-bold text-amber-200 mt-1">श्री लक्ष्मी-गणेश</span>
              </div>
              <div className="flex flex-col items-center transform-style-3d translate-z-20">
                <span className="text-3xl sm:text-4xl animate-flame filter drop-shadow-[0_0_15px_#f59e0b] translate-z-30">🪔</span>
                <span className="text-[10px] sm:text-xs text-amber-300/80 font-medium mt-1">लाभ</span>
              </div>
            </div>
          </Card3D>
          <span className="text-[11px] text-amber-300/60 block mt-1.5 font-mono">
            ✨ Tilt phone or move cursor for 3D depth ✨
          </span>
        </div>

        {/* Main CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 mb-8">
          <button
            onClick={onCreateClick}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-purple-950 font-extrabold text-base shadow-xl hover:brightness-110 active:scale-95 transition-all gold-glow"
          >
            <Wand2 className="w-5 h-5 stroke-[2.5]" />
            <span>{lang === 'hi' ? 'अपना नाम लिखकर कार्ड बनाएं' : 'Create Greeting with Name'}</span>
          </button>

          <button
            onClick={onExploreGallery}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-amber-500/30 text-amber-100 font-bold text-base transition-all"
          >
            <span>{lang === 'hi' ? '100+ डिजाइन्स देखें' : 'Explore 100+ Designs'}</span>
            <ArrowRight className="w-4 h-4 text-amber-400" />
          </button>

          <button
            onClick={triggerCelebration}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-purple-900/40 hover:bg-purple-900/70 border border-purple-500/30 text-amber-200 font-semibold text-sm transition-all"
            title="Surprise me with a random greeting!"
          >
            <Shuffle className="w-4 h-4 text-amber-400" />
            <span>{lang === 'hi' ? 'रैंडम विश 🎆' : 'Random Greeting 🎆'}</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="max-w-xl mx-auto">
          <div className="relative flex items-center">
            <Search className="absolute left-4 w-5 h-5 text-amber-400/80 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={
                lang === 'hi'
                  ? 'खोजें: हिंदी विशेस, व्हाट्सएप स्टेटस, परिवार, व्यापार, लक्ष्मी पूजन...'
                  : 'Search: Hindi wishes, WhatsApp status, business, Laxmi puja, 9:16...'
              }
              className="w-full pl-12 pr-4 py-3 sm:py-3.5 rounded-2xl bg-[#180931]/90 border border-amber-500/30 text-amber-100 placeholder-amber-200/50 text-sm focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/20 shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3.5 text-xs text-amber-300 hover:text-white px-2 py-1 bg-white/10 rounded-md"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick search tag suggestions */}
          <div className="flex items-center justify-center gap-2 flex-wrap mt-3 text-xs text-amber-300/80">
            <span className="text-amber-200/50">{lang === 'hi' ? 'ट्रेंडिंग:' : 'Trending:'}</span>
            {[
              { tag: 'हिंदी संदेश', q: 'हिंदी' },
              { tag: 'WhatsApp Status', q: 'status' },
              { tag: 'सपरिवार', q: 'परिवार' },
              { tag: 'दुकान व व्यापार', q: 'व्यापार' },
              { tag: 'लक्ष्मी पूजन', q: 'laxmi' },
              { tag: 'Instagram Story', q: 'instagram' },
            ].map((t, idx) => (
              <button
                key={idx}
                onClick={() => onSearchChange(t.q)}
                className="hover:text-amber-100 underline decoration-amber-500/40 underline-offset-2 transition-colors"
              >
                {t.tag}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
