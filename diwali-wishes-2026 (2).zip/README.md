# Diwali Wishes 2026 🪔

A production-ready, mobile-first Indian festive web application celebrating **Diwali 2026 (Sunday, November 8, 2026 • Vikram Samvat 2083)** with glowing oil lamps (diyas), realistic rangoli, royal gold aesthetics, a personal greeting maker with HTML5 Canvas export, 100+ design slots across 17 categories, multi-platform sharing, genuine analytics, and a protected admin portal.

---

## 🌟 Key Features

### 🪔 1. Authentic Festive Design
- **Glowing Diyas & Realistic Lamps**: Realistic flickering flame animation, clay and brass lamps, floating lanterns.
- **Indian Festive Palette**: Deep royal purple (`#120626`), royal midnight blue, saffron, temple gold, and sindoori red.
- **Bilingual Experience**: Instant Hindi (हिन्दी) & English toggle.
- **Festive Sound**: Web Audio API synthesizer playing temple bell (घंटी) and sparkler chime (muted by default with clear toggle).
- **Diwali 2026 Countdown**: Accurate countdown to Sunday, November 8, 2026 (Kartik Amavasya) with muhurat indicators.

### 🎨 2. Personal Greeting Maker (HTML5 Canvas Engine)
- **Aspect Ratio Options**:
  - `1:1` Square (Feed post)
  - `9:16` Full Vertical (WhatsApp Status & Instagram Story)
  - `4:5` Portrait (Printable luxury greeting card)
  - `16:9` Landscape (Banner / Desktop)
- **Personalized Inputs**:
  - Sender Name (e.g., *राजेश एवं समस्त परिवार*)
  - Recipient Name (e.g., *प्रिय वर्मा जी*)
  - Business / Shop Name (e.g., *॥ शुभ लाभ ज्वेलर्स ॥*)
  - Custom Greeting Message with 14+ one-click Hindi & English presets
- **Photo Upload**:
  - Circle (with royal gold rim), rounded, or square framing.
  - Scale slider and positioning.
- **Styling Controls**:
  - Hindi Unicode fonts (Rozha One, Noto Sans Devanagari, Cinzel, Great Vibes, Outfit).
  - Font scaling, alignment (Left, Center, Right), golden text shadow toggle.
- **Stickers & Diya Overlays**: Placeable Diyas, Rangoli, Kalash, Swastik, Om, and Marigold garlands.
- **Export**: Instant pristine 1080p PNG/JPG download and generation of unique public shareable URLs (`/wishes/:slug`).

### 📱 3. Multi-Platform Social Sharing
- **WhatsApp**: Pre-formatted message with title, greeting text, and link.
- **Facebook, X (Twitter), Telegram**: Direct dialog integrations.
- **Instagram**: "Download Image + Open Instagram" workflow.
- **QR Code**: Scan to view personalized card on any smartphone.
- **One-Click Copy**: Instant toast feedback for copying greeting texts and links.

### 🖼️ 4. 100+ Design Slots Across 17 Categories
1. Happy Diwali Hindi
2. Happy Diwali English
3. Family Diwali Wishes
4. Friends Diwali Wishes
5. Love and Couple Greetings
6. Business and Shop Greetings
7. Corporate Diwali Greetings
8. Laxmi Puja and Ganesh Puja
9. Shubh Deepawali
10. Kids and Cartoon Diwali
11. Royal Gold Diwali
12. Animated Diwali Greetings
13. WhatsApp Status 9:16
14. Instagram Story 9:16
15. Facebook Post 1:1
16. Greeting Cards 4:5
17. YouTube Shorts Background 9:16

### 🛡️ 5. Protected Admin Dashboard (`/admin`)
- **Protected Access**: Default password `diwali2026admin` (or configured via `ADMIN_PASSWORD` env var).
- **Genuine Analytics**: Real visitor metrics, cards created count, and platform share click breakdown (no fake counters).
- **Greeting Management**: Add new designs, edit existing metadata, delete, or mark as featured/trending.
- **Content Moderation**: Review user-submitted content reports.

### 💰 6. Monetization & Ads Hub (Google AdSense, Adsterra & Affiliate Commission)
- **Google AdSense**: Configurable Publisher Client ID (`ca-pub-XXXXX`), Ad unit slot ID, responsive banner ad unit, and dynamic `/ads.txt` generation.
- **Adsterra (Sterior Ad Network)**: Configurable Smart Direct Link and Popunder/Banner script code to monetize festive viral traffic.
- **E-Commerce Affiliate Commission Links**:
  - **Amazon India**: Festive Diwali sale affiliate tracking link.
  - **Flipkart**: Big Billion Days & Big Diwali Sale affiliate tracking link.
  - **Myntra**: Diwali ethnic wear & festive fashion affiliate link.
  - **Custom Festive Deals**: Add specific deals (Brass Akhand Diya, Kaju Katli gift hampers, fairy lights, pooja thalis) with custom store, discount text, and URLs.
- **Diwali Festive Storefront (`AffiliateDeals.tsx`)**: High-converting festive gift showcase displayed on the homepage and within the greeting download panel.

### 🎬 7. Social Videos & Reels Hub (YouTube, Instagram, Facebook)
- **YouTube Festive Videos**: Embed Diwali Lakshmi Aarti (`F0W0lC59QZ4`), Ayodhya Deepotsav, and festive bhajans with an in-app responsive theater modal.
- **Instagram Reels**: Direct links to popular Diwali rangoli tutorials and festive reels.
- **Facebook Videos**: Direct links to authentic festive recipes and celebration videos.
- **Admin Control**: Add, edit, and delete video links and embed codes directly in `/admin`.

### 🔍 8. SEO & Social Scraper Ready
- Dynamic Server-Rendered OpenGraph & Twitter Card tags in `server.ts` for social links (`/wishes/:slug`).
- Dynamic `sitemap.xml` and `robots.txt`.
- 5 Dedicated Keyword Landing Pages (`/seo/diwali-greetings`, `/seo/whatsapp-status`, etc.).
- Schema.org JSON-LD structured data and breadcrumbs.

---

## 🚀 Beginner Deployment Guide (From Mobile or Desktop)

### Prerequisites
- Node.js 18+ installed on your computer or cloud container.

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Start the Full-Stack Server
```bash
npm run dev
```
The server will start on `http://0.0.0.0:3000`.

### Step 3: Production Build
```bash
npm run build
npm start
```

---

## ☁️ Connecting Firebase Firestore & Storage (Optional)

The application works out-of-the-box in local demo mode with in-memory caching and localStorage. To persist data in Google Firebase:

1. Create a Firebase project in the [Firebase Console](https://console.firebase.google.com/).
2. Enable **Firestore Database** in test or production mode.
3. Deploy the following security rules to `firestore.rules`:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Anyone can read greetings; only authenticated admins can write
    match /greetings/{id} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    // Users can create and read personalized custom cards
    match /customCards/{id} {
      allow read: if true;
      allow create: if request.resource.data.senderName != null;
    }
  }
}
```

---

## 📄 License
Apache-2.0 License.
Made with devotion for Diwali 2026.
