export type AspectRatioType = '1:1' | '9:16' | '4:5' | '16:9';

export type CardTheme = 
  | 'royal-purple' 
  | 'golden-amber' 
  | 'crimson-divine' 
  | 'midnight-blue' 
  | 'saffron-glow' 
  | 'emerald-festive'
  | 'temple-gold';

export interface GreetingDesign {
  id: string;
  slug: string;
  title: string;
  titleHi: string;
  categoryId: string;
  hindiWish: string;
  englishWish: string;
  aspectRatio: AspectRatioType;
  theme: CardTheme;
  imageUrl?: string;
  previewGradient: string;
  featured?: boolean;
  trending?: boolean;
  likes?: number;
  shares?: number;
  tags: string[];
  seoTitle?: string;
  seoDescription?: string;
}

export interface CategoryInfo {
  id: string;
  slug: string;
  name: string;
  nameHi: string;
  iconName: string;
  description: string;
  defaultAspectRatio: AspectRatioType;
  count?: number;
}

export interface DecorativeSticker {
  id: string;
  name: string;
  nameHi: string;
  category: 'diya' | 'rangoli' | 'divine' | 'crackers' | 'floral';
  svgPath: string;
}

export interface PlacedSticker {
  id: string;
  stickerId: string;
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  scale: number;
  rotation?: number;
}

export interface UserPersonalization {
  id?: string;
  slug?: string;
  senderName: string;
  recipientName: string;
  businessName: string;
  messageText: string;
  language: 'hi' | 'en';
  baseDesignId: string;
  aspectRatio: AspectRatioType;
  fontFamily: string;
  fontSize: number; // base scale
  textColor: string;
  textShadow: boolean;
  textAlign: 'center' | 'left' | 'right';
  userPhotoUrl: string | null;
  photoShape: 'circle' | 'square' | 'rounded';
  photoPosition: { x: number; y: number; scale: number };
  stickers: PlacedSticker[];
  cardBackground?: string;
  createdAt?: string;
}

export interface SiteLanguage {
  lang: 'hi' | 'en';
}

export interface AdminAnalytics {
  totalVisits: number;
  totalCardsCreated: number;
  totalShares: number;
  shareBreakdown: {
    whatsapp: number;
    facebook: number;
    twitter: number;
    telegram: number;
    download: number;
    copyLink: number;
  };
  topCategories: { categoryId: string; count: number }[];
}

export interface AffiliateDeal {
  id: string;
  title: string;
  titleHi: string;
  store: 'Amazon' | 'Flipkart' | 'Myntra' | 'Other';
  url: string;
  discountText: string;
  category: string;
  icon: string;
}

export interface SocialVideoItem {
  id: string;
  platform: 'youtube' | 'instagram' | 'facebook';
  title: string;
  titleHi: string;
  url: string;
  thumbnailUrl?: string;
  embedId?: string;
  description?: string;
}

export interface DonationSettings {
  enabled: boolean;
  upiId: string;
  merchantName: string;
  razorpayKeyId: string;
  razorpayKeySecret?: string;
  minAmount: number;
  suggestedAmounts: number[];
  causeTitle: string;
  causeTitleHi: string;
}

export interface MonetizationSettings {
  googleAdClient: string;
  googleAdSlot: string;
  googleAdEnabled: boolean;
  adsterraDirectLink: string;
  adsterraBannerCode: string;
  adsterraEnabled: boolean;
  adsTxtContent: string;
  amazonAffiliateUrl: string;
  flipkartAffiliateUrl: string;
  myntraAffiliateUrl: string;
  customDeals: AffiliateDeal[];
  videos: SocialVideoItem[];
  donation?: DonationSettings;
}

