import { UserPersonalization } from '../types/greeting';

const FAVORITES_KEY = 'diwali_wishes_favorites_v1';
const RECENT_VIEWED_KEY = 'diwali_wishes_recent_v1';
const CREATED_CARDS_KEY = 'diwali_wishes_my_creations_v1';
const LANG_KEY = 'diwali_wishes_pref_lang';

export function getFavorites(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleFavorite(designId: string): boolean {
  try {
    const current = getFavorites();
    const index = current.indexOf(designId);
    let updated: string[];
    let isFav = false;
    if (index > -1) {
      updated = current.filter((id) => id !== designId);
      isFav = false;
    } else {
      updated = [designId, ...current];
      isFav = true;
    }
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    return isFav;
  } catch {
    return false;
  }
}

export function isFavorite(designId: string): boolean {
  return getFavorites().includes(designId);
}

export function getRecentlyViewed(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_VIEWED_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addRecentlyViewed(designId: string) {
  try {
    const current = getRecentlyViewed().filter((id) => id !== designId);
    const updated = [designId, ...current].slice(0, 16);
    localStorage.setItem(RECENT_VIEWED_KEY, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

export function getSavedCustomCards(): UserPersonalization[] {
  try {
    const raw = localStorage.getItem(CREATED_CARDS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveCustomCard(card: UserPersonalization) {
  try {
    const current = getSavedCustomCards().filter((c) => c.id !== card.id);
    const updated = [card, ...current].slice(0, 30);
    localStorage.setItem(CREATED_CARDS_KEY, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

export function getPreferredLanguage(): 'hi' | 'en' {
  try {
    const saved = localStorage.getItem(LANG_KEY);
    if (saved === 'hi' || saved === 'en') return saved;
  } catch {
    // Ignore
  }
  return 'hi'; // Default Hindi for authentic Diwali feel, toggleable anytime
}

export function setPreferredLanguage(lang: 'hi' | 'en') {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch {
    // Ignore
  }
}
