/**
 * Web Audio API synthesizer for festive Indian chime and temple bell.
 * Plays clean acoustic tones without external audio file download dependencies.
 */

class FestiveAudioPlayer {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = true; // muted by default as requested

  constructor() {
    // Lazy initialize on first interaction
  }

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (!muted) {
      this.initCtx();
      this.playTempleChime();
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  /**
   * Plays an auspicious Indian festive temple bell chime (Ghanti sound)
   */
  public playTempleChime() {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      // Fundamental bell frequency & harmonics
      const freqs = [587.33, 1174.66, 1760.0, 2349.32]; // D5 note with harmonics
      const gains = [0.4, 0.25, 0.15, 0.08];

      freqs.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gainNode = this.ctx.createGain();

        osc.type = idx === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        // Exponential decay for realistic bell resonance
        gainNode.gain.setValueAtTime(gains[idx], now);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 1.8 + idx * 0.2);

        osc.connect(gainNode);
        gainNode.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 2.2);
      });
    } catch {
      // Audio not supported or blocked by browser policy
    }
  }

  public playChime() {
    this.playTempleChime();
  }

  /**
   * Plays authentic auspicious Shankh Naad (Conch shell sound)
   */
  public playShankhNaad() {
    this.initCtx();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const baseFreq = 220;
      const harmonics = [
        { f: baseFreq, g: 0.35, t: 'sawtooth' as OscillatorType },
        { f: baseFreq * 2, g: 0.25, t: 'triangle' as OscillatorType },
        { f: baseFreq * 3, g: 0.15, t: 'sine' as OscillatorType },
      ];

      harmonics.forEach(({ f, g, t }) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = t;
        osc.frequency.setValueAtTime(f * 0.85, now);
        osc.frequency.exponentialRampToValueAtTime(f * 1.15, now + 0.3);
        osc.frequency.exponentialRampToValueAtTime(f, now + 0.8);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(g, now + 0.4);
        gain.gain.setValueAtTime(g, now + 1.6);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 2.8);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 2.9);
      });
    } catch {
      // Ignore
    }
  }

  /**
   * Plays festive Diwali Firecrackers sound effect
   */
  public playCrackersSound() {
    this.initCtx();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      for (let i = 0; i < 4; i++) {
        const time = now + i * 0.12 + Math.random() * 0.05;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(140 + Math.random() * 80, time);
        osc.frequency.exponentialRampToValueAtTime(30, time + 0.18);

        gain.gain.setValueAtTime(0.4, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(time);
        osc.stop(time + 0.28);
      }
      this.playSparkle();
    } catch {
      // Ignore
    }
  }

  /**
   * Plays traditional Diwali Aarti & Bhajan melody ("Om Jai Lakshmi Mata" notes)
   */
  public playDiwaliSongMelody() {
    this.initCtx();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const notes = [
        { f: 261.63, dur: 0.28 },
        { f: 293.66, dur: 0.28 },
        { f: 329.63, dur: 0.35 },
        { f: 349.23, dur: 0.28 },
        { f: 392.0, dur: 0.45 },
        { f: 440.0, dur: 0.35 },
        { f: 392.0, dur: 0.35 },
        { f: 329.63, dur: 0.35 },
        { f: 293.66, dur: 0.35 },
        { f: 261.63, dur: 0.6 },
      ];

      let t = now;
      notes.forEach((n) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(n.f, t);

        gain.gain.setValueAtTime(0.01, t);
        gain.gain.linearRampToValueAtTime(0.25, t + 0.05);
        gain.gain.setValueAtTime(0.2, t + n.dur * 0.7);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + n.dur);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t);
        osc.stop(t + n.dur + 0.05);
        t += n.dur;
      });

      setTimeout(() => {
        this.playTempleChime();
      }, (t - now) * 1000);
    } catch {
      // Ignore
    }
  }

  /**
   * Plays celebratory festive Shehnai / Sitar Dhun
   */
  public playFestiveDhun() {
    this.playDiwaliSongMelody();
  }

  /**
   * Plays a cheerful firework sparkle sound
   */
  public playSparkle() {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C E G C
      notes.forEach((freq, i) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.08);

        gain.gain.setValueAtTime(0.2, now + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.08 + 0.4);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.45);
      });
    } catch {
      // Ignore
    }
  }
}

export const festiveAudio = new FestiveAudioPlayer();
