import React, { useState } from 'react';
import { Clock, Sparkles, Volume2, Flame, Bell, Star, Music, ChevronDown, ChevronUp } from 'lucide-react';
import { Card3D } from './Card3D';
import { festiveAudio } from '../utils/audio';

interface DiwaliMuhuratProps {
  lang: 'hi' | 'en';
}

export const DiwaliMuhurat: React.FC<DiwaliMuhuratProps> = ({ lang }) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState<string | null>(null);
  const [showFullVidhi, setShowFullVidhi] = useState<boolean>(false);

  const handlePlaySound = (type: 'shankh' | 'aarti' | 'bell' | 'crackers') => {
    setIsPlayingAudio(type);
    if (type === 'shankh') {
      festiveAudio.playShankhNaad();
    } else if (type === 'aarti') {
      festiveAudio.playDiwaliSongMelody();
    } else if (type === 'bell') {
      festiveAudio.playTempleChime();
    } else if (type === 'crackers') {
      festiveAudio.playCrackersSound();
    }
    setTimeout(() => {
      setIsPlayingAudio(null);
    }, 3500);
  };

  return (
    <Card3D maxTilt={7} glare={true} className="w-full">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#2a0e44] via-[#1a0730] to-[#3a1020] border-2 border-amber-500/40 p-5 sm:p-7 shadow-2xl gold-glow transform-style-3d">
        {/* Subtle decorative rangoli watermark */}
        <div className="absolute -right-12 -top-12 w-48 h-48 opacity-10 pointer-events-none">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-amber-300">
            <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" />
            <polygon points="50,5 63,38 95,50 63,62 50,95 38,62 5,50 38,38" fill="none" stroke="currentColor" strokeWidth="1.5" />
          </svg>
        </div>

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/25 pb-4 mb-5 translate-z-20">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 text-2xl shadow-inner animate-flame">
              🪔
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[11px] font-bold tracking-wider font-mono">
                  {lang === 'hi' ? 'शास्त्रसम्मत पंचांग 2026' : 'Vedic Panchang 2026'}
                </span>
                <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                  <Star className="w-3 h-3 fill-emerald-400" />
                  {lang === 'hi' ? 'अमृत योग' : 'Shubh Yog'}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-amber-100 font-festive mt-0.5 text-3d-gold">
                {lang === 'hi' ? 'दीपावली लक्ष्मी-गणेश पूजन शुभ मुहूर्त' : 'Diwali Lakshmi-Ganesh Puja Muhurat'}
              </h2>
            </div>
          </div>

          {/* Quick Sound Buttons */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={() => handlePlaySound('shankh')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all shadow-md active:scale-95 ${
                isPlayingAudio === 'shankh'
                  ? 'bg-amber-500 text-purple-950 border-amber-400 animate-pulse'
                  : 'bg-amber-500/15 hover:bg-amber-500/25 border-amber-500/30 text-amber-300'
              }`}
              title="Play Shankh Naad"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'शंख नाद' : 'Shankh'}</span>
            </button>
            <button
              onClick={() => handlePlaySound('aarti')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all shadow-md active:scale-95 ${
                isPlayingAudio === 'aarti'
                  ? 'bg-amber-500 text-purple-950 border-amber-400 animate-pulse'
                  : 'bg-red-500/15 hover:bg-red-500/25 border-red-500/30 text-red-300'
              }`}
              title="Play Lakshmi Aarti Melody"
            >
              <Music className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'आरती धुन' : 'Aarti'}</span>
            </button>
            <button
              onClick={() => handlePlaySound('bell')}
              className="p-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 text-amber-300 transition-colors"
              title="Temple Bell"
            >
              <Bell className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4 Key Muhurat Timings Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-5 translate-z-10">
          {/* Box 1: Sthir Lagna (Vrishabha) */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-600/10 border-2 border-amber-400/50 shadow-lg relative overflow-hidden group hover:border-amber-300 transition-all">
            <div className="absolute top-2 right-2 text-xs px-2 py-0.5 rounded-full bg-amber-400 text-purple-950 font-black">
              ★ {lang === 'hi' ? 'सर्वश्रेष्ठ' : 'Best'}
            </div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300 mb-1">
              <Clock className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'वृषभ लग्न (स्थिर लग्न)' : 'Vrishabha Lagna'}</span>
            </div>
            <div className="text-xl sm:text-2xl font-black text-amber-100 font-mono tracking-tight my-1">
              06:12 PM – 08:08 PM
            </div>
            <p className="text-[11px] text-amber-200/80 font-hindi">
              {lang === 'hi'
                ? 'अवधि: 1 घंटा 56 मिनट (घर व दुकान में महालक्ष्मी वास)'
                : 'Duration: 1h 56m — Ideal for home & shop Puja'}
            </p>
          </div>

          {/* Box 2: Pradosh Kaal */}
          <div className="p-4 rounded-2xl bg-black/40 border border-amber-500/25 shadow-md hover:border-amber-400/40 transition-all">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300 mb-1">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span>{lang === 'hi' ? 'प्रदोष काल मुहूर्त' : 'Pradosh Kaal'}</span>
            </div>
            <div className="text-xl sm:text-2xl font-black text-amber-100 font-mono tracking-tight my-1">
              05:39 PM – 08:14 PM
            </div>
            <p className="text-[11px] text-amber-200/70 font-hindi">
              {lang === 'hi'
                ? 'अवधि: 2 घंटा 35 मिनट (दीप प्रज्वलन व पूजा)'
                : 'Duration: 2h 35m — Diya lighting & prayers'}
            </p>
          </div>

          {/* Box 3: Nishitha Kaal */}
          <div className="p-4 rounded-2xl bg-black/40 border border-amber-500/25 shadow-md hover:border-amber-400/40 transition-all">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'hi' ? 'महानिशीथ काल (सिंह लग्न)' : 'Maha Nishitha Kaal'}</span>
            </div>
            <div className="text-xl sm:text-2xl font-black text-amber-100 font-mono tracking-tight my-1">
              11:42 PM – 12:33 AM
            </div>
            <p className="text-[11px] text-amber-200/70 font-hindi">
              {lang === 'hi'
                ? 'अवधि: 51 मिनट (कुबेर पूजन व लक्ष्मी साधना)'
                : 'Duration: 51m — Kuber Puja & Midnight Sadhana'}
            </p>
          </div>

          {/* Box 4: Shubh Choghadiya */}
          <div className="p-4 rounded-2xl bg-black/40 border border-amber-500/25 shadow-md hover:border-amber-400/40 transition-all">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300 mb-1">
              <Star className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'hi' ? 'चौघड़िया शुभ मुहूर्त' : 'Shubh Choghadiya'}</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-amber-100 font-mono tracking-tight my-1">
              07:15 PM – 10:25 PM
            </div>
            <p className="text-[11px] text-amber-200/70 font-hindi">
              {lang === 'hi'
                ? 'शुभ व अमृत चौघड़िया (अखंड सुख व सौभाग्य)'
                : 'Shubh & Amrit muhurat for prosperity'}
            </p>
          </div>
        </div>

        {/* Sacred Mantra & Shloka Banner */}
        <div className="p-3.5 sm:p-4 rounded-2xl bg-amber-500/10 border border-amber-400/30 flex flex-col md:flex-row items-center justify-between gap-3 text-center md:text-left translate-z-10">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🕉️</span>
            <div>
              <span className="text-[11px] text-amber-300/80 font-bold tracking-wider block font-hindi">
                ॥ सिद्ध महालक्ष्मी बीज मंत्र ॥
              </span>
              <p className="text-sm sm:text-base font-black text-amber-200 font-festive">
                ॐ श्रीं ह्रीं क्लीं श्रीं सिद्ध लक्ष्म्यै नमः
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handlePlaySound('aarti')}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 text-purple-950 font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Music className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'आरती सुनें' : 'Listen Aarti'}</span>
            </button>
            <button
              onClick={() => setShowFullVidhi(!showFullVidhi)}
              className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-amber-500/20 text-amber-300 text-xs font-semibold flex items-center gap-1"
            >
              <span>{showFullVidhi ? (lang === 'hi' ? 'संक्षिप्त करें' : 'Hide Vidhi') : (lang === 'hi' ? 'पूजन सामग्री व विधि' : 'Puja Vidhi')}</span>
              {showFullVidhi ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Expandable Puja Vidhi & Samagri */}
        {showFullVidhi && (
          <div className="mt-4 pt-4 border-t border-amber-500/20 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-amber-200/90 font-hindi leading-relaxed animate-in fade-in duration-300">
            <div className="p-3.5 rounded-xl bg-black/30 border border-amber-500/20">
              <h4 className="font-bold text-amber-300 mb-2 flex items-center gap-1.5">
                <span>🪔</span>
                <span>{lang === 'hi' ? 'पूजन सामग्री सूची (Pooja Samagri)' : 'Key Puja Essentials'}</span>
              </h4>
              <ul className="space-y-1 list-disc list-inside text-amber-200/80">
                <li>कच्ची मिट्टी या पीतल के दीपक, गाय का शुद्ध घी व तिल का तेल</li>
                <li>कमलगट्टा, कौड़ी, गोमती चक्र, साबुत हल्दी व धनिया</li>
                <li>लाल व पीला वस्त्र, रोली, चंदन, अक्षत, धूप व कपूर</li>
                <li>कमल का फूल, गेंदा माला, पान के पत्ते व पंचामृत</li>
                <li>लक्ष्मी-गणेश की नवीन प्रतिमा, खील, बताशे व मोदक</li>
              </ul>
            </div>

            <div className="p-3.5 rounded-xl bg-black/30 border border-amber-500/20">
              <h4 className="font-bold text-amber-300 mb-2 flex items-center gap-1.5">
                <span>✨</span>
                <span>{lang === 'hi' ? 'सरल पूजन विधि (Step-by-Step Vidhi)' : 'Simple Puja Steps'}</span>
              </h4>
              <ol className="space-y-1 list-decimal list-inside text-amber-200/80">
                <li>चौकी पर लाल वस्त्र बिछाकर मां लक्ष्मी व गणेश जी स्थापित करें।</li>
                <li>पूर्व या उत्तर दिशा की ओर मुख करके अखंड ज्योति प्रज्वलित करें।</li>
                <li>तिलक, अक्षत, पुष्प अर्पित कर गणेश वंदना व लक्ष्मी आवाहन करें।</li>
                <li>खील-बताशे व नैवेद्य भोग लगाएं और 11 या 21 दीपक प्रज्वलित करें।</li>
                <li>सपरिवार "ॐ जय लक्ष्मी माता" की आरती गाएं व शंख-घंटी बजाएं।</li>
              </ol>
            </div>
          </div>
        )}
      </div>
    </Card3D>
  );
};
